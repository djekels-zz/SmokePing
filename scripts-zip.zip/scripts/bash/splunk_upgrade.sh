#!/usr/bin/bash

COLOR_GREEN='\033[0;32m'
COLOR_DEFAULT='\033[0m'
COLOR_RED='\033[0;31m'
COLOR_BLUE='\033[1;34m'

HOSTS_DEV="GLA2VM251
GLA2VM250
GLA2VM249
GLA0LOG133
GLA0LOG134
GLA0LOG141
GLA0LOG142
GLA0LOG144
GLA0LOG145
GLA0LOG147"

HOSTS_7X="119.0.200.55
119.0.200.59
119.0.200.58
119.0.200.51
119.0.200.52
119.1.200.51
119.1.200.52
119.16.200.51
119.16.200.52
119.17.200.51
119.17.200.52
119.32.200.51
119.32.200.52
119.33.200.51
119.33.200.52
119.34.200.51
119.34.200.52
119.36.200.51
119.36.200.52"

HOSTS_UAT="ny2vm187
ch2vm150
ch2vm101
ny3vm156
ny3vm157
ny3vm158
ny3vm160
ny3vm161
ny3vm162
ny3vm163"

HOSTS_PROD="ar2vm41
ar2vm90
ar2vm38
ch0log151
ch0log152
ch0log153
ch0log158
ch0log159
ch0log160
ch0log161"

print() { printf "[${COLOR_GREEN}✓${COLOR_DEFAULT}] $*\n" ; }
error()  { if [ ! -z "$1" ]; then printf "[${COLOR_RED}✗${COLOR_DEFAULT}] $*\n" ; fi }

function OCT2() {
  local dc="${1}"

  case $dc in
    [Gg][Ll][Aa]) OCTET2=192 ;;
    [Gg][Ll][Bb]) OCTET2=193 ;;
    [Gg][Ll][Cc]) OCTET2=194 ;;
    [Gg][Ll][Dd]) OCTET2=195 ;;
    [Ii][Pp][Aa]) OCTET2=176 ;;
    [Ii][Pp][Bb]) OCTET2=177 ;;
    [Ii][Pp][Cc]) OCTET2=178 ;;
    [Aa][Rr]) OCTET2=102 ;;
    [Cc][Hh]) OCTET2=111 ;;
    [Ff][Rr]) OCTET2=127 ;;
    [Ss][Yy]) OCTET2=144 ;;
    [Ss][Gg]) OCTET2=143 ;;
    [Nn][Yy]) OCTET2=113 ;;
    [Ll][Nn]) OCTET2=126 ;;
    [Hh][Kk]) OCTET2=145 ;;
    [Tt][Yy]) OCTET2=142 ;;
    [Bb][Kk]) OCTET2=147 ;;
    [Bb][Aa]) OCTET2=125 ;;
    [Ss][Pp]) OCTET2=148 ;;
    [Ss][Qq][Ee][Cc][Hh]) OCTET2=184 ;;
    [Ss][Qq][Ee][Nn][Yy]) OCTET2=185 ;;
    [Ss][Qq][Ee][Aa][Rr]) OCTET2=186 ;;
    [Ss][Qq][Ee][Ff][Rr]) OCTET2=187 ;;
    [Ss][Qq][Ee][Ss][Gg]) OCTET2=188 ;;
    [Ss][Qq][Ee][Sy][Yy]) OCTET2=189 ;;
    [Ss][Qq][Ee][Ll][Nn]) OCTET2=190 ;;
    [Ss][Qq][Ee][Tt][Kk]) OCTET2=191 ;;
    [Mm]-[Aa][Rr]) OCTET2=204 ;;
    [Mm]-[Cc][Hh]) OCTET2=205 ;;
    [Mm]-[Ff][Rr]) OCTET2=206 ;;
    [Mm]-[Nn][Yy]) OCTET2=207 ;;
  esac

  echo ${OCTET2}
}

# Who needs DNS anyways
function ttdns() {
  HOST=$(echo "${1}" | tr '[:upper:]' '[:lower:]')

  if [[ ${HOST} =~ (m-[a-zA-Z]+|m[a-zA-Z]+|sqe-[a-zA-Z]+|sqe[a-zA-Z]+|[a-zA-Z]+)([0-9]+)([a-zA-Z]+)([0-9]+) ]] ; then
    DC=${BASH_REMATCH[1]}
    DC_OCT=${BASH_REMATCH[2]}
    CLASS=${BASH_REMATCH[3]}
    CLASS_OCT=${BASH_REMATCH[4]}
  fi

  IP="10.$(OCT2 "$DC").${DC_OCT}.${CLASS_OCT}"

  echo "${IP}"
}


function do_loop() {
  hosts="${1}"
  cmd="${2}"
  for x in ${hosts}
    do
    if [[ ${x} =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]]; then
      print "Connecting to: ${x}"
      ipaddr="${x}"
    else
      ipaddr=$(ttdns "${x}")
      print "Connecting to: ${COLOR_GREEN}${x}${COLOR_DEFAULT} (${COLOR_BLUE}${ipaddr}${COLOR_DEFAULT})"
    fi
    # shellcheck disable=SC2029
    ssh -l "$(whoami)" "${ipaddr}" "${cmd}"
  done
}

### Install new package and start splunk...
if [[ -z ${1} ]]
then
  file="splunk-7.3.4-13e97039fb65-linux-2.6-x86_64.rpm"
else
  file="${1}"
fi

pass=$(cat /dev/urandom| tr -dc 'a-zA-Z0-9' | fold -w 24| head -n 1)

if [[ ! -z ${2} && ${2} != "DEV" ]] ; then
  print "You are attempting to upgrade an environment OTHER THEN DEV..."
  print "Please enter the password (${COLOR_BLUE}${pass}${COLOR_DEFAULT}) to continue!!!"
  read -r -s proceed
  if [[ ${proceed} != ${pass} ]] ; then
    error "${COLOR_RED}You have not provided the correct password...${COLOR_DEFAULT}"
    exit 1
  fi
fi

if [[ -z ${2} ]]
then
  hosts=${HOSTS_DEV}
  clstr="DEV"
else
  hosts=$(eval echo \$HOSTS_$2)
  clstr=${2}
fi

print "Starting splunk upgrade.... \n    Upgrading to: ${COLOR_GREEN}${file}${COLOR_DEFAULT}\n    On Cluster: ${COLOR_GREEN}${clstr}${COLOR_DEFAULT}"

cmd="sudo rpm -Uhv http://172.17.250.250/repo/tt-custom/el7/x86_64/${file} ; sudo /opt/splunk/bin/splunk start --accept-license --no-prompt --answer-yes"
do_loop "${hosts}" "${cmd}"

cmd="hostname ; rpm -qa | grep splunk"
do_loop "${hosts}" "${cmd}"
