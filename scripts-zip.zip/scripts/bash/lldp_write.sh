#!/bin/bash
#Author: Sy Spencer
#JIRA: OPS-21989

hst=$(hostname)
cent_ver=$(sudo rpm --eval %{centos_ver})
hst_type=$(sudo dmidecode -s system-product-name)

echo "$hst is a CentOS $cent_ver server running on $hst_type."

if [[ "$hst" =~ .*"vm".* ]]
then
    echo "This looks like a VM and is not supported. Exiting..."
    exit 1
elif [[ $hst_type = "VMware Virtual Platform" ]]
then
    echo "This is a VMware VM and is not supported. Exiting..."
    exit 1
elif [[ $hst_type = "AHV" ]]
then
    echo "This is a Nutanix VM and is not supported. Exiting..."
    exit 1
fi

if [[ $cent_ver -eq 6 ]]
then
    mgt_iface=$"eth0"
    trd_iface=$"eth1"
    echo "Management Interface: $mgt_iface"
    echo "Trade Interface: $trd_iface"
elif [[ $cent_ver -ge 7 ]]
then
    mgt_iface=$(sudo ip route get 8.8.8.8 | awk -- '{printf $5}')
    trd_iface=$(sudo ls /sys/class/net | sudo grep $(echo $mgt_iface | sudo sed -e 's/^\(.\{4\}\).*$/\1/')".*1")
    echo "Management Interface: $mgt_iface"
    echo "Trade Interface: $trd_iface"
else
    echo "This script is only supported on Centos6 and Centos7. Better check yourself before you wreck yourself."
    exit 1
fi

if [[ "$hst" =~ .*"srv".* ]]
then
    echo "Enabling lldp for interface: $mgt_iface"
    sudo lldptool set-lldp -i $mgt_iface adminStatus=rxtx
    sudo lldptool -T -i $mgt_iface -V sysName enableTx=yes
    sudo lldptool -T -i $mgt_iface -V portDesc enableTx=yes
    echo "Enabling lldp for interface: $trd_iface"
    sudo lldptool set-lldp -i $trd_iface adminStatus=rxtx
    sudo lldptool -T -i $trd_iface -V sysName enableTx=yes
    sudo lldptool -T -i $trd_iface -V portDesc enableTx=yes
else
    echo "Unknown host type. Exiting..."
    exit 1
fi
