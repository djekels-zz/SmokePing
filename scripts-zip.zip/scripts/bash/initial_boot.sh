#!/bin/bash

#
# this script is build from Epic to verify machines before bootstrapped 
#
# Author: SysEgn Team 
# Summer 2020

# we doing colors to aide with legibilty
COLOR_GREEN='\033[0;32m'
COLOR_DEFAULT='\033[0m'
COLOR_RED='\033[0;31m'
COLOR_BLUE='\033[1;34m'
COLOR_LBLUE='\033[1;34m'
COLOR_PURPLE='\033[0;35m'

ScriptLoc=$(readlink -f "$0")

# call these functions through out the tool to aide as the tool grows
print() { printf "[${COLOR_GREEN}✓${COLOR_DEFAULT}] $*\n" ; }
error()  { if [ ! -z "$1" ]; then printf "[${COLOR_RED}✗${COLOR_DEFAULT}] $*\n" ; fi }


# one function for each ticket in the epic

usage() {


}


verify_hardware() {
# OPS-20838

   print "Checking if the hardware is supported reaper jobs"
   print "------------------------------------------------------------------------"

   $hardware = $()
   
   if [ $hardware matches all the models we support ]; then

      print "this hardware is supported"

   else

      error "this hardware is not currently supported"

   fi

}


verify_operating_system() {
# OPS-20839


}



main() {

   case $1 in
     start) 
	verify_hardware
	verify_operating_system
        ;;
     *)
        usage
        ;;
   esac

}

main
