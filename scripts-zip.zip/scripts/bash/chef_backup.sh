#!/usr/bin/env bash

# Program Name: chef_backup.sh
# Author Name : Jeremy M <j@trade.tt>
# Created On  : Apr 24 2018
# Purpose     : Backup Chef Env
#----------------------------------------------------------------------------------

### Function Defs
print() { printf "[\033[0;34m+\033[0m]: $*\n" ; logger "[+]: $*" ; }
quit()  { if [ ! -z "$1" ]; then printf "[\033[0;31m!\033[0m] \033[0;31m%s\033[0m\n" "$*" ; logger "$*" ; exit 2 ; fi }

### Variables
DATE=$(date +%Y-%m-%d)
DIR="7x_chef-backup-${DATE}"
LOG="/dev/null"

if [[ ${1} == "DEBUG" ]] ; then
  LOG="./chef_backup.log"
fi


### Code
print "Exporting Chef Data:"
knife backup export -D ${DIR} >> ${LOG} 2>&1

print "Export Complete, Starting To Compressing File"
tar -zcf ${DIR}.tgz ${DIR} >> ${LOG} 2>&1 

print "Compression Complete, Cleaning up Directory"
rm -rf "${DIR}" >> ${LOG} 2>&1 

print "Backup Job Complete, Copying File to NAS for backups!"
md5sum ${DIR}.tgz >> ${LOG} 2>&1 ; ls -alsh ${DIR}.tgz >> ${LOG} 2>&1 
smbclient -U Administrator@ttnet.local%TTNET\$999nt //119.0.203.250/Chef-Backups -c "put ${DIR}.tgz" >> ${LOG} 2>&1 

print "Cleaning up stale backups (Older then 7 Days)"
find /home/chef_backup -iname "7x_chef-backup-*.tgz" -mtime +7 -print -exec rm -rf '{}' \; >> ${LOG} 2>&1 

print "Everything complete!!!"

exit 0
