The tools here require:

http://172.17.250.250/syseng/informatica-mtools-0.1.0-1.el6.x86_64.rpm
http://172.17.250.250/syseng/mtools-tools.tar.gz