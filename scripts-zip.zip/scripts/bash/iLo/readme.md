### pull_ver_ilo.sh

This script is to cycle through the hosts on a subnet and validate what version of the ilo firmware is installed. There are two flags to use:

```bash
[!] Usage pull_ver_ilo.sh
     -u (iLo User) <word> ***
     -p (iLo Pass) <word> ***
     -e (environment tt=10, 7x=119) <int> ***
     -d (datacenter) <int> ***
     -i (ilo) <int> ***
     -s (start) <int> ***
     -f (finish) <int> ***
     -t (target ver) <string>


     (*** Required Fields)
```

```bash
[+] Host - iLo Version
=======================================
[+] 10.142.8.31 - 2.55
[+] 10.142.8.32 - 2.55
[+] 10.142.8.33 - 2.55
[+] 10.142.8.34 - 2.55
[+] 10.142.8.35 - 2.55
[+] 10.142.8.36 - 2.55
[+] 10.142.8.37 - 2.55
[+] 10.142.8.38 - 2.55
```

#### Required Packages:
* [python-hpilo](https://github.com/seveas/python-hpilo)