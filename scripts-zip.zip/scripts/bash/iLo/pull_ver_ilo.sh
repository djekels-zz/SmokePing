#!/usr/bin/env bash

# Program Name: pull_ver_ilo.sh
# Author Name : Jeremy M. <j@trade.tt>
# Created On  : Jan 8 2018
# Purpose     : Connect to iLo API and pull the current version for entire subnet.
# Requirements : python-hpilo (https://github.com/seveas/python-hpilo) - pip install python-hpilo
#----------------------------------------------------------------------------------

print() { printf "[\033[0;34m+\033[0m] $*\n" ; }
usage() { printf "[\033[0;31m!\033[0m] \033[0;31mUsage\033[0m \033[1;32m%s \n\t -u (iLo User) <word> *** \n\t -p (iLo Pass) <word> *** \n\t -e (environment tt=10, 7x=119) <int> *** \n\t -d (datacenter) <int> ***\n\t -i (ilo) <int> ***\n\t -s (start) <int> ***\n\t -f (finish) <int> ***\n\t -t (target ver) <string> \n\t -x (Only Show out of date) \n\n\n\t \033[0;31m(*** Required Fields)\033[0m\n\n" "$0" ; exit 2 ; }
quit()  { if [ ! -z "$1" ]; then printf "[\033[0;31m!\033[0m] \033[0;31m%s\033[0m\n" "$*" ; exit 2 ; fi }


while getopts 'u:p:e:d:i:s:f:t:h:x' flag; do
  options_found=1
  case "${flag}" in
    u)
      USR=${OPTARG} ;;
    p)
      PASS=${OPTARG} ;;
    e)
      if [[ ! -z ${OPTARG##[0-9]*} ]] ; then
        quit "Please provide proper environment (first) octet."
      else
        ENV=${OPTARG}
      fi
      ;;
    d)
      if [[ ! -z ${OPTARG##[0-9]*} ]] ; then
        quit "Please provide proper datacenter (second) octet."
      else
        DC=${OPTARG}
      fi
      ;;
    i)
      if [[ ! -z ${OPTARG##[0-9]*} ]] ; then
        quit "Please provide proper ilo (third) octet."
      else
        ILO=${OPTARG}
      fi
      ;;
    s)
      if [[ ! -z ${OPTARG##[0-9]*} ]] ; then
        quit "Please provide proper start (fourht) octet."
      else
        START=${OPTARG}
      fi
      ;;
    f)
      if [[ ! -z ${OPTARG##[0-9]*} ]] ; then
        quit "Please provide proper end (fourth) octet."
      else
        FINISH=${OPTARG}
      fi
      ;;
    t)
      TAR=${OPTARG} ;;
    x)
      EXC=true ;;
    \?)
      usage
      ;;
  esac
done

if ((!options_found)); then
  usage
fi

if [[ -z ${ENV} ]] || [[ -z ${DC} ]] || [[ -z ${ILO} ]] || [[ -z ${START} ]] || [[ -z ${FINISH} ]] ; then
  usage
fi

print "Host - iLo Version"
echo "======================================="
for i in $(seq 31 254) ; do
  host="${ENV}.${DC}.${ILO}.${i}"
  if [[ $(ping -c1 "${host}") ]] ; then
    output=$(hpilo_cli -l "${USR}" -p "${PASS}" "${host}" get_fw_version 2>&1) ; status=$?
    ver=$(echo "${output}" | grep firmware_version | awk -F : '{print $2}' | awk -F \, '{print $1}' | sed -e "s/'//g" | tr -d ' ')
    if [[ ${status} == 0 ]] ; then
      if [[ ! -z ${EXC} ]] ; then
        if [[ ! -z "${TAR}" ]] && [[ "${ver}" != "${TAR}" ]] ; then
          print "${host} - ${ver}"
        fi
      else
        if [[ ! -z "${TAR}" ]] && [[ "${ver}" == "${TAR}" ]] ; then
          ver="\033[0;32m${ver}\033[0m"
        elif [[ -z "${TAR}" ]] ; then
          ver="\033[0;32m${ver}\033[0m"
        else
          ver="\033[0;31m${ver}\033[0m"
        fi
        print "${host} - ${ver}"
      fi    
    fi
  fi
done