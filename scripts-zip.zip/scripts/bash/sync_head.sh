#!/bin/bash
#dn: cn=replica,cn=dc\3Dint\2Cdc\3Dtt\2Cdc\3Dlocal,cn=mapping tree,cn=config


ldapmodify -v -D "cn=directory manager" -y /etc/dirsrv/slapd-chidir01/dman.txt <<EOF
dn: cn=AD-repl-agreement,cn=replica,cn=dc\3Dint\2Cdc\3Dtt\2Cdc\3Dlocal,cn=mapping tree,cn=config
changetype: modify
replace: nsds5beginreplicarefresh
nsds5beginreplicarefresh: start
EOF
