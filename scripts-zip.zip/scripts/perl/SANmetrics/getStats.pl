#! /usr/bin/perl

use warnings;
use strict;
use HPSD::WSAPI;
use HPSD::WSAPI::Errcodes ':apiCodes';
use HPSD::WSAPI::Enums;
use Getopt::Long;
use Data::Dumper;
use ServiceNow::Simple;
use Date::Simple qw(date);
use YAML::XS qw/LoadFile/;
use Path::Class qw( file );

my $path = file($0)->absolute->dir;
my $kcpath = $path;
$kcpath=~ s/\/SANmetrics//g;
my $configfile = "$kcpath/Spacewalk/etc/kickstart_config.yml";
my $config = LoadFile($configfile);
my @k = keys %$config;

my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
$year += 1900;
my @abbr = qw(Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec);
my $dmon = $mon +1;
if($dmon<10) {$dmon="0".$dmon;}
if($mday<10) {$mday="0".$mday;}

my $date="$year-$dmon-$mday";

$ENV{PERL_LWP_SSL_VERIFY_HOSTNAME} = 0;
$ENV{'HTTP_PROXY'} = undef;
$ENV{'HTTPS_PROXY'} = undef;

########### SERVICE NOW HOOK ######
my $sn = ServiceNow::Simple->new({
	instance => 'tradingtech',
	user => 'svc_ws_readwrite',
	password => '9USTAsat',
	table => 'u_san_metrics'
});

my @hosts = ('10.206.8.10', '10.204.8.10', '10.102.8.10', '10.111.8.10', '10.113.8.10','10.127.8.10','10.143.8.10', '10.144.8.10');
#my @hosts = ('10.206.8.10', '10.204.8.10');
#my @hosts = ('10.111.8.10');
my $user="apiuser";
my $pass="apiuser";
my $dncnt=-1;
my @didnotrun=();
foreach my $hostname (@hosts) {
	#### GET DATACENTER #####
	my $datacenter="";
	my ($a,$b,$c,$d)=split(/\./,$hostname);
	foreach my $item (@k) {
		my $config=();
		$config = LoadFile($configfile);
		$config = \%{$config->{$item}};
		my $sitenet=$config->{'sitenet'};
		if (defined $sitenet) {
			if($sitenet eq "$a.$b") {
				$datacenter = getDCid($item);
			}
		}
	}
	my $ws = HPSD::WSAPI->new();
	my $rc = $ws->authenticate( sys      => $hostname,
	                            user     => $user,
	                            password => $pass,
	                            ssl      => 1 );
	if($rc != "201") {
		print "Failed to log into $hostname ($rc)\n";
		$dncnt++;
		$didnotrun[$dncnt]="$hostname";
		next;
	}
	$ws->getSpace();
	my $spaceInfo = $ws->getJsonHash();
	my $cnt=0;
	my @stuff=();
	foreach (%{$spaceInfo->{'allCapacity'}}) {
		$stuff[$cnt]=$_;
		$cnt++;
	}
	$cnt=0;
	my $totalMib = $stuff[9];
	my $freeMib = $stuff[11];
	my $pct = 100-($freeMib/$totalMib*100);

#	print "$hostname: $totalMib - $freeMib - $pct\n";

	$ws->getSystemInfo() != 200 && die makeErr("failed to get system info", $ws);
	my ($response, $sysinfo);
	$response = $ws->getJsonHash();
	$sysinfo = ($response);
	my $name = $sysinfo->{name};
	my $model = $sysinfo->{model};
	my $serial = $sysinfo->{serialNumber};
	my $nodes = $sysinfo->{totalNodes};
	my $sysver = $sysinfo->{systemVersion};

	my $result = $sn->insert({
		u_hostname=>$hostname,
		u_totalmib=>$totalMib,
		u_freemib=>$freeMib,
		u_percent=>$pct,
		u_snapdate=>$date,
		u_name=>$name,
		u_model=>$model,
		u_serial=>$serial,
		u_totalnodes=>$nodes,
		u_systemversion=>$sysver,
		u_datacenter=>$datacenter
	});
	$ws->finish()
}
if($dncnt>-1) {
	print "Sleeping 10 minutes to retry";
	sleep 600;
foreach my $hostname (@didnotrun) {
	#### GET DATACENTER #####
	my $datacenter="";
	my ($a,$b,$c,$d)=split(/\./,$hostname);
	foreach my $item (@k) {
		my $config=();
		$config = LoadFile($configfile);
		$config = \%{$config->{$item}};
		my $sitenet=$config->{'sitenet'};
		if (defined $sitenet) {
			if($sitenet eq "$a.$b") {
				$datacenter = getDCid($item);
			}
		}
	}
	my $ws = HPSD::WSAPI->new();
	my $rc = $ws->authenticate( sys      => $hostname,
	                            user     => $user,
	                            password => $pass,
	                            ssl      => 1 );
	if($rc != "201") {
		print "Failed to log into $hostname ($rc)\n";
		next;
	}
	$ws->getSpace();
	my $spaceInfo = $ws->getJsonHash();
	my $cnt=0;
	my @stuff=();
	foreach (%{$spaceInfo->{'allCapacity'}}) {
		$stuff[$cnt]=$_;
		$cnt++;
	}
	$cnt=0;
	my $totalMib = $stuff[9];
	my $freeMib = $stuff[11];
	my $pct = 100-($freeMib/$totalMib*100);

#	print "$hostname: $totalMib - $freeMib - $pct\n";

	$ws->getSystemInfo() != 200 && die makeErr("failed to get system info", $ws);
	my ($response, $sysinfo);
	$response = $ws->getJsonHash();
	$sysinfo = ($response);
	my $name = $sysinfo->{name};
	my $model = $sysinfo->{model};
	my $serial = $sysinfo->{serialNumber};
	my $nodes = $sysinfo->{totalNodes};
	my $sysver = $sysinfo->{systemVersion};

	my $result = $sn->insert({
		u_hostname=>$hostname,
		u_totalmib=>$totalMib,
		u_freemib=>$freeMib,
		u_percent=>$pct,
		u_snapdate=>$date,
		u_name=>$name,
		u_model=>$model,
		u_serial=>$serial,
		u_totalnodes=>$nodes,
		u_systemversion=>$sysver,
		u_datacenter=>$datacenter
	});
	$ws->finish()
}

}

sub getDCid {
        my @sid = @_;
        my $dcid="";
        my $siteid=$sid[0];
        my $sn = ServiceNow::Simple->new({
                instance => 'tradingtech',
                user => 'svc_ws_readwrite',
                password => '9USTAsat',
                table => 'cmdb_ci_datacenter',
        });
        my $results = $sn->get_records({
                u_debesys_abbreviation => $siteid,
                __columns => "name",
        });
        my @data = @{ $results->{rows} };
        foreach my $item (@data) {
                $dcid = $item->{name};
        }
        return $dcid;
}

