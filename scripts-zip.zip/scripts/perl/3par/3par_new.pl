use warnings;
use strict;
use HPSD::WSAPI;
use HPSD::WSAPI::Errcodes ':apiCodes';
use HPSD::WSAPI::Enums;
use Getopt::Long;

#Defaults
my %opts = ( san      => '',
             user     => '3paradm',
             password => '',
             hostname => '',
             cpgname  => 'FC_r5',
             size_GiB => '50' );

#CLI options
my %getopts = ();
Getopt::Long::GetOptions( \%opts,
                          'san=s',
                          'user=s',
                          'password=s',
                          'hostname=s',
                          'cpgname=s',
                          'size_GiB=s',
                          'help!' );
if($opts{help})
{
    HELP_MESSAGE();
    exit 1;
}
unless( $opts{san} && $opts{user} && $opts{password}
        && $opts{hostname} && $opts{cpgname} && $opts{size_GiB} )
{
    HELP_MESSAGE();
    exit 2;
}

my $ws = HPSD::WSAPI->new();
my $hostname = $opts{hostname};
my $rc = $ws->authenticate( sys      => $opts{san},
                            user     => $opts{user},
                            password => $opts{password},
                            ssl      => 1 );
if($rc != 201)
{
        print 'Failed to authenticate: ' . $ws->getErrInfo()->{desc} . "\n";
        exit(3);
}

$rc = $ws->createHost( { name    => $hostname,
                         persona => HPSD::WSAPI::HOST::GENERIC,
                         iSCSINames => [ "iqn.1994-05.com.domain:$hostname" ] } );
if($rc != 201)
{
    print 'Host creation failed: ' . $ws->getErrInfo()->{desc} . "\n";
    exit(4);
}

$rc = $ws->createVolume( { name    => "$hostname-root",
                           cpg     => $opts{cpgname},
                           sizeMiB => $opts{size_GiB} * 1024,
                           tpvv    => $JSON::true } );
if($rc != 201)
{
    print 'Volume creation failed: ' . $ws->getErrInfo()->{desc} . "\n";
    exit(5);
}

$rc = $ws->createVlun( { volumeName => "$hostname-root",
                         hostname   => $hostname,
                         lun        => 0,
                         maxAutoLun => 16863,
                         autoLun    => $JSON::true } );
if($rc != 201)
{
    print 'VLUN creation failed: ' . $ws->getErrInfo()->{desc} . "\n";
    exit(6);
}

my $auto_id = (split /,/, $ws->getLocation())[1];
unless( $auto_id => 0 && $auto_id <= 16863 )
{
    print 'Auto LUN id not assigned: ' . $ws->getErrInfo()->{desc} . "\n";
    exit(7);
}


sub HELP_MESSAGE
{
    print <<"EOM";
$0 - Create a new LUN for a host

--san       SAN address (required)
--user      SAN user (default: $opts{user})
--password  SAN password (required)
--hostname  Name of connecting host (required)
--cpgname   Name of common provisioning group (default: $opts{cpgname})
--size_GiB  Size of new volume (default: $opts{size_GiB})
--help      Show this message

EOM
}
