#!/usr/bin/perl
use strict;
use warnings;
use VMware::VIRuntime;
use VMware::VILib;

$ENV{PERL_LWP_SSL_VERIFY_HOSTNAME} = 0;
$ENV{'HTTP_PROXY'} = undef;
$ENV{'HTTPS_PROXY'} = undef; 

my %opts = (
	hostname => {
		type => "=s",
		help => "Name of the VM as labeled within vCenter",
		required => 1,
	},
	vmnetname => {
		type => "=s",
		help => "Name of the port group on the VDS Switch (VLAN).  You can also define 'all' to receive a bulk response.",
		required => 0,
	}
);
Opts::add_options(%opts);
Opts::parse();
Opts::validate();

my $hostname = "";
my $vmnetname = "";
$hostname = Opts::get_option('hostname');
$vmnetname = Opts::get_option('vmnetname');
if($vmnetname eq "") {$vmnetname = "ALL";}

Util::connect();

###################### FIND PORT GROUP KEY FROM VM ##############################
my $vm_view = Vim::find_entity_views(view_type => 'VirtualMachine', filter => {'name' => $hostname},);

foreach(@$vm_view) {
	my $displayname = $_->summary->config->name;
	my $devices = $_->config->hardware->device;
	my $disk_string;
	foreach(@$devices) {
		if($_->deviceInfo->label=~ m/Network adapter/) {
			my $mac = uc $_->{'macAddress'};
			my $vmportgroupkey =uc $_->backing->port->portgroupKey;
			my $DVPG;
			if($vmnetname ne "ALL") {
				$DVPG = Vim::find_entity_views(view_type => 'DistributedVirtualPortgroup', filter => {'name' => $vmnetname});
				foreach(@$DVPG) {
					my $portgroupname = uc $_->{'name'};
					my $portgroupkey = uc $_->{'key'};
					if($vmportgroupkey eq $portgroupkey) {
						print "$mac";
					}
				}
			}
			else {
				$DVPG = Vim::find_entity_views(view_type => 'DistributedVirtualPortgroup');
				foreach(@$DVPG) {
					my $portgroupname = uc $_->{'name'};
					my $portgroupkey = uc $_->{'key'};
					if($vmportgroupkey eq $portgroupkey) {
						my ($junk,$pgshort)=split(/VLAN/,$portgroupname);
						print "$pgshort\t$mac\n";
					}
				}
			}
		}
	}
}

Util::disconnect();
exit 0;
