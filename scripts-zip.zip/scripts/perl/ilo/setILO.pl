#setILO.pl
#
# Changelog:
#
#   v2.1.0 | 10/06/10 (JT): Changelog added.
#   v2.2.0 | 10/06/10 (JT): Major rewrite.  Modularized components, incorporated all batch file tasks
#                       into this script.  x64 support added.
#   v2.3.0 | 10/06/10 (JT): G5 is actually ilo2, changed mapped drive to unc path, NA is now ilo-NA
#   v2.3.1 | 03/23/11 (JT): Added DNS server and domain suffix to ilo2_s2_netset and ilo1_s2_netset
#   v2.3.2 | 04/11/11 (JT): Script now executes batch file for installing programs necessary to HP SIM
#   v2.4.0 | 03/06/12 (JT): Added high performance mouse parameter
#
# Current Issues:
#   see bug report emails
#   
# TODO:
#
#  


$| = 1;

our $VERSION = '2.4.0';

use strict;
use logster ':ALL';
use Sys::Hostname;
use File::Copy;
use Win32::IPConfig;
use Win32::OLE qw(in with);


my @MGMT_OCTETS              = ('254', '28', '29', '30', '31');
my @start_time               = localtime(time); $start_time[5] += 1900; $start_time[4] += 1;
my $installer_path           = 'c:\temp\ilo\iLO-install';
my $rem_installer_path       = '\\\\192.168.254.16\\spie\\iLO';
my $HPSIM_rem_installer_path = '\\\\192.168.254.20\\reimage\\software\\WMIMapper';
my $rem_touch_path           = '\\\\192.168.254.16\\spie\\iLO\\touched';
my $volatile_path            = 'c:\temp\ilo';
my $rem_log_path             = '\\\\192.168.254.16\\spie\\iLO\\logs';
my $logpath                  = 'c:\temp\ilo';
my $log_filename             = 'ilo-' . hostname . '.log';
my $static_path              = 'c:\temp';
my $version_filename         = 'iLO-version.txt';
my $before_filename          = 'setILO.before.' . hostname . '.txt';
my $after_filename           = 'setILO.after.' . hostname . '.txt';
my $HPSIM_filename           = 'INST_WMIMapper.bat';
my $touch_filename           = sprintf("%4d%02d%02d_%02d%02d%02d", @start_time);
$touch_filename             .= " - " . hostname;

print "$touch_filename\n\n\n\n";

my $NEEDS_UNMOUNT = 0;
my $NEEDS_CLEANUP = 0;

my $ipconfig;           #handle for ipconfig instance (object)
my $ilo_hostname;       #hostname for ilo (string)
my $ilo_ip;             #ip addr for ilo (string)
my $ilo_gw;             #gw addr for ilo (string)
my $system_model;       #model of current system
my $system_arch;
my @mgmt_ips;           #ip addr for managment (string)
my @ipaddrs = ();       #ip addresses extracted from ipconfig object (string array)
my $firmware_filename = undef;
my $driver_filename = undef;
my $hponcfg_filename = undef;




set_debug_level(L_DEBUG);

#Make sure directory where we log to exists
#
unless(-d $logpath)
{
    print logmsg(L_DEBUG, "(main) creating logfile directory");
    mkdir($logpath);
}
$NEEDS_CLEANUP = 1;


log_to_file("$logpath\\$log_filename");
set_file_debug_level(L_DEBUG);


#Mount remote directory with installers
#
#print logmsg(L_INFO, "(main) mounting installer directory");
#if(mount_remote($rem_installer_path, $drive_letter))
#{
#    print logmsg(L_CRITICAL, "(main) could not mount remote directory");
#    ilo_exit();
#}
#$NEEDS_UNMOUNT = 1;


#Check if we need to run the script
#
print logmsg(L_INFO, "(main) Checking version");
if(check_version("$static_path\\$version_filename"))
{
    print logmsg(L_INFO, "(main) can't continue on version, exiting");
    ilo_exit();
}


#Run installers for programs required by HP Systems Insight Manager
#
print logmsg(L_INFO, "(main) Installing HP SIM software");
print logmsg(L_DEBUG, "(main) Path: $HPSIM_rem_installer_path\\\\$HPSIM_filename");
print logmsg(L_DEBUG, "(main) Batch output: ");
print logmsg_nostamp(L_DEBUG, install($HPSIM_rem_installer_path, $HPSIM_filename));



#Get target system info
#
print logmsg(L_INFO, "(main) fetching system info");
($system_model, $system_arch, $ilo_ip) = get_sysinfo(hostname);

unless($system_model && $system_arch && $ilo_ip)
{
    print logmsg(L_CRITICAL, "(main) invalid system info");
    ilo_exit();
}
if($system_model eq 'ilo-NA')
{
    print logmsg(L_INFO, "(main) invalid machine type, exiting");
    write_version("$static_path\\$version_filename", 'ilo-NA');
    ilo_exit();
}
$ilo_hostname = 'ilo-' . hostname;
my @octets = split /\./, $ilo_ip;
$ilo_ip = "10.0.$octets[2].$octets[3]";
$ilo_gw = "10.0.$octets[2].1";

print logmsg(L_DEBUG, "(main) ilo_hostname: $ilo_hostname");
print logmsg(L_DEBUG, "(main) ilo_ip:       $ilo_ip");
print logmsg(L_DEBUG, "(main) ilo_gw:       $ilo_gw");


#Copy appropriate installers, build directories if appropriate
#
unless(-d $volatile_path)
{
    print logmsg(L_DEBUG, "(main) creating installer directory");
    mkdir($volatile_path);
}
if(copy_installers($system_model, $system_arch, $rem_installer_path))
{
    print logmsg(L_CRITICAL, "(main) could not copy installers");
    ilo_exit();
}


#Get installer filenames
#
my $DIR;
opendir($DIR, $volatile_path);
while(my $file = readdir $DIR)
{
    if($file =~ m/FIRMWARE/)
    {
        $firmware_filename = $file;
        print logmsg(L_DEBUG, "(main) using firmware installer: $firmware_filename");
    }
    elsif($file =~ m/DRIVER/)
    {
        $driver_filename = $file;
        print logmsg(L_DEBUG, "(main) using driver installer: $driver_filename");
    }
    elsif($file =~ m/HPONCFG/)
    {
        $hponcfg_filename = $file;
        print logmsg(L_DEBUG, "(main) using hponcfg installer: $hponcfg_filename");
    }
}
closedir($DIR);
unless(defined $firmware_filename)
{
    print logmsg(L_CRITICAL, "(main) could not locate firmware installer");
    ilo_exit();
}
unless(defined $driver_filename)
{
    print logmsg(L_CRITICAL, "(main) could not locate driver installer");
    ilo_exit();
}
unless(defined $hponcfg_filename)
{
    print logmsg(L_CRITICAL, "(main) could not locate hponcfg installer");
    ilo_exit();
}


#Install software
#
foreach($firmware_filename, $driver_filename, $hponcfg_filename)
{
    print logmsg(L_INFO, "(main) installing $_");
    my $ret = install($volatile_path, $_, '/s');  #no error checking on installation
    print logmsg(L_DEBUG, "(main) install returns: $ret");
}


#Write ilo config files
#
if($system_model eq 'G6' or $system_model eq 'G1' or $system_model eq 'G5')
{
    print logmsg(L_INFO, "(main) writing ilo2 config files");
    if(write_iLO2($ilo_hostname, $ilo_ip, $ilo_gw, $volatile_path))
    {
        print logmsg(L_CRITICAL, "(main) could not write ilo config files");
        ilo_exit();
    }
}
elsif($system_model eq 'G4')
{
    print logmsg(L_INFO, "(main) writing ilo1 config files");
    if(write_iLO1($ilo_hostname, $ilo_ip, $ilo_gw, $volatile_path))
    {
        print logmsg(L_CRITICAL, "(main) could not write ilo config files");
        ilo_exit();
    }
}
else
{
    write_version("$static_path\\$version_filename", 'ilo-NA');
    ilo_exit();
}


#Extract non-modified ilo configuration
#
print logmsg(L_INFO, "(main) extracting current ilo configuration");
fetch_iLO_config("$volatile_path\\setILO.before." . hostname . ".txt");


#Write new ilo configuration
#
print logmsg(L_INFO, "(main) writing new configuration to ilo");
put_iLO_config($volatile_path);


#Extract updated ilo configuration
#
print logmsg(L_INFO, "(main) extracting modified ilo configuration");
fetch_iLO_config("$volatile_path\\setILO.after." . hostname . ".txt");

write_version("$static_path\\iLO-version.txt", $VERSION);
ilo_exit();





#-----------------------------------------------------------------------------------------------


sub check_version
{
    if(@_ < 1)
    {
        print logmsg(L_ERROR, "(check_version) malformed request");
        return 1;
    }    
    my $file = shift;
    my $version;
    
    open(FILE, "<$file")
        or print logmsg(L_DEBUG, "(check_version) version file does not exist")
        and return 0;
    chomp($version = <FILE>);
    close FILE;
    
    if(not defined $version)
    {
        print logmsg(L_WARNING, "(check_version) version not defined");
        return 0;
    }
    
    print logmsg(L_DEBUG, "(check_version) version: $version");
    if($version =~ m/ilo-NA/)
    {
        print logmsg(L_DEBUG, "(check_version) nonapplicable machine type");
        return 1;
    }
    elsif($version gt $VERSION)
    {
        print logmsg(L_WARNING, "(check_version) version on target is greater than script");
        return 1;
    }
    elsif($version eq $VERSION)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}


sub clean_up
{
    my $DIR;
    
    print logmsg(L_DEBUG, "(clean_up) copying previous ilo config over");
    unless(copy("$volatile_path\\$before_filename", "$rem_installer_path\\backup_configs"))
    {
        print logmsg(L_WARNING, "(clean_up) could not copy previous ilo config: $!");
        print logmsg(L_WARNING, "(clean_up) saving locally to $static_path");
        
        unless(copy("$volatile_path\\$before_filename", $static_path))
        {
            print logmsg(L_ERROR, "(clean_up) could not copy previous ilo config, config not saved");
            print logmsg(L_ERROR, "(clean_up) $!");
        }
    }
    print logmsg(L_DEBUG, "(clean_up) copying new ilo config over");
    unless(copy("$volatile_path\\$after_filename", "$rem_installer_path\\backup_configs"))
    {
        print logmsg(L_WARNING, "(clean_up) could not copy new ilo config: $!");
        print logmsg(L_WARNING, "(clean_up) saving locally to $static_path");
        
        unless(copy("$volatile_path/$after_filename", $static_path))
        {
            print logmsg(L_ERROR, "(clean_up) could not copy new ilo config, config not saved");
            print logmsg(L_ERROR, "(clean_up) $!");
        }
    }
    
    print logmsg(L_DEBUG, "(clean_up) leaving touched files for verification");
    open(TEMPFILE, ">$volatile_path\\$touch_filename");
    print TEMPFILE "$VERSION";
    close TEMPFILE;
    unless(copy("$volatile_path\\$touch_filename", $rem_touch_path))
    {
        print logmsg(L_WARNING, "(clean_up) could not copy touch file: $!");
        print logmsg(L_WARNING, "(clean_up) saving locally to $static_path");
        
        unless(copy("$logpath\\$touch_filename", $static_path))
        {
            print logmsg(L_ERROR, "(clean_up) could not copy touch file, logfile not saved");
            print logmsg(L_ERROR, "(clean_up) $!");
        }
    }
    
    
    print logmsg(L_DEBUG, "(clean_up) copying log over");
    stop_log_to_file();
    
    #NOTE: All logging to disk is stopped after this point
    
    unless(copy("$logpath\\$log_filename", $rem_log_path))
    {
        print logmsg(L_WARNING, "(clean_up) could not copy logfile: $!");
        print logmsg(L_WARNING, "(clean_up) saving locally to $static_path");
        
        unless(copy("$logpath\\$log_filename", $static_path))
        {
            print logmsg(L_ERROR, "(clean_up) could not copy logfile, logfile not saved");
            print logmsg(L_ERROR, "(clean_up) $!");
        }
    }
    
    
    print logmsg(L_DEBUG, "(clean_up) removing files");
    opendir($DIR, $volatile_path)
        or print logmsg(L_WARNING, "(clean_up) could not open directory: $volatile_path");
    while(my $file = readdir $DIR)
    {
        if($file eq '.' or $file eq '..')
        {
            next;
        }
        unless(unlink("$volatile_path/$file"))
        {
            print logmsg(L_WARNING, "(clean_up) could not delete file: $file");
        }
    }
    closedir($DIR);
    
    print logmsg(L_DEBUG, "(clean_up) Removing directory");
    unless(rmdir $volatile_path)
    {
        print logmsg(L_WARNING, "(clean_up) could not delete directory: $volatile_path");
    }
}


sub copy_installers
{
    if(@_ < 3)
    {
        print logmsg(L_ERROR, "(copy_installers) malformed request");
        return 1;
    }
    my $model = shift;
    my $arch = shift;
    my $path = shift;
    my $file;
    my $DIR;
    
    
    if($model eq 'G6' or $model eq 'G1')
    {
        $model = 'ilo2';
    }
    elsif($system_model eq 'G5' or $system_model eq 'G4')
    {
        $model = 'ilo1';
    }
    
    
    print logmsg(L_DEBUG, "(copy_installers) Copying $model installer(s)");
    opendir($DIR, "$path/$model")
        or print logmsg(L_ERROR, "Could not open directory: $path/$model")
        and return 1;
    while($file = readdir($DIR))
    {
        if($file eq '.' or $file eq '..')
        {
            next;
        }
        unless(copy("$path/$model/$file", $volatile_path))
        {
            print logmsg(L_ERROR, "(copy_installers) Could not copy $model specific installer(s): $file");
            print logmsg(L_ERROR, "  $!");
            return 1;
        }
    }
    closedir($DIR);

    print logmsg(L_DEBUG, "(copy_installers) Copying $arch installer(s)");
    opendir($DIR, "$path/$arch")
        or print logmsg(L_ERROR, "Could not open directory: $path/$arch")
        and return 1;
    while($file = readdir($DIR))
    {
        if($file eq '.' or $file eq '..')
        {
            next;
        }
        unless(copy("$path/$arch/$file", $volatile_path))
        {
            print logmsg(L_ERROR, "(copy_installers) Could not copy $arch specific installer(s): $file");
            print logmsg(L_ERROR, "  $!");
            return 1;
        }
    }
    closedir($DIR);
    
    return 0;
}


sub fetch_iLO_config
{
    my $path = shift;
    
    install('c:\Program Files\HP\hponcfg', 'hponcfg.exe', "/a /w $path");
}


sub get_sysinfo
{
    if(@_ < 1)
    {
        print logmsg(L_ERROR, "(get_sysinfo) malformed request");
        return 1;
    }    
    my $hostname = shift;
    
    my $model;
    my $arch;
    my $mgmt_ip;
    my $services;
    my $sysset;
    my $got_one;
    
    my $WMI = Win32::OLE->new('WbemScripting.SWbemLocator')
        or print logmsg(L_ERROR, "(get_sysinfo) Could not create OLE object")
        and return 1;
    my $ipconfig = Win32::IPConfig->new($hostname)
        or print logmsg(L_ERROR, "(get_sysinfo) Could not create ipconfig object")
        and return 1;
    
    $services = $WMI->ConnectServer($hostname);
    $sysset   = $services->InstancesOf("Win32_ComputerSystem");
    
    foreach(in($sysset))
    {
        $model = $_->{'model'};
        $arch = $_->{'systemtype'};
    }
    
    unless($model)
    {
        print logmsg(L_ERROR, "Model not found");
    }
    unless($arch)
    {
        print logmsg(L_ERROR, "Architecture not found");
    }
    
    print logmsg(L_DEBUG, "(get_sysinfo) model: $model");
    print logmsg(L_DEBUG, "(get_sysinfo) arch: $arch");
    
    if($model =~ m/G1/)
    {
        $model = 'G1';
    }
    elsif($model =~ m/G4/)
    {
        $model = 'G4';
    }
    elsif($model =~ m/G5/)
    {
        $model = 'G5';
    }
    elsif($model =~ m/G6/)
    {
        $model = 'G6';
    }
    else
    {
        $model = 'ilo-NA';
    }
    
    if($arch =~ m/x86/i)
    {
        $arch = 'x86';
    }
    elsif($arch =~ m/x64/i)
    {
        $arch = 'x64';
    }
    else
    {
        $arch = 'ilo-NA';
    }
    
    
    foreach($ipconfig->get_adapters)
    {
        push @ipaddrs, $_->get_ipaddresses;
    }
     
    $got_one = 0;
    foreach my $ip (@ipaddrs)
    {
        my @octets = split(/\./, $ip);
        foreach(@MGMT_OCTETS)
        {
            #print logmsg(L_DEBUG, "$octets[2] eq $_");
            if($octets[2] eq $_)
            {
                $got_one++;
                $mgmt_ip = $ip;
            }
        }
    }
    if($got_one > 1)
    {
        print logmsg(L_WARNING, "(get_sysinfo) found more than one management IP: @ipaddrs");
    }
    elsif(!$got_one)
    {
        print logmsg(L_ERROR, "(get_sysinfo) no management interfaces found in: @ipaddrs");
    }
    else
    {
        print logmsg(L_DEBUG, "(get_sysinfo) management IP: $mgmt_ip");
    }
    
    return $model, $arch, $mgmt_ip;
}


sub ilo_exit
{
    if($NEEDS_CLEANUP)
    {
        clean_up();
    }
    #if($NEEDS_UNMOUNT)
    #{
    #    print logmsg(L_INFO, "(ilo_exit) unmounting remote directory");
    #    if(unmount_remote($drive_letter))
    #    {
    #        print logmsg(L_ERROR, "(ilo_exit) could not unmount remote directory");
    #    }
    #}
    
    exit;
}


sub install
{
    if(@_ < 2)
    {
        print logmsg(L_ERROR, "(install) malformed request");
        return 1;
    }
    my $path = shift;
    my $file = shift;
    my $options = shift || '';
    my $tasks = ();
    my $output;
    
    print logmsg(L_DEBUG, "(install) beginning install on: $file");
    print logmsg(L_DEBUG, "(install) string: $path\\$file $options");
    $output = `\"$path\\$file\" $options 2>&1`;
    
    $tasks = `tasklist`;
    while($tasks =~ m/$file/)
    {
        sleep 3;
        $tasks = `tasklist`;
    }
    print logmsg(L_DEBUG, "(install) $file complete");
    
    return $output;
}


sub mount_remote
{
    if(@_ < 2)
    {
        print logmsg(L_ERROR, "(mount_remote) malformed request");
        return 1;
    }
    my $path = shift;
    my $letter = shift;
    my $ret;
    
    $ret = (system("net use $letter: $path /yes 1>nul 2>&1")) >> 8;
    
    if($ret == -1)
    {
        print logmsg(L_ERROR, "(mount_remote) system call failed: $!");
        return 1;
    }
    elsif($ret == 2)
    {
        print logmsg(L_ERROR, "(mount_remote) drive letter in use");
        return 1;
    }
    elsif($ret)
    {
        print logmsg(L_ERROR, "(mount_remote) unknown error mouting drive"); 
    }
    
    return 0;
}

sub put_iLO_config
{
    if(@_ < 1)
    {
        print logmsg(L_ERROR, "(put_iLO_config) malformed request");
    }
    my $path = shift;
    my @files;
    my $DIR;
    my $ret;
    
    opendir($DIR, $path)
        or print logmsg(L_ERROR, "(put_iLO_config) could not open directory: $path")
        and return 1;
    while(my $file = readdir $DIR)
    {
        if($file eq '.' or $file eq '..')
        {
            next;
        }
        
        if($file =~ m/s[0-9]\.txt/)
        {
            push @files, $file;
        }
    }
    closedir($DIR);
    
    print logmsg(L_DEBUG, "(put_iLO_config), resetting ilo");
    $ret = install('C:\Program Files\HP\hponcfg', 'hponcfg.exe', '/reset');
    print logmsg(L_DEBUG, "(put_iLO_config) install returns: $ret");
    
    @files = sort @files;
    foreach(@files)
    {
        print logmsg(L_DEBUG, "(put_iLO_config), putting file: $_");
        $ret = install('C:\Program Files\HP\hponcfg', 'hponcfg.exe', "/f c:\\temp\\ilo\\$_");
        print logmsg(L_DEBUG, "(put_iLO_config) install returns: $ret");
    }
    
}


sub unmount_remote
{
    if(@_ < 1)
    {
        print logmsg(L_ERROR, "(unmount_remote) malformed request");
    }
    my $letter = shift;
    my $ret;
    
    $ret = (system("net use $letter: /delete /yes 1>nul 2>&1")) >> 8;
    
    if($ret == -1)
    {
        print logmsg(L_ERROR, "(mount_remote) system call failed: $!");
        return 1;
    }
    elsif($ret)
    {
        print logmsg(L_ERROR, "(mount_remote) could not unmount drive");
        return 1;
    }
    return 0;
}


sub write_iLO1
{
    if(@_ < 4)
    {
        print logmsg(L_ERROR, "(write_iLO1) malformed request");
    }
    my $hostname = shift;
    my $ip = shift;
    my $gateway = shift;
    my $path = shift;
    
    open FILE, ">$path\\s1.txt"
        or logmsg(L_ERROR, "(write_iLO2) could not open a filehandle for ilo2_s1_activate")
        and return 1;
    print FILE ilo1_s1_activate();
    close FILE;
    
    open FILE, ">$path\\s2.txt"
        or logmsg(L_ERROR, "(write_iLO2) could not open a filehandle for ilo2_s2_netset")
        and return 1;
    print FILE ilo1_s2_netset($ilo_hostname, $ilo_ip, $ilo_gw);
    close FILE;
    
    open FILE, ">$path\\s3.txt"
        or logmsg(L_ERROR, "(write_iLO2) could not open a filehandle for ilo2_s3_global")
        and return 1;
    print FILE ilo1_s3_global();
    close FILE;
    
    open FILE, ">$path\\s4.txt"
        or logmsg(L_ERROR, "(write_iLO2) could not open a filehandle for ilo2_s4_directory")
        and return 1;
    print FILE ilo1_s4_directory();
    close FILE;
    
    open FILE, ">$path\\s5.txt"
        or logmsg(L_ERROR, "(write_iLO2) could not open a filehandle for ilo2_s5_snmp")
        and return 1;
    print FILE ilo1_s5_snmp();
    close FILE;
    
    open FILE, ">$path\\s6.txt"
        or logmsg(L_ERROR, "(write_iLO2) could not open a filehandle for ilo2_s6_2factor")
        and return 1;
    print FILE ilo1_s6_2factor();
    close FILE;
    
    open FILE, ">$path\\s7.txt"
        or logmsg(L_ERROR, "(write_iLO2) could not open a filehandle for ilo2_s7_power")
        and return 1;
    print FILE ilo1_s7_power();
    close FILE;
    
    open FILE, ">$path\\s8.txt"
        or logmsg(L_ERROR, "(write_iLO2) could not open a filehandle for ilo2_s8_user")
        and return 1;
    print FILE ilo1_s8_user();
    close FILE;

    
    return 0;
}


sub write_iLO2
{
    if(@_ < 4)
    {
        print logmsg(L_ERROR, "(write_iLO2) malformed request");
    }
    my $hostname = shift;
    my $ip = shift;
    my $gateway = shift;
    my $path = shift;
    
    open FILE, ">$path\\s1.txt"
        or logmsg(L_ERROR, "(write_iLO2) could not open a filehandle for ilo2_s1_activate")
        and return 1;
    print FILE ilo2_s1_activate();
    close FILE;
    
    open FILE, ">$path\\s2.txt"
        or logmsg(L_ERROR, "(write_iLO2) could not open a filehandle for ilo2_s2_netset")
        and return 1;
    print FILE ilo2_s2_netset($ilo_hostname, $ilo_ip, $ilo_gw);
    close FILE;
    
    open FILE, ">$path\\s3.txt"
        or logmsg(L_ERROR, "(write_iLO2) could not open a filehandle for ilo2_s3_global")
        and return 1;
    print FILE ilo2_s3_global();
    close FILE;
    
    open FILE, ">$path\\s4.txt"
        or logmsg(L_ERROR, "(write_iLO2) could not open a filehandle for ilo2_s4_directory")
        and return 1;
    print FILE ilo2_s4_directory();
    close FILE;
    
    open FILE, ">$path\\s5.txt"
        or logmsg(L_ERROR, "(write_iLO2) could not open a filehandle for ilo2_s5_snmp")
        and return 1;
    print FILE ilo2_s5_snmp();
    close FILE;
    
    open FILE, ">$path\\s6.txt"
        or logmsg(L_ERROR, "(write_iLO2) could not open a filehandle for ilo2_s6_2factor")
        and return 1;
    print FILE ilo2_s6_2factor();
    close FILE;
    
    open FILE, ">$path\\s7.txt"
        or logmsg(L_ERROR, "(write_iLO2) could not open a filehandle for ilo2_s7_power")
        and return 1;
    print FILE ilo2_s7_power();
    close FILE;
    
    open FILE, ">$path\\s8.txt"
        or logmsg(L_ERROR, "(write_iLO2) could not open a filehandle for ilo2_s8_user")
        and return 1;
    print FILE ilo2_s8_user();
    close FILE;
    
    open FILE, ">$path\\s9.txt"
        or logmsg(L_ERROR, "(write_iLO2) could not open a filehandle for ilo2_s9_sso")
        and return 1;
    print FILE ilo2_s9_sso();
    close FILE;
    
    return 0;
}


sub write_version
{
    if(@_ < 2)
    {
        print logmsg(L_ERROR, "(write_version) malformed request");
    }
    my $file = shift;
    my $write_buf = shift;
    
    open FILE, ">$file"
        or print logmsg(L_ERROR, "(write_version) Could not open version file: $file for writing")
        and return 1;
        
    print FILE "$write_buf";
    close FILE;
    
    return 0;
}




#------------------------------------------------------------------------------------



sub ilo1_s1_activate
{
    return ilo2_s1_activate();
}

sub ilo2_s1_activate
{
    return
qq(<RIBCL VERSION="2.0">
<LOGIN USER_LOGIN="admin" PASSWORD="password">
<RIB_INFO mode="write">
<LICENSE>
<ACTIVATE KEY="332C8TH76HGQNWX8PLGSJ49J6" />
</LICENSE>
</RIB_INFO>
</LOGIN>
</RIBCL>
);
};
 



sub ilo1_s2_netset
{
    my $hostname = shift;
    my $ip = shift;
    my $gateway = shift;
    
    return
qq(<RIBCL VERSION="2.0">
<LOGIN USER_LOGIN="admin" PASSWORD="password">

<RIB_INFO mode="write">

<MOD_NETWORK_SETTINGS>

                                <ENABLE_NIC VALUE="Y" />
                                <SHARED_NETWORK_PORT VALUE="N" />
                                <SHARED_NETWORK_PORT_VLAN VALUE="N" />
    
                                <SPEED_AUTOSELECT VALUE="N" />
                                <NIC_SPEED VALUE="100" />
                                <FULL_DUPLEX VALUE="Y" />
                                <DHCP_ENABLE VALUE="N" />
                               <DHCP_GATEWAY VALUE="Y" />
                                <DHCP_DNS_SERVER VALUE="Y" />
                               <DHCP_WINS_SERVER VALUE="Y" />
                                <DHCP_STATIC_ROUTE VALUE="Y" />
                                <DHCP_DOMAIN_NAME VALUE="Y" />
                                <REG_WINS_SERVER VALUE="Y" />
                                <REG_DDNS_SERVER VALUE="Y" />
                                <PING_GATEWAY VALUE="N" />
    
                                <IP_ADDRESS VALUE="$ip" />
                                <SUBNET_MASK VALUE="255.255.255.0" />
                                <GATEWAY_IP_ADDRESS VALUE="$gateway" />
                                <DNS_NAME VALUE="$hostname" />
                                <DOMAIN_NAME VALUE="ilo.pi.domain" />
                                <PRIM_DNS_SERVER VALUE="192.168.254.20" />
                                <SEC_DNS_SERVER VALUE="192.168.254.21" />


                                 <PRIM_WINS_SERVER VALUE="0.0.0.0" />
                                <SEC_WINS_SERVER VALUE="0.0.0.0" />
                                <STATIC_ROUTE_1 DEST="0.0.0.0" GATEWAY="0.0.0.0" />
                                <STATIC_ROUTE_2 DEST="0.0.0.0" GATEWAY="0.0.0.0" />
                                <STATIC_ROUTE_3 DEST="0.0.0.0" GATEWAY="0.0.0.0" />
</MOD_NETWORK_SETTINGS>
</RIB_INFO>

</LOGIN>
</RIBCL>
);
};

                #<SHARED_NETWORK_PORT VALUE="N" />
                #<VLAN_ENABLED VALUE="N" />
sub ilo2_s2_netset
{
    my $hostname = shift;
    my $ip = shift;
    my $gateway = shift;
    
    return 
qq(<RIBCL VERSION="2.0">
<LOGIN USER_LOGIN="admin" PASSWORD="password">

<RIB_INFO mode="write">

<MOD_NETWORK_SETTINGS>

                <ENABLE_NIC VALUE="Y" />
    
                <SPEED_AUTOSELECT VALUE="N" />
                <NIC_SPEED VALUE="100" />
                <FULL_DUPLEX VALUE="Y" />
                <DHCP_ENABLE VALUE="N" />
                <DHCP_GATEWAY VALUE="Y" />
                <DHCP_DNS_SERVER VALUE="Y" />
                <DHCP_WINS_SERVER VALUE="Y" />
                <DHCP_STATIC_ROUTE VALUE="Y" />
                <DHCP_DOMAIN_NAME VALUE="Y" />
                <REG_WINS_SERVER VALUE="Y" />
                <REG_DDNS_SERVER VALUE="Y" />
                <PING_GATEWAY VALUE="N" />
    
                <IP_ADDRESS VALUE="$ip" />
                <SUBNET_MASK VALUE="255.255.255.0" />
                <GATEWAY_IP_ADDRESS VALUE="$gateway" />
                <DNS_NAME VALUE="$hostname" />
                <DOMAIN_NAME VALUE="ilo.pi.domain" />
                <PRIM_DNS_SERVER VALUE="192.168.254.20" />
                <SEC_DNS_SERVER VALUE="192.168.254.21" />
                <PRIM_WINS_SERVER VALUE="0.0.0.0" />
                <SEC_WINS_SERVER VALUE="0.0.0.0" />
                <STATIC_ROUTE_1 DEST="0.0.0.0" GATEWAY="0.0.0.0" />
                <STATIC_ROUTE_2 DEST="0.0.0.0" GATEWAY="0.0.0.0" />
                <STATIC_ROUTE_3 DEST="0.0.0.0" GATEWAY="0.0.0.0" />
</MOD_NETWORK_SETTINGS>
</RIB_INFO>

</LOGIN>
</RIBCL>);
}





sub ilo1_s3_global
{
    return
qq(<RIBCL VERSION="2.0">
<LOGIN USER_LOGIN="admin" PASSWORD="password">

<RIB_INFO mode="write">

<MOD_GLOBAL_SETTINGS>

                                <SESSION_TIMEOUT VALUE="30" />
                                <ILO_FUNCT_ENABLED VALUE="Y" />
                                <F8_PROMPT_ENABLED VALUE="Y" />
                                <F8_LOGIN_REQUIRED VALUE="N" />
                                <REMOTE_CONSOLE_PORT_STATUS VALUE="2" />
                                <REMOTE_CONSOLE_ENCRYPTION VALUE="Y" />
                                <PASSTHROUGH_CONFIG VALUE="1" />
                                <HTTPS_PORT VALUE="443" />
                                <HTTP_PORT VALUE="80" />
                                <REMOTE_CONSOLE_PORT VALUE="2323" />
                                <TERMINAL_SERVICES_PORT VALUE="3389" />
                                <VIRTUAL_MEDIA_PORT VALUE="17988" />
                                <VSP_SOFTWARE_FLOW_CONTROL VALUE="N" />
                                <SSH_PORT VALUE="22" />
                                <SSH_STATUS VALUE="Y" />
                                <SERIAL_CLI_STATUS VALUE="3" />
                                <SERIAL_CLI_SPEED VALUE="1" />
                                <RAW_SERIAL_PORT VALUE="3002" />
                                <MIN_PASSWORD VALUE="8" />
                                <REMOTE_KEYBOARD_MODEL VALUE="US" />
                                <REMOTE_CONSOLE_ACQUIRE VALUE="N" />
                                <RBSU_POST_IP VALUE="Y" />
                                                <!--
                                                NOTE: Hponcfg reports "script failed" when "HIGH_PERFORMANCE_MOUSE" setting is
                                                attempted under the following conditions:
                                                1. When iLO Remote Console is open.
                                                The L_ERROR message displayed here will be "This setting cannot be changed
                                                while remote console is connected."
                                               2. When iLO Virtual Media is connected.
                                                The L_ERROR message displayed will be "This setting can not be changed
                                                while virtual media is connected."
                                                -->
                                <HIGH_PERFORMANCE_MOUSE VALUE="Y" />
</MOD_GLOBAL_SETTINGS>
</RIB_INFO>
</LOGIN>
</RIBCL>
);
}


sub ilo2_s3_global
{
    return
qq(<RIBCL VERSION="2.0">
	<LOGIN USER_LOGIN="admin" PASSWORD="password">
		<RIB_INFO mode="write">
			<MOD_GLOBAL_SETTINGS>

			<SESSION_TIMEOUT VALUE="30" />
			<ILO_FUNCT_ENABLED VALUE="Y" />
			<F8_PROMPT_ENABLED VALUE="Y" />
			<F8_LOGIN_REQUIRED VALUE="N" />
			<TELNET_ENABLE VALUE="N" />
			<PASSTHROUGH_CONFIG VALUE="1" />
			<HTTPS_PORT VALUE="443" />
			<HTTP_PORT VALUE="80" />
			<REMOTE_CONSOLE_PORT VALUE="2323" />
			<TERMINAL_SERVICES_PORT VALUE="3389" />
			<VIRTUAL_MEDIA_PORT VALUE="17988" />
			<SSH_PORT VALUE="22" />
			<CONSOLE_CAPTURE_PORT VALUE="17990" />
			<SHARED_CONSOLE_PORT VALUE="9300" />
			<RAWVSP_PORT VALUE="3002" />
			<VSP_SOFTWARE_FLOW_CONTROL VALUE="N" />
			<SSH_STATUS VALUE="Y" />
			<SERIAL_CLI_STATUS VALUE="3" />
			<SERIAL_CLI_SPEED VALUE="1" />
			<MIN_PASSWORD VALUE="8" />
			<AUTHENTICATION_FAILURE_LOGGING VALUE="3" />
			<REMOTE_KEYBOARD_MODEL VALUE="US" />
			<RBSU_POST_IP VALUE="Y" />
			
			<!--  
				NOTE: Hponcfg reports "script failed" when "HIGH_PERFORMANCE_MOUSE" setting is 
				attempted under the following conditions: 
				1. When iLO Remote Console is open. 
				The L_ERROR message displayed here will be "This setting cannot be changed 
				while remote console is connected." 
				2. When iLO Virtual Media is connected. 
				The L_ERROR message displayed will be "This setting can not be changed 
				while virtual media is connected." 
			-->
			
			<HIGH_PERFORMANCE_MOUSE VALUE="Y" />
			<REMOTE_CONSOLE_ACQUIRE VALUE="N" />
			<KEY_UP_KEY_DOWN VALUE="Y" />
			<CONSOLE_CAPTURE_ENABLE VALUE="N" />
			<CONSOLE_CAPTURE_BOOT_BUFFER_ENABLE VALUE="N" />
			<CONSOLE_CAPTURE_FAULT_BUFFER_ENABLE VALUE="N" />
			<INTERACTIVE_CONSOLE_REPLAY_ENABLE VALUE="N" />
			<CAPTURE_AUTO_EXPORT_ENABLE VALUE="N" />
			<CAPTURE_AUTO_EXPORT_LOCATION VALUE="http://192.168.1.1/folder/capture-PI30SERVER35-ilo.ilo" />
			<CAPTURE_AUTO_EXPORT_USERNAME VALUE="" />
			<CAPTURE_AUTO_EXPORT_PASSWORD VALUE="" />
			<SHARED_CONSOLE_ENABLE VALUE="N" />
			<ENFORCE_AES VALUE="N" />
			</MOD_GLOBAL_SETTINGS>
		</RIB_INFO>
	</LOGIN>
</RIBCL>);
}



sub ilo1_s4_directory
{
    return
qq(<RIBCL VERSION="2.0">
<LOGIN USER_LOGIN="admin" PASSWORD="password">

<RIB_INFO mode="write">
                
<DIR_INFO mode="write">
<MOD_DIR_CONFIG>
                                <DIR_AUTHENTICATION_ENABLED VALUE="N" />
                                <DIR_LOCAL_USER_ACCT VALUE="Y" />
                                <DIR_SERVER_ADDRESS VALUE="" />
                                <DIR_SERVER_PORT VALUE="636" />
                                <DIR_OBJECT_DN VALUE="" />
                                <DIR_USER_CONTEXT_1 VALUE="" />
                                <DIR_USER_CONTEXT_2 VALUE="" />
                                <DIR_USER_CONTEXT_3 VALUE="" />
                                <DIR_ENABLE_GRP_ACCT VALUE="N" />
</MOD_DIR_CONFIG>
</DIR_INFO>

</RIB_INFO>
</LOGIN>
</RIBCL>
);
};

sub ilo2_s4_directory
{
    return
qq(<RIBCL VERSION="2.0">
<LOGIN USER_LOGIN="admin" PASSWORD="password">

	<DIR_INFO mode="write">
		<MOD_DIR_CONFIG>
			<DIR_AUTHENTICATION_ENABLED VALUE="N" />
			<DIR_LOCAL_USER_ACCT VALUE="Y" />
			<DIR_SERVER_ADDRESS VALUE="" />
			<DIR_SERVER_PORT VALUE="636" />
			<DIR_OBJECT_DN VALUE="" />
			<DIR_USER_CONTEXT_1 VALUE="" />
			<DIR_USER_CONTEXT_2 VALUE="" />
			<DIR_USER_CONTEXT_3 VALUE="" />
			<DIR_ENABLE_GRP_ACCT VALUE="N" />
		</MOD_DIR_CONFIG>
	</DIR_INFO>

</LOGIN>
</RIBCL>);
}



sub ilo1_s5_snmp
{
    return
qq(<RIBCL VERSION="2.0">
<LOGIN USER_LOGIN="admin" PASSWORD="password">

<RIB_INFO mode="write">
                
                <MOD_SNMP_IM_SETTINGS>
<SNMP_ADDRESS_1 VALUE="" />
<SNMP_ADDRESS_2 VALUE="" />
<SNMP_ADDRESS_3 VALUE="" />
<RIB_TRAPS VALUE="N" />
<OS_TRAPS VALUE="N" />
<SNMP_PASSTHROUGH_STATUS VALUE="Y" />
<WEB_AGENT_IP_ADDRESS VALUE="" />
<CIM_SECURITY_MASK VALUE="3" />
</MOD_SNMP_IM_SETTINGS>

</RIB_INFO>

</LOGIN>
</RIBCL>
);
};

sub ilo2_s5_snmp
{
    return
qq(<RIBCL VERSION="2.0">
<LOGIN USER_LOGIN="admin" PASSWORD="password">

	<RIB_INFO mode="write">
		<MOD_SNMP_IM_SETTINGS>
		<SNMP_ADDRESS_1 VALUE="" />
		<SNMP_ADDRESS_2 VALUE="" />
		<SNMP_ADDRESS_3 VALUE="" />
		<RIB_TRAPS VALUE="N" />
		<OS_TRAPS VALUE="N" />
		<SNMP_PASSTHROUGH_STATUS VALUE="Y" />
		<WEB_AGENT_IP_ADDRESS VALUE="" />
		<CIM_SECURITY_MASK VALUE="3" />
		</MOD_SNMP_IM_SETTINGS>
	</RIB_INFO>

</LOGIN>
</RIBCL>);
}



sub ilo1_s6_2factor
{
    return
qq(<RIBCL VERSION="2.0">
<LOGIN USER_LOGIN="admin" PASSWORD="password">

<RIB_INFO mode="write">
                
                <MOD_TWOFACTOR_SETTINGS>
<AUTH_TWOFACTOR_ENABLE VALUE="N" />
<CERT_REVOCATION_CHECK VALUE="N" />
<CERT_OWNER_SUBJECT />
</MOD_TWOFACTOR_SETTINGS>

</RIB_INFO>

</LOGIN>
</RIBCL>
);
}

sub ilo2_s6_2factor
{
    return
qq(<RIBCL VERSION="2.0">
<LOGIN USER_LOGIN="admin" PASSWORD="password">

	<RIB_INFO mode="write">
		<MOD_TWOFACTOR_SETTINGS>
		<AUTH_TWOFACTOR_ENABLE VALUE="N" />
		<CERT_REVOCATION_CHECK VALUE="N" />
		<CERT_OWNER_SUBJECT />
		</MOD_TWOFACTOR_SETTINGS>
	</RIB_INFO>

</LOGIN>
</RIBCL>);
}



sub ilo1_s7_power
{
    return
qq(<RIBCL VERSION="2.0">
<LOGIN USER_LOGIN="admin" PASSWORD="password">

<SERVER_INFO mode="write">
<SET_HOST_POWER_SAVER HOST_POWER_SAVER="1" />
</SERVER_INFO>

</LOGIN>
</RIBCL>
);
}

sub ilo2_s7_power
{
    return
qq(<RIBCL VERSION="2.0">
<LOGIN USER_LOGIN="admin" PASSWORD="password">

	<SERVER_INFO mode="write">
		<SET_HOST_POWER_SAVER HOST_POWER_SAVER="4" />
		<SERVER_AUTO_PWR VALUE="No" />
		<SET_POWER_CAP POWER_CAP="0" />
	</SERVER_INFO>
	
</LOGIN>
</RIBCL>);
}



sub ilo1_s8_user
{
    return
qq(<RIBCL VERSION="2.0">
<LOGIN USER_LOGIN="admin" PASSWORD="password">

<USER_INFO mode="write">
<ADD_USER USER_NAME="ttadmxxx100" USER_LOGIN="ttadmxxx100" PASSWORD="Tt12345678">
<ADMIN_PRIV value="Y" />
<REMOTE_CONS_PRIV value="Y" />
<RESET_SERVER_PRIV value="Y" />
<VIRTUAL_MEDIA_PRIV value="Y" />
<CONFIG_ILO_PRIV value="Y" />
</ADD_USER>
</USER_INFO>

</LOGIN>
</RIBCL>
);
};

sub ilo2_s8_user
{
    return
qq(<RIBCL VERSION="2.0">
<LOGIN USER_LOGIN="admin" PASSWORD="password">

	<USER_INFO mode="write">
		<ADD_USER USER_NAME="ttadmxxx100" USER_LOGIN="ttadmxxx100" PASSWORD="Tt12345678">
		<ADMIN_PRIV value="Y" />
		<REMOTE_CONS_PRIV value="Y" />
		<RESET_SERVER_PRIV value="Y" />
		<VIRTUAL_MEDIA_PRIV value="Y" />
		<CONFIG_ILO_PRIV value="Y" />
		</ADD_USER>
	</USER_INFO>
	
</LOGIN>
</RIBCL>);
}

sub ilo2_s9_sso
{
    return
qq(<RIBCL VERSION="2.0">
<LOGIN USER_LOGIN="admin" PASSWORD="password">

	<SSO_INFO mode="write">
		<MOD_SSO_SETTINGS>
		<TRUST_MODE VALUE="DISABLED" />
		<USER_ROLE LOGIN_PRIV="Y" />
		<USER_ROLE REMOTE_CONS_PRIV="N" />
		<USER_ROLE RESET_SERVER_PRIV="N" />
		<USER_ROLE VIRTUAL_MEDIA_PRIV="N" />
		<USER_ROLE CONFIG_ILO_PRIV="N" />
		<USER_ROLE ADMIN_PRIV="N" />
		<OPERATOR_ROLE LOGIN_PRIV="Y" />
		<OPERATOR_ROLE REMOTE_CONS_PRIV="Y" />
		<OPERATOR_ROLE RESET_SERVER_PRIV="Y" />
		<OPERATOR_ROLE VIRTUAL_MEDIA_PRIV="Y" />
		<OPERATOR_ROLE CONFIG_ILO_PRIV="N" />
		<OPERATOR_ROLE ADMIN_PRIV="N" />
		<ADMINISTRATOR_ROLE LOGIN_PRIV="Y" />
		<ADMINISTRATOR_ROLE REMOTE_CONS_PRIV="Y" />
		<ADMINISTRATOR_ROLE RESET_SERVER_PRIV="Y" />
		<ADMINISTRATOR_ROLE VIRTUAL_MEDIA_PRIV="Y" />
		<ADMINISTRATOR_ROLE CONFIG_ILO_PRIV="Y" />
		<ADMINISTRATOR_ROLE ADMIN_PRIV="Y" />
		</MOD_SSO_SETTINGS>
	</SSO_INFO>

</LOGIN>
</RIBCL>);
}

