$computers = import-csv servers.csv
$plainpassword = 'TTNET$999nt'
$domainUser = "bank\Administrator"
$domainPass = $plainpassword | ConvertTo-SecureString -AsPlainText -Force
$domainCreds = new-object -typename System.Management.Automation.PSCredential -argumentlist $domainUser, $domainPass

foreach ($computer in $computers) {

	$hostname = $computer.Host
	$IP = $computer.IP

	$localUser = $hostname+"\Administrator"
	$localPass = $plainpassword | ConvertTo-SecureString -AsPlainText -Force
	$localCreds = new-object -typename System.Management.Automation.PSCredential -argumentlist $localUser, $localPass

	$domain = (Get-WmiObject win32_computersystem -ComputerName $IP -Credential $localcreds).domain
	#write-host $hostname ":" $domain
    
	if ($domain -ne "bank.ttnet.local") {
        Write-Host "Joining $hostname to the Bank domain"
	Add-Computer -ComputerName $IP -LocalCredential $localCreds -Domain "bank.ttnet.local" -Credential $domainCreds -Restart
	}
	else{
	write-host $hostname ": is already on the Bank domain"
	}
}