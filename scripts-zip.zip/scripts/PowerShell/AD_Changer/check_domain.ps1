$pass = 'TTNET$999nt'
$computers = Import-Csv servers.csv
$Hosts = $computers.Host
$IPs = $computers.IP


foreach ($computer in $computers) {
	$hostname = $computer.Host
	$IP = $computer.IP

	write-host $hostname" - "$IP

	$localUser = $hostname+"\Administrator"
	$localPass = $pass | ConvertTo-SecureString -AsPlainText -Force
	$localCreds = new-object -typename System.Management.Automation.PSCredential -argumentlist $localUser, $localPass
	Get-WmiObject win32_computersystem -ComputerName $IP -Credential $localcreds | select domain
	write-host `n
}
