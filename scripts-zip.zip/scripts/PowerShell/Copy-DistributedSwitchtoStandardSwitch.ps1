#requires -version 4
<#
.SYNOPSIS
    Clone dvswitch (Distributed virtual switch) portgroups to standard virtual switch.
.DESCRIPTION
    The Copy-DvsPortGroupToSSwitch cmdlet creates new standard switch named 'SvSwitch-NAME' on esxi host and clone portgroups from existing distributed standard switch and create it on 'SvSwitch-NAME'.
.PARAMETER vCenter
    Prompts you for vCenter server FQDN or IP address to connect, vc parameter is an alias, This value can be taken from pipline by property name.
.PARAMETER Cluster
    Make sure you type a valid ClusterName within the provided vCenter server. New vSwitch name 'SvSwitch-NAME' is created on all esxi hosts withing this cluster, and existing DvSwitch PortGroups cloned to newly vSwitch created.
.INPUTS
    VMware.VimAutomation.ViCore.Impl.V1.Inventory.ClusterImpl
    VMware.VimAutomation.Vds.Impl.V1.VmwareVDSwitchImpl
    VMware.VimAutomation.ViCore.Impl.V1.Host.Networking.VirtualPortGroupImpl
    VMware.VimAutomation.ViCore.Impl.V1.Host.Networking.VirtualSwitchImpl
.OUTPUTS
    VMware.VimAutomation.ViCore.Impl.V1.Host.Networking.VirtualPortGroupImpl
    VMware.VimAutomation.ViCore.Impl.V1.Host.Networking.VirtualSwitchImpl
.NOTES
  Version:        1.0
  Author:         Jeremy Alons
  Creation Date:  6/21/2018
  Purpose/Change: Clone or copy existing distributed virtual portgroups from dvswitch to Standard virtual switch
  Useful URLs: http://chidebvc01
.EXAMPLE
    PS C:\>.\Copy-DvsPortGroupToSSwitch.ps1 -vCenter chidebvc01 -Cluster "TT HK Infrastructure"

    This command connects to vcenter 'chidebvc01' and copies dvswitch portgroups to newly created Standard switch 
#>
[CmdletBinding(SupportsShouldProcess=$True,
    ConfirmImpact='Medium', 
    HelpURI='http://chidebvc01', 
    SupportsTransactions=$True)]
Param (
    [parameter(Position=0, Mandatory=$true, ValueFromPipelineByPropertyName=$true, HelpMessage='Type vCenter server IP or FQDN you want to connect')]
    [alias('vc')]
    [String]$vCenter,
    [parameter(Position=1, Mandatory=$true, ValueFromPipelineByPropertyName=$true, HelpMessage='Type valid datacenter name')]
    [alias('dc')]
    [String]$Datacenter,
    [parameter(Position=2, Mandatory=$true, ValueFromPipelineByPropertyName=$true, ValueFromPipeline=$true, HelpMessage='Type valid Cluster Name within vCenter server')]
    [alias('c')]
    [String]$Cluster
)
Begin {
#$Cluster = 'TT HK Infrastructure'
#$Datacenter= 'Debesys-HongKong'
    if ( -not (Get-Module  vmware.vimautomation.core)) {
        Import-Module vmware.vimautomation.core
        Import-Module vmware.vimautomation.vds
    }
}
Process {
    if ($global:DefaultVIServers.Name -notcontains $vCenter) {
        try {
            Connect-VIServer $vCenter -ErrorAction Stop
        }
        catch {
            Write-Host $($Error[0].Exception) -ForegroundColor Red
            break
        }
    }
    try {
        $ClusterInfo = Get-Cluster $cluster -ErrorAction Stop
        $DvSwitches = Get-VDSwitch -Location $Datacenter -ErrorAction Stop
    }
    catch {
        Write-Host $($Error[0].Exception) -ForegroundColor Red
        break
    }

    $AllEsxis = $ClusterInfo | Get-VMhost
    

    foreach ($esxi in $ALLEsxis) {

	foreach ($DVSwitch in $DVSwitches) {
		$DvSwitchInfo = Get-VDSwitch -Name $DVSwitch.Name -ErrorAction Stop
		$DvPortGroupInfo = $DvSwitchInfo | Get-VDPortgroup | Where-Object {$_.IsUplink -eq $false}

		$ExistingSwitchs = $esxi | Get-VirtualSwitch
		$esxiName = $esxi.name
		$SvSwitchName = 'SvSwitch-' + $DVSwitch.Name
		if ($ExistingSwitchs.Name -notcontains $SvSwitchName) {
		    $vSwitch = $esxi | New-VirtualSwitch -Name $SvSwitchName -Mtu $DvSwitchInfo.Mtu
		    $NvSwitchName = $vSwitch.Name
		    Write-Host "$([char]8734) " -ForegroundColor Magenta -NoNewline
		    Write-Host "Created $NvSwitchName on $esxiName" -BackgroundColor Magenta 
		    Foreach ($DvPortGroup in $DvPortGroupInfo) {
			$vPortGroupName = $DvPortGroup.Name
			$vLanID = $DvPortGroup.ExtensionData.Config.DefaultPortConfig.Vlan.VlanId
			$NewPortGroup = $vSwitch | New-VirtualPortGroup -Name $DvPortGroup.Name -VLanId $vLanID
			Write-Host "`t $([char]8730) " -ForegroundColor Green -NoNewline
			Write-Host "Created New PortGroup $vPortGroupName With vLanID $vLanID" -BackgroundColor DarkGreen
		    }
		}
		else {
		    Write-Host "$([char]215) " -ForegroundColor Red -NoNewline
		    Write-Host "SvSwitch100 already present on $esxiName skipping..." -BackgroundColor DarkRed 
		    Continue
		}
	}
    }
}
End {
    Disconnect-VIServer $vCenter -Confirm:$false
}
