#!/bin/bash
#
#	This script will allow you too apply TLS settings to listeners
#	ex: ./aws_elb_tls_change.sh poc us-east-1


#Addressing classic loadbalancers first

#Looping throught all each loadbalancer in the account
#and quering for Loadbalancer name
for i in $(aws elb describe-load-balancers --query 'LoadBalancerDescriptions[*].[LoadBalancerName]' --profile $1 --region $2 --output text);

do 
echo "[=====$i=====]";

#Once we have Each load balancer name we need to create load balancer ssl policy
#NOTE: Please change ELBSECURITYPOLICY-TLS-1-2-2017 for the latest policy
#
aws elb create-load-balancer-policy --load-balancer-name $i --policy-name TT-SSLNegotiation-policy-1-2-2017-01 --policy-type-name SSLNegotiationPolicyType --policy-attributes AttributeName=Reference-Security-Policy,AttributeValue=ELBSecurityPolicy-TLS-1-2-2017-01 --profile $1 --region $2; 

#apply TLS setting too each listnerer on port 443 per loadbalancer
aws elb set-load-balancer-policies-of-listener --load-balancer-name $i --load-balancer-port 443 --policy-names TT-SSLNegotiation-policy-1-2-2017-01 --profile $1 --region $2;

#Verify loadbalancer policy is correct
aws elb describe-load-balancers --load-balancer-name $i --query LoadBalancerDescriptions[*].[ListenerDescriptions[*]] --profile $1 --region $2 --output table;
printf "\n"

done | sed '/^\[$/d' | sed '/^    \[$/d' | sed '/        \[$/d' | sed '/^\]/d' | sed '/^    \]$/d' | sed '/^        \]$/d' | sed 's/^            //g'



##addressing application load balancers

#Loop through loadbalancers to grab name
for i in $(aws elbv2 describe-load-balancers --query 'LoadBalancers[*].[LoadBalancerName]' --profile $1 --output text --region $2)
do

echo "[=====$i=====]";
#set loadbalancerARN variable
elb_arn=$(aws elbv2 describe-load-balancers --names $i --query 'LoadBalancers[*].LoadBalancerArn' --profile $1 --output text --region $2)
#set listener variable
list_arn=$(aws elbv2 describe-listeners --load-balancer-arn $elb_arn --query 'Listeners[?Port==`443`].ListenerArn' --profile $1 --output text --region $2)

echo $elb_arn
echo $list_arn

echo -e "\n"

#Apply ssl policy to each listenerarn 
#NOTE:Please change --SSL-POLICY to latest ssl cert
# 
aws elbv2 modify-listener --listener-arn $list_arn --ssl-policy ELBSecurityPolicy-TLS-1-2-Ext-2018-06 --output table --profile $1 --region $2

done
