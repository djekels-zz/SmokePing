# TT Monitoring With Splunk

## Installation

Install the ttsplunk package via pip. This is 2.6 compliant, so install directly to system python.

Internal
```
sudo pip install -i https://pypi-dev.debesys.net/pypi ttsplunk
```

External
```
sudo pip install -i https://pypi.debesys.net/pypi ttsplunk
```

Run the Splunk install script.  If the node is not chef deployed, omit the chef args.

URL for deployment server is:
internal(default): `splunk-deployment-server-int.debesys.net`
external: `splunk-deployment-server.debesys.net`

```
sudo ttsplunk -n <hostname> -i <ip> -s <deployment_server_url> -d <data_center> -c <chef_environment> -r <run_list>
```

That's it!  Splunk should now be installed, running, and forwarding logs to the indexers.