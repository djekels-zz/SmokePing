"""setup.py

Setup this python app to be built.
"""
from codecs import open
from os import path
from setuptools import setup, find_packages

HERE = path.abspath(path.dirname(__file__))

# Get the long description from the README file
with open(path.join(HERE, 'README.md'), encoding='utf-8') as f:
    LONG_DESCRIPTION = f.read()

setup(
    name='ttsplunk',
    version='1.1.43',
    description='Trading Technologies - Splunk Modules',
    long_description=LONG_DESCRIPTION,
    url='https://github.com/tradingtechnologies/systems_engineering',
    author='Systems Engineering',
    author_email='syseng@tradingtechnologies.com',
    license='Proprietary. All Rights Reserved',
    keywords='monitoring splunk',     # What does your project relate to?
    include_package_data=True,
    packages=find_packages(exclude=['contrib', 'docs', 'tests'], include=['*']),
    install_requires=[
    ],

    # command line tool
    entry_points={
        'console_scripts': [
            'ttsplunk=ttsplunk.main:main'
        ]
    }
)
