#!/bin/env python

"""ttsplunk

App to install splunk universal forwarder on vm and bm hosts.
"""
import os
import logging
from logging.handlers import RotatingFileHandler
from .tools.splunk import do_work

def main():
    """
    Function: main
    Summary: Primary function definition.
    """
    debesys_log_dir = "/var/log/debesys"
    script_log_file = "{0}/ttsplunk.log".format(debesys_log_dir)
    max_logfile_size = 1024 * 1024 * 100
    max_logfile_count = 5

    # Setup logger
    log_format = '%(asctime)s.%(msecs).03d | %(levelname)-8s | %(message)s'
    date_format = '%Y-%m-%d %H:%M:%S'
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    formatter = logging.Formatter(fmt=log_format, datefmt=date_format)

    # Stdout logging
    handler = logging.StreamHandler()
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    # File logging
    if not os.path.exists(debesys_log_dir):
        os.makedirs(debesys_log_dir)
    fhandler = RotatingFileHandler(script_log_file, maxBytes=max_logfile_size,
                                   backupCount=max_logfile_count)
    fhandler.setFormatter(formatter)
    logger.addHandler(fhandler)

    do_work()
