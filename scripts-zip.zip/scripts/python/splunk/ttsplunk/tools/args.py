#!/bin/env python
"""args.py

Provides a platform to get and proces argv into variables that can be used elsewhere in the app.
"""
import optparse

def get_args():
    """
    Function: get_args
    Summary: Takes argv[] and converts to opt variable.
    Returns: options
    """
    parser = optparse.OptionParser(description="Splunk Universal Forwarder "
                                   "Install Script")
    parser.add_option("-n", "--name", help="Name of the node")
    parser.add_option("-i", "--ip-address", help="IP of the node")
    parser.add_option("-d", "--data-center", help="Name of the data center")
    parser.add_option("-c", "--chef-environment",
                      help="Name of the chef environment", default="none")
    parser.add_option("-r", "--run-list", help="Chef run list", default="none")
    parser.add_option("-s", "--deployment-server",
                      help="URL of the deployment server",
                      default="splunk-deployment-server-int.debesys.net")
    parser.add_option("--direct-download",
                      help="Download forwarder RPM from splunk.com instead "
                      "of TT repos.")
    (options, args) = parser.parse_args()

    return options
