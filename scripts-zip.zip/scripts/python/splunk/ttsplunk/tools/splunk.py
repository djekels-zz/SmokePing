#!/bin/env python

"""splunk

Splunk related def's
"""
import os
import shutil
import logging
import sys
import socket
from subprocess import Popen, PIPE
import rpm
from .args import get_args

LOGGER = logging.getLogger(__name__)

__all__ = [
    "DC_MAP",
    "install_splunk",
    "write_index_time_inputs",
    "write_splunk_alias",
    "write_deployment_client",
    "delete_old_files",
    "enable_boot_start",
    "restart_splunk",
    "uninstall_splunk",
    "stop_splunk",
    "kill_splunk",
    "package_version_check",
    "disable_boot_start"
]

DC_MAP = {
    # POC AWS
    "10.203.0": "poc-us-east-1",
    "10.203.2": "poc-us-east-1",
    "10.203.4": "poc-us-east-1",
    "10.203.9": "poc-us-east-1",

    "10.203.48": "poc-us-west-1",
    "10.203.50": "poc-us-west-1",
    "10.203.52": "poc-us-west-1",

    "10.203.80": "poc-ap-northeast-1",
    "10.203.82": "poc-ap-northeast-1",
    "10.203.84": "poc-ap-northeast-1",

    # PROD AWS
    "10.210.0": "ttnet-us-east-1",
    "10.210.2": "ttnet-us-east-1",
    "10.210.4": "ttnet-us-east-1",

    "10.213.0": "ttnet-eu-west-1",
    "10.213.2": "ttnet-eu-west-1",
    "10.213.4": "ttnet-eu-west-1",

    "10.215.0": "ttnet-ap-northeast-1",
    "10.215.2": "ttnet-ap-northeast-1",
    "10.215.4": "ttnet-ap-northeast-1",
}

SPLUNK_BIN = "/opt/splunkforwarder/bin/"
SPLUNK_CMD = "{0}/splunk".format(SPLUNK_BIN)

YUM_INSTALL = "/usr/bin/yum -y install {0}"
YUM_REMOVE = "/usr/bin/yum -y remove {0}"

RPM_VER = "7.2.4"
RPM_NAME = "splunkforwarder-7.2.4-8a94541dcfac-linux-2.6-x86_64.rpm"
RPM_URL = "http://download.splunk.com/products/universalforwarder/" \
"releases/7.2.4/linux/"

class SplunkRuntimeError(Exception):
    """
    SplunkRuntimeError

    Used for passing more detailed output in cases of errors.
    """
    pass

def do_work():
    # pylint: disable=trailing-whitespace
    """
    Function: do_work
    Summary: primary function for all the work in main()
    """
    logger = LOGGER

    opt = get_args()

    # These could all yield odd results, but if you're not passing it in
    # you get what you get
    if opt.name is None:
        opt.name = socket.gethostname().split(".")[0]

    if opt.ip_address is None:
        try:
            opt.ip_address = socket.gethostbyname(socket.gethostname())
        # The above doesn't work on ec2 for whatever reason, so just parse
        # it out of the name
        except socket.gaierror:
            if "ip" not in opt.name:
                logging.error("Could not get IP, please pass it explicitly")

            octets = opt.name.split("-")
            opt.ip_address = "{0}.{1}.{2}.{3}".format(octets[1], octets[2],
                                                      octets[3], octets[4])

    if opt.data_center is None:
        # Just removes the last octet
        key = opt.ip_address.rsplit('.', 1)[0]
        opt.data_center = DC_MAP.get(key, "unknown")

    # Splunk servers don't need the forwarder
    if "recipe[splunk2::" in opt.run_list:
        logger.info("This node is a Splunk server, removing the forwarder")
        if os.path.exists("/opt/splunkforwarder"):
            uninstall_splunk()
        sys.exit(0)

    logger.info("Installing Splunk with the following settings")
    logger.info("Hostname: %s", opt.name)
    logger.info("IP Address: %s", opt.ip_address)
    logger.info("Data Center: %s", opt.data_center)
    logger.info("Chef Environment: %s", opt.chef_environment)
    logger.info("Run List: %s", opt.run_list)
    logger.info("Deployment Server: %s", opt.deployment_server)

    # In days of old splunk used a bunch of other configs
    # that may still be around, so remove them
    delete_old_files()

    if package_version_check("splunkforwarder"):
        kill_splunk()
        disable_boot_start()
        install_splunk()
        enable_boot_start()

    write_splunk_alias()
    write_index_time_inputs(opt.name, opt.chef_environment, opt.ip_address, opt.data_center,
                            opt.run_list)
    write_deployment_client(opt.name, opt.deployment_server, opt.data_center,
                            opt.chef_environment, opt.run_list)
    start_splunk()


def run_command(cmd):
    # pylint: disable=trailing-whitespace
    """
    Function: run_command
    Summary: execute the command in question and return the output.
    Attributes:
        @param (cmd):Command to run.
    Returns: output from command that was executed.
    """

    results = Popen(cmd, shell=True, stdout=PIPE, stderr=PIPE)
    results.communicate()
    return results

def package_version_check(pkg_name):
    # pylint: disable=trailing-whitespace
    """
    Function: package_version_check
    Summary: Validate if the package is going to be upgraded
    Attributes:
    @param (pkg_name):RPM Package To Validate
    Returns: True|False Based on if the package should be upgraded or not.
    """
    logger = LOGGER
    trnset = rpm.TransactionSet() #pylint: disable=no-member
    rpm_match = trnset.dbMatch('name', pkg_name)
    try:
        match = rpm_match.next()
        return bool(RPM_VER != match['version'])

    except StopIteration:
        logger.info("Package Not Found")
        kill_splunk()
        disable_boot_start()
        install_splunk()
        enable_boot_start()

def install_splunk():
    """
    Function: install_splunk
    Summary: Install Splunk
    """

    logger = LOGGER

    if os.path.exists(SPLUNK_BIN):
        logger.info("Splunk already installed")
        return

    logger.info("Installing Splunk via yum")
    run = run_command(YUM_INSTALL.format("splunkforwarder"))

    if run.returncode == 0:
        logger.info("Splunk successfully installed via yum")
        return
    else:
        logger.warning(run.stdout)
        logger.warning(run.stderr)

    logger.info("Splunk yum install failed, attempting to download rpm")

    run = run_command("wget {0}/{1}".format(RPM_URL, RPM_NAME))

    if run.returncode != 0:
        logger.warning(run.stdout)
        logger.warning(run.stderr)
        logger.error("Could not download rpm")
        raise SplunkRuntimeError("Could not download rpm")

    run = run_command(YUM_INSTALL.format(RPM_NAME))

    if run.returncode == 0:
        logger.info("Splunk successfully installed via downloaded rpm")
        return
    else:
        logger.warning(run.stdout)
        logger.warning(run.stderr)
        logger.error("Could not install Splunk via downloaded rpm")
        raise SplunkRuntimeError("Install Splunk failed")


def uninstall_splunk():
    """
    Function: uninstall_splunk
    Summary: Uninstall Splunk Universal Forwarder
    """

    logger = LOGGER

    try:
        stop_splunk()
    except SplunkRuntimeError:
        pass

    run = run_command(YUM_REMOVE.format("splunkforwarder"))

    if run.returncode == 0:
        logger.info("Splunk successfully uninstalled")
    else:
        logger.warning(run.stdout)
        logger.warning(run.stderr)
        logger.error("Uninstall Splunk failed")
        raise SplunkRuntimeError("Uninstall Splunk failed")

    if os.path.isdir("/opt/splunkforwarder"):
        shutil.rmtree("/opt/splunkforwarder")

    profile_file = "/etc/profile.d/splunk.sh"
    if os.path.isfile(profile_file) or os.path.islink(profile_file):
        os.remove(profile_file)

    # You'd think yum would do this, but it doesn't.
    # We nee to delete this, because if the host was
    # bootstrapped as a generic host, the forwarder's
    # init script will be installed, and a subsequent
    # full splunk server install will not replace it.
    init_script = "/etc/init.d/splunk"
    if os.path.isfile(init_script) or os.path.islink(init_script):
        os.remove(init_script)


def write_index_time_inputs(hostname, chef_environment, ip_address, data_center, run_list):
    # pylint: disable=trailing-whitespace
    """
    Function: write_index_time_inputs
    Summary: Create the inputs.conf file on the client nodes.
    Attributes:
        @param (hostname):hostname we are installing on
        @param (chef_environment):chef_environment we are on
        @param (ip_address):local ip address
        @param (data_center):datacenter we are in
        @param (run_list):chef runlist for this node
    Returns: InsertHere
    """
    logger = LOGGER

    logger.info("Creating Splunk inputs config")

    inputs_template = (
        "[default]\n"
        "host = {hostname}\n"
        "_meta = node_chef_environment::{chef_environment} "
        "node_ip_address::{ip_address} "
        "node_data_center::{data_center} node_run_list::\"{run_list}\"\n"
    )

    inputs_text = inputs_template.format(hostname=hostname,
                                         chef_environment=chef_environment,
                                         ip_address=ip_address,
                                         data_center=data_center,
                                         run_list=run_list)

    with open("/opt/splunkforwarder/etc/system/local/inputs.conf", "w") as fle:
        fle.write(inputs_text)


def write_splunk_alias():
    """
    Function: write_splunk_alias
    Summary: write the splunk bash alias.
    """

    logger = LOGGER

    logger.info("Creating Splunk alias file")

    with open("/etc/profile.d/splunk.sh", "w") as fle:
        fle.write("alias splunk='sudo /opt/splunkforwarder/bin/splunk'")


def write_deployment_client(hostname, deployment_server_url, data_center,
                            chef_environment, run_list):
    # pylint: disable=trailing-whitespace
    """
    Function: write_deployment_client
    Summary: Write Deployment Client Configs
    Attributes:
        @param (hostname):hostname we are installing on
        @param (deployment_server_url):InsertHere
        @param (data_center):datacenter we are in
        @param (chef_environment):chef_environment we are on
        @param (run_list):chef runlist for this node
    """
    logger = LOGGER

    logger.info("Creating Splunk deployment client config")

    identifier = "UF"
    if "bankalgo" in run_list:
        identifier = "bankalgo-" + identifier

    deployment_template = (
        "[deployment-client]\n"
        "clientName = {identifier}-{hostname}-{data_center}-"
        "{chef_environment}\n"
        "\n"
        "[target-broker:deploymentServer]\n"
        "targetUri = {deployment_server}:8089\n"
    )

    deployment_text = \
        deployment_template.format(identifier=identifier,
                                   hostname=hostname,
                                   data_center=data_center,
                                   chef_environment=chef_environment,
                                   deployment_server=deployment_server_url)

    dpl_conf = "/opt/splunkforwarder/etc/system/local/deploymentclient.conf"
    with open(dpl_conf, "w") as fle:
        fle.write(deployment_text)


def delete_old_files():
    """
    Function: delete_old_files
    Summary: Remove files no longer in use.
    """

    logger = LOGGER

    logger.info("Deleting old Splunk configs")

    old_files = [
        '/opt/splunkforwarder/etc/system/local/outputs.conf',
        '/usr/local/bin/check_logs_growth.py',
        '/usr/sbin/check_logs_growth.py',
        '/opt/splunkforwarder/.FORWARDER_DISABLED'
    ]

    old_dirs = [
        "/opt/splunkforwarder/etc/apps/universal-forwarder-config",
        "/opt/splunkforwarder/etc/apps/bankalgo_inputs",
        "/opt/splunkforwarder/etc/apps/forwarder_inputs_perf_data",
        "/opt/splunkforwarder/etc/apps/forwarder_chef_log_files",
        "/opt/splunkforwarder/etc/apps/forwarder_limits",
        "/opt/splunkforwarder/etc/apps/forwarder_messages",
        "/opt/splunkforwarder/etc/apps/forwarder_sfptp_log_files",
        "/opt/splunkforwarder/etc/apps/forwarder_debesys_log_files"
    ]

    for fle in old_files:
        if os.path.exists(fle):
            os.remove(fle)

    for fldr in old_dirs:
        if os.path.isdir(fldr):
            shutil.rmtree(fldr)


def enable_boot_start():
    """
    Function: enable_boot_start
    Summary: Ensure splunk is setup to start at boot
    """

    logger = LOGGER

    logger.info("Enabling Splunk boot start")

    commands = [
        "{0} start --accept-license --no-prompt --answer-yes --seed-passwd ProbablyFixingSplunk",
        "{0} enable boot-start"
    ]

    if (os.path.exists('/etc/init.d/splunk')) or (os.path.exists(
            '/etc/systemd/system/SplunkForwarder.service')):
        logger.info("Already Enabled!!!")
    else:
        for cmd in commands:
            run = run_command(cmd.format(SPLUNK_CMD))

            if run.returncode != 0:
                logger.warning(run.stdout)
                logger.warning(run.stderr)
                logger.error("Enable boot start failed")
                raise SplunkRuntimeError("Enable boot start failed")

def disable_boot_start():
    """
    Function: disable_boot_start
    Summary: Disable splunk start on boot
    """

    logger = LOGGER

    logger.info("Disabling Splunk boot start")

    commands = [
        "{0} disable boot-start"
    ]

    if not (os.path.isfile('/etc/init.d/splunk')) or not (os.path.isfile(
            '/etc/systemd/system/Splunkd.service')):
        logger.info("Already Disabled!!!")
    else:
        for cmd in commands:
            run = run_command(cmd.format(SPLUNK_CMD))

            if run.returncode != 0:
                logger.warning(run.stdout)
                logger.warning(run.stderr)
                logger.error("Disable boot start failed")
                raise SplunkRuntimeError("Disable boot start failed")

def restart_splunk():
    """
    Function: restart_splunk
    Summary: Restart splunk
    """

    logger = LOGGER

    logger.info("Restarting Splunk")

    run = run_command("{0} restart".format(SPLUNK_CMD))

    if run.returncode != 0:
        logger.warning(run.stdout)
        logger.warning(run.stderr)
        logger.error("Splunk restart failed")
        raise SplunkRuntimeError("Splunk restart failed")

def start_splunk():
    """
    Function: start_splunk
    Summary: start splunk IF not already running
    """

    logger = LOGGER

    pid = run_command("pidof splunkd")
    if pid.returncode == 1:
        logger.info("Starting Splunk")

        run = run_command("{0} start --accept-license --no-prompt --answer-yes --seed-passwd ProbablyFixingSplunk".format(SPLUNK_CMD))

        if run.returncode != 0:
            logger.warning(run.stdout)
            logger.warning(run.stderr)
            logger.error("Splunk restart failed")
            raise SplunkRuntimeError("Splunk restart failed")


def stop_splunk():
    """
    Function: stop_splunk
    Summary: Stop Splunk Services
    """

    logger = LOGGER

    logger.info("Stopping Splunk")

    run = run_command("{0} stop".format(SPLUNK_CMD))

    if run.returncode != 0:
        logger.warning(run.stdout)
        logger.warning(run.stderr)
        logger.error("Splunk stop failed")
        raise SplunkRuntimeError("Splunk stop failed")

def kill_splunk():
    # pylint: disable=trailing-whitespace
    """
    Function: kill_splunk
    Summary: Kill splunk in the case stop and restart did not work.
    """

    logger = LOGGER

    logger.info("Killing Splunk")

    run = run_command("if [[ $(pgrep splunkd) ]] ; then killall -9 splunkd ; fi")

    if run.returncode != 0:
        logger.warning(run.stdout)
        logger.warning(run.stderr)
        logger.error("Splunk kill failed")
        raise SplunkRuntimeError("Splunk kill failed")
