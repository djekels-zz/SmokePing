import time
from boto.s3.connection import S3Connection



s3_conn = S3Connection(profile_name='ct')

ath_buck = s3_conn.get_bucket('athena-database-bucket')

logs_buck = s3_conn.get_bucket('s3-logs-ttnet-prod')

prefix = 'ttdiag-captures-eu-west-12017-08'
log_keys = logs_buck.list(prefix)
for lk in log_keys:
    count = 1
    copy = False
    while copy == False:
        wait = 1*count
        count += 1
        try:
            print lk.name
            lk.copy('athena-database-bucket',lk.name)
            copy = True
        except:
            time.sleep(wait)
            try:
                lk.copy('athena-database-bucket',lk.name)
                copy = True
            except Exception,e:
                print e
