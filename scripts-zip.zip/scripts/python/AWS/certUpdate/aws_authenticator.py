#!/usr/bin/env python2.7
# -*- mode: python -*-
import mechanize
from BeautifulSoup import BeautifulSoup
import os
from getpass import getpass
import sys
import boto
from boto.sts.connection import STSConnection
from boto.s3.connection import S3Connection
from boto.iam.connection import IAMConnection
import pickle
import urllib
import argparse

# Mapping role names to use.
AWS_ROLES = {
    'read': {
        'role' : 'Read'
    },
    'admin': {
        'role' : 'DevAdmins'
    },
    'dev': {
        'role' : 'Devs'
    },
    'beanstalk': {
        'role' : 'Elastic-Beanstalk'
    },
    'network': {
        'role' : 'NetworkAdmins'
    },
    'route53': {
        'role' : 'R53'
    },
    'Admins': {
        'role' : 'Admins'
    }
}

# Mapping the selected aws environment to account to use.
AWS_ACCOUNTS = {
    'it':  {
        'account_number': '022824216630',
        'account_prefix': 'ELS',
	    'account': 'it'
    },
    'deb':  {
        'account_number': '331560656580',
        'account_prefix': 'DEB',
	    'account': 'deb'
    },
    'prod':  {
        'account_number': '464154314123',
        'account_prefix': 'PROD',
	    'account': 'prod'
    },
}

def add_argparse_arguments(argument_parser):
    auth_options = argument_parser.add_argument_group("AWS authorization (optional)")
    auth_options.add_argument("--aws-access-key-id", default=None)
    auth_options.add_argument("--aws-secret-access-key", default=None)
    auth_options.add_argument("--aws-session-token",  default=None)

def interactive_login(*args, **kwargs):
    cli_args = kwargs.pop('cli_args', None)
    if not cli_args.aws_access_key_id or not cli_args.aws_secret_access_key:
        return AwsAuthenticator(*args, **kwargs).getKeys()
    else:
        return {
            "aws_access_key_id": cli_args.get('aws_access_key_id'),
            "aws_secret_access_key": cli_args.get('aws_secret_access_key'),
            "security_token": cli_args.get('aws_session_token')
        }

# Building Authenticator Class
class AwsAuthenticator():
    def __init__(self, username=None, password=None, account="it", role="read", role_arn=None,
                 username_prompt='Enter your INTAD username:',
                 password_prompt=None):
        self.adfs_url = "https://ttsts1.tradingtechnologies.com/adfs/ls/IdpInitiatedSignOn.aspx"
        self.saml_url_base = "https://ttsts1.tradingtechnologies.com"
        self.saml_response = None
        self.username = username
        self.password = password
        self.username_prompt = username_prompt
        self.password_prompt = password_prompt

        if not account in AWS_ACCOUNTS.keys():
            raise Exception("invalid account specified")

        self.aws_account_number = AWS_ACCOUNTS[account]["account_number"]
        self.aws_account_prefix = AWS_ACCOUNTS[account]["account_prefix"]
        self.aws_account = AWS_ACCOUNTS[account]["account"]
        self.aws_role = AWS_ROLES[role]["role"]
        self.role_arn = role_arn
        self.keys_file = os.path.expanduser("~/.aws-keys_{0}_{1}".format(account, role))

    def deleteKeysFile(self):
        if os.path.isfile(self.keys_file):
            os.remove(self.keys_file)

    # Prompts for Creds if needed
    def promptCreds(self):
        username = os.getenv('INTAD_USER')
        if not username:
            username = raw_input(self.username_prompt)

        if not self.password_prompt:
            prompt = "Enter your password for INTAD user {0}:".format(username)
        else:
            prompt = self.password_prompt
        password = getpass(prompt)
        self.username = username
        self.password = password

    # Checks if old keys exist and attempts s3 connection. If they are expired or do not exist, will prompt for creds
    def GetCachedKeys(self):
        if os.path.isfile(self.keys_file):
            f = open(self.keys_file)
            keys = pickle.load(f)
            f.close()

            keysValid = True
            for key in ["aws_access_key_id", "aws_secret_access_key", "security_token"]:
                if not key in keys.keys():
                    keysValid = False

            if keysValid:
                key_id = keys["aws_access_key_id"]
                access_key = keys["aws_secret_access_key"]
                token = keys["security_token"]
                s3_connection = S3Connection(
                        aws_access_key_id=key_id,
                        aws_secret_access_key=access_key,
                        security_token=token
                )
                try:
                    s3_connection.get_all_buckets()
                    return keys
                except:
                    return None
            else:
                return None
        else:
            if os.path.isfile("~/.aws-keys_{0}_admin".format(self.aws_account)):
                self.keys_file = os.path.expanduser("~/.aws-keys_{0}_admin".format(self.aws_account))
                if os.path.isfile(self.keys_file):
                    f = open(self.keys_file)
                    keys = pickle.load(f)
                    f.close()

                    keysValid = True
                    for key in ["aws_access_key_id", "aws_secret_access_key", "security_token"]:
                        if not key in keys.keys():
                            keysValid = False

                    if keysValid:
                        key_id = keys["aws_access_key_id"]
                        access_key = keys["aws_secret_access_key"]
                        token = keys["security_token"]
                        s3_connection = S3Connection(
                            aws_access_key_id=key_id,
                            aws_secret_access_key=access_key,
                            security_token=token
                        )
                        try:
                            s3_connection.get_all_buckets()
                            return keys
                        except:
                            return None
                    else:
                        return None
                else:
                    return None
            else:
                return None

    # Heavy Lifting to get SAML Response via terminal web browse with Mechanize
    def getSamlResponse(self):
        haveLoginInfo = True
        if not self.username:
            sys.stderr.write("error: no username specified")
            haveLoginInfo = False
        if not self.password:
            sys.stderr.write("error: no password specified")
            haveLoginInfo = False

        if not haveLoginInfo:
            raise Exception("missing login info")

        br = mechanize.Browser()
        br.open(self.adfs_url)
        br.select_form(nr=0)
        br.form["ctl00$ContentPlaceHolder1$group1"] = ["OtherRpRadioButton"]
        '''
        In the event that we add another service to ADFS and AWS is no longer the default option, uncomment the line below to set the drop-down list to AWS.
        We were unable to find any way around this with Mechanize.  The site uses javascript, which Mechanize doesn't support, to enable the drop-down list.
        Other automated browsing like selenium that support javascript don't support full html responses that are required for this use case.
        '''
        #br.form["ctl00$ContentPlaceHolder1$RelyingPartyDropDownList"] = ["urn:amazon:webservices"]

        br.submit()

        html = br.response().read()
        parsed = BeautifulSoup(html)

        tag = parsed.findAll('form', {'name':'aspnetForm'})
        for elem in tag:
            resp = elem['action']

        saml_url = self.saml_url_base+resp
        br.open(saml_url)

        br.select_form(nr=0)

        br.form["ctl00$ContentPlaceHolder1$UsernameTextBox"] = self.username
        br.form["ctl00$ContentPlaceHolder1$PasswordTextBox"] = self.password
        br.submit()

        html = br.response().read()
        parsed = BeautifulSoup(html)
        authCheck = parsed.findAll('span', {'id':'ctl00_ContentPlaceHolder1_ErrorTextLabel'})
        counter = 0

        while len(authCheck) > 0 and counter < 5:
            counter += 1
            if counter == 4:
                raise Exception("Too many failed authentications; aws_authenticator.py cannot continue.")
            print 'Your INTAD authentication failed, please try again.'
            self.promptCreds()
            br.open(saml_url)
            br.select_form(nr=0)
            br.form["ctl00$ContentPlaceHolder1$UsernameTextBox"] = self.username
            br.form["ctl00$ContentPlaceHolder1$PasswordTextBox"] = self.password
            br.submit()
            html = br.response().read()
            parsed = BeautifulSoup(html)
            authCheck = parsed.findAll('span', {'id':'ctl00_ContentPlaceHolder1_ErrorTextLabel'})


        tag = parsed.findAll('input', {'name':'SAMLResponse'})
        for elem in tag:
            resp = elem['value']

        br.close()
        boto_v =  int(str(boto.Version).split('.')[1])
        if boto_v > 34:
            self.saml_response = resp
        else:
            self.saml_response = urllib.quote(resp.encode("utf-8"))

    # Uses SAML Response to assume role
    def assumeRole(self):
        # Assume Role from ADFS
        if self.role_arn == None:
            role_arn="arn:aws:iam::{0}:role/{1}-ADFS-{2}".format(self.aws_account_number, self.aws_account_prefix, self.aws_role)
        else:
            role_arn=self.role_arn
        principal_arn="arn:aws:iam::{0}:saml-provider/ADFS".format(self.aws_account_number)
        saml_assertion=self.saml_response
        duration_seconds="3600"


        try:
            sts_connection = STSConnection(anon=True)
        except:
            raise Exception("We were unable to open a connection to AWS with the Boto API; aws_authenticator cannot continue. Please check network connectivity to AWS.")

        try:
            assumedRoleObject = sts_connection.assume_role_with_saml(
                role_arn=role_arn,
                principal_arn=principal_arn,
                saml_assertion=saml_assertion,
                duration_seconds=duration_seconds)

        except:
            role_arn="arn:aws:iam::{0}:role/{1}-ADFS-DevAdmins".format(self.aws_account_number, self.aws_account_prefix)
            try:
                self.keys_file = os.path.expanduser("~/.aws-keys_{0}_admin".format(self.aws_account))

                assumedRoleObject = sts_connection.assume_role_with_saml(
                        role_arn=role_arn,
                        principal_arn=principal_arn,
                        saml_assertion=saml_assertion,
                        duration_seconds=duration_seconds)
            except:
	            raise Exception("You do not have appropriate permissions; aws_authenticator.py cannot continue. Please open a ticket via http://go/seek to get aws permissions")

        result = {
            'aws_access_key_id': assumedRoleObject.credentials.access_key,
            'aws_secret_access_key': assumedRoleObject.credentials.secret_key,
            'security_token': assumedRoleObject.credentials.session_token,
        }

        f = open(self.keys_file, 'w')
        pickle.dump(result, f)
        f.close()

        return result

    # Gets Key ID, Key, and Session Token. If they do not exist or are expired, prompt for creds and assume role.
    def getKeys(self):
        keys = self.GetCachedKeys()
        if keys:
            return keys

        self.promptCreds()
        self.getSamlResponse()
        return self.assumeRole()

    def getUser(self):
        return self.username

# Example inteface lists users in IAM account specified
if __name__ == "__main__":

    # User specifies what AWS account they want to run the task in.
    parser = argparse.ArgumentParser()
    parser.add_argument('--account', help="Select either: it, deb, or prod.")
    parser.add_argument('--env', action='store_true', default=False,
        help=("Print the shell commands to set your temporary access keys as "
        "environment variables. These environment variables are compatible "
        "with the AWS CLI. Try $(aws_authenticator --env) to load these variables "
        "into your current terminal session."))
    parser.add_argument('--role', default='read', help="Pass either read, dev, beanstalk, network, or admin")
    parser.add_argument('--role-arn', default=None, help="If the role you need is not supported by default, pass the full role arn from AWS")
    parser.add_argument('--boto', default=None, help="If you want to use this to export a profile to ~/.aws/credentials file, give a profile name and redirect (aws_authenticator.py --account --role --boto > ~/.aws/credentials) output to the file. Be careful not to overwrite current profiles. If you want to add a role with out clobbering the file use the append redirect (>>).")

    args = parser.parse_args()
    
    if args.role_arn != None:
        # If the user specified the ability to use a full AWS arn
        auth = AwsAuthenticator(account=args.account, role_arn=args.role_arn)
    else:
        # Passes account and role into AWS_Authenticator.
        # Specify what role is needed for specific task. Defaults to read only.
        auth = AwsAuthenticator(account=args.account, role=args.role)

    # Gets pertinent key information from AWS_Authenticator then runs AWS task.
    result = auth.getKeys()
    key_id = result["aws_access_key_id"]
    access_key = result["aws_secret_access_key"]
    token = result["security_token"]

    if args.env:
        print "export AWS_ACCESS_KEY_ID={0}".format(key_id)
        print "export AWS_SECRET_ACCESS_KEY={0}".format(access_key)
        print "export AWS_SESSION_TOKEN={0}".format(token)
        print "export AWS_ACCOUNT={0}".format(args.account)
        sys.exit(0)
    if args.boto:
        print "\n[{0}]".format(args.boto)
        print "aws_access_key_id = {0}".format(key_id)
        print "aws_secret_access_key =  {0}".format(access_key)
        print "aws_security_token = {0}".format(token)
        sys.exit(0)


    #Creates connection to IAM
    iam_connection = IAMConnection(
        aws_access_key_id=key_id,
        aws_secret_access_key=access_key,
        security_token=token)

    # Lists all buckets within specified AWS account
    users = iam_connection.get_all_users()
    for user in users.list_users_result.users:
        print user.user_name
