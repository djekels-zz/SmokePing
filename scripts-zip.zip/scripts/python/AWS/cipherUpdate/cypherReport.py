import boto3
import time
import argparse
import sys
import os
from pprint import pprint
from datetime import datetime
from aws_authenticator import AwsAuthenticator
from time import strptime,strftime


# Getting all ELBs depending on ELB version (classic or application) and returning them in an array
def get_elbs(elb_conn, elb_version):
    result = []
    if elb_version == 'elb':
        for page in elb_conn.get_paginator('describe_load_balancers').paginate():
            for elb in page['LoadBalancerDescriptions']:
                 #print elb['LoadBalancerName']
                 result.append(elb)
        return result
    elif elb_version == 'elbv2':
        for page in elb_conn.get_paginator('describe_load_balancers').paginate():
            for elb in page['LoadBalancers']:
                 #print elb['LoadBalancerName']
                 result.append(elb)
        return result
    else:
        sys.exit("Invalid elb version")

#For Application ELBs or elbv2, it was easier to get listeners in a speparate array
def get_listeners(elb_conn, elb_arn):
    result = []
    for page in elb_conn.get_paginator('describe_listeners').paginate(LoadBalancerArn=elb_arn):
        for listener in page['Listeners']:
             #print listener['ListenerArn']
             result.append(listener)
    return result

#Def for automated run using keys queried from LDAP to check if there is a new SSL cipher available and notify Sys Eng for manual run of the script
def check_new(curr_cipher,account):
    curr_cipher_date = strptime(curr_cipher.split("-")[1]+curr_cipher.split("-")[2]+"01","%Y%m%d")
    #query LDAP and Assume Role with keys
    cmd = "ldapsearch -H \"ldap://10.192.0.20\" -D \"cn=binduser,ou=ds-service-accounts,dc=int,dc=tt,dc=local\" -w \"Tt12345678\" -b \"dc=int,dc=tt,dc=local\" uid=aws-poc-it | grep ntUserParms"
    execute = os.popen(cmd,"r")
    output = execute.readline()
    aws_key = output.split(":")[1].strip()
    aws_secret = output.split(":")[2].strip()
    role = "arn:aws:iam::331560656580:role/role-it-elastic-lb-check"    
     
    sesh = boto3.Session(
        aws_access_key_id = aws_key,
        aws_secret_access_key = aws_secret)

    sts_conn = sesh.client('sts')
    #Assuming the role for the POC account so I can edit the buckets in that account
    role_assume = sts_conn.assume_role(
        RoleArn = role,
        RoleSessionName = "Session1",
        DurationSeconds = 900)
    #Rather than re-write ridic overly lengthy code to use boto3 to pull this information I am just writing temp creds to a profile that AWSCLI can use
    with open("/root/.aws/credentials","w") as f:
        f.write("[cipher]\n")
        f.write("aws_access_key_id = {0}\n".format(role_assume['Credentials']['AccessKeyId']))
        f.write("aws_secret_access_key =  {0}\n".format(role_assume['Credentials']['SecretAccessKey']))
        f.write("aws_security_token = {0}\n".format(role_assume['Credentials']['SessionToken']))
     
    cmd = 'aws elb describe-load-balancer-policies --query "PolicyDescriptions[?PolicyTypeName==\'SSLNegotiationPolicyType\'].{PolicyName:PolicyName}" --output text --profile cipher --region us-east-1'
    execute = os.popen(cmd,"r")
    output = execute.read()
    print output
    #Cycling through ciphers returned by AWSCLI run to see if any of them are newer than the one specified as param
    ciphers = output.strip().split("\n")
    for ciph in ciphers:
        if 'ELBSecurity' in ciph:
            if curr_cipher_date < strptime(ciph.split("-")[1]+ciph.split("-")[2]+"01","%Y%m%d"):
                print "Should be happening"
                ses_client = boto3.client(
                    'ses',
                    region_name = 'us-east-1',
                    aws_access_key_id=role_assume["Credentials"]["AccessKeyId"],
                    aws_secret_access_key=role_assume["Credentials"]["SecretAccessKey"],
                    aws_session_token=role_assume["Credentials"]["SessionToken"])

                ses_client.send_email(
                    Source='els@tradingtechnologies.com',
                    Destination={'ToAddresses':['syseng@trade.tt','sec_alerts@tradingtechnologies.com']},
                    Message={
                        'Subject': {
                            'Data': 'There is a new cipher available for ELBs in AWS',
                        },
                        'Body':{
                            'Html': {
                                'Data': '<html>\n\t<body>\n\t\tPlease see wiki <a href="https://tradingtech.atlassian.net/wiki/display/TT/Updating+AWS+ELB+Ciphers">article</a> on updating ciphers.\n\t</body>\n</html>',
                            }
                        }
                    }
                )

#Main portion of code starting with command line arguments
parser = argparse.ArgumentParser()
parser.add_argument('--policy', help='Please specify the name of the policy you want listener ciphers to use.')
parser.add_argument('--account', help='Please specify "deb" or "prod"')
parser.add_argument('--execute', action='store_true', default=False, help='Specify --execute to perform update of ciphers')
parser.add_argument('--check', default=False, help='Used to for automation to check if there is a newer cipher available provide current newest cipher')
args = parser.parse_args()

if not args.account:
    sys.exit("Please specify either \"deb\" or \"prod\" account")

#Check argument will be used for automated runs.  The chron job will need to be updated to run with the newest ELBSecurity name any time we manually update
if args.check:
    if len(args.check.split("-")) != 3:
        sys.exit("Does not match expected format of ELBSecurityPolicy-YYYY-MM")
    check_new(args.check,args.account)
    sys.exit()
else:
    #If this is not an automated run, then we will be checking to see if our ciphers are up to date.  Starting by see if you want to execute or not.  If you don't want to execute it prints a : seperated report that can be dumped into Google Sheets
    if not args.policy:
        sys.exit("Please specify the name of the policy you want listener ciphers to use.")
    if args.execute:
        role = "Admins"
        update_required = True
    else:
        role = "read"
        update_required = True
    #Using AD creds...would be runners of reports must have -AWS-Read AD Security Group for the desired account.  Runners of Execute must have -AWS-Admins AD Security Group of desired account.
    auth = AwsAuthenticator(account=args.account,role=role)
    result = auth.getKeys()
    # Grabbing all regions and popping them into a list
    s = boto3.Session(
            aws_access_key_id= result["aws_access_key_id"],
            aws_secret_access_key= result["aws_secret_access_key"],
            aws_session_token= result["security_token"])

    regions = s.get_available_regions('elb', 'aws')

    #Cycling through regions first as it is required in connection call/client calls
    for region in regions:
        #making the Sessions
        s = boto3.Session(
                region_name = region,
                aws_access_key_id= result["aws_access_key_id"],
                aws_secret_access_key= result["aws_secret_access_key"],
                aws_session_token= result["security_token"])
        #There are two versions of ELB I will cycle through both so we address ALL ELBs
        elb_versions = ['elb','elbv2']
        for elb_version in elb_versions:
            #Making the client with the desired ELB type elb=Classic ELBs  elbv2=Application ELBs.  API for interacting with the two are completely different so there is an if block
            elb_conn = s.client(elb_version)
            #Getting the list of ELBs from def above
            for elb in get_elbs(elb_conn,elb_version):
                #pprint(elb)
                #Execute action on any Classic ELB
                if elb_version == 'elb':
                    #pprint(elb)
                    #Getting information on listeners associated with ELBs
                    print region,"~",elb['LoadBalancerName'],"~",elb['CreatedTime'],"~",elb['DNSName'],"~",str(elb['Instances']),"~",elb['SecurityGroups'],"~",str(elb['AvailabilityZones']),"~",elb['Scheme']                 
                #Work to be done on Application ELBs
                elif elb_version == 'elbv2':
                    #Get all the listeners for the ELB using def above
                    print "ELB2: ",region,"~",elb['LoadBalancerName']


