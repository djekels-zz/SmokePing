import boto3
import time
import argparse
import sys
import os
from pprint import pprint
from datetime import datetime
from aws_authenticator import AwsAuthenticator
from time import strptime,strftime

def get_rds(rds_conn):
    result = []
    for page in rds_conn.get_paginator('describe_db_instances').paginate():
#        pprint(page)
        for rds in page['DBInstances']:
            result.append(rds)

    return result

def get_lop(session):
    ec2_conn = session.client('ec2')
    sg = ec2_conn.describe_security_groups(Filters=[{'Name':'group-name', 'Values':['TT-LOP']}])
    try:
        return sg['SecurityGroups'][0]['GroupId']
    except:
        return False
    

def test_conn(url, port):
    cmd = "tcping -t 2 "+url+" "+str(port)
    execute = os.popen(cmd,"r")
    output = execute.read()
    if "open" in output:
        return "open"
    else:
        return "timeout or closed"


#Main portion of code starting with command line arguments
parser = argparse.ArgumentParser()
parser.add_argument('--account', help='Please specify "deb" or "prod"')
parser.add_argument('--matching', default=None, help='Specify a substring to only update databases containing this string.  Ex.  "--matching uat" will only update DBs with uat in the name.')
parser.add_argument('--execute', action='store_true', default=False, help='Specify --execute to perform sg updates on all RDS')

args = parser.parse_args()
role = "read"
if not args.account:
    sys.exit("Please specify either \"deb\" or \"prod\" account")

if args.execute:
    role = "Admins"
else:
    role = "read"

#Using AD creds...would be runners of reports must have -AWS-Read AD Security Group for the desired account.  Runners of Execute must have -AWS-Admins AD Security Group of desired account.
auth = AwsAuthenticator(account=args.account,role=role)
result = auth.getKeys()
# Grabbing all regions and popping them into a list
s = boto3.Session(
        aws_access_key_id= result["aws_access_key_id"],
        aws_secret_access_key= result["aws_secret_access_key"],
        aws_session_token= result["security_token"])

regions = s.get_available_regions('rds', 'aws')

#Cycling through regions
for region in regions:
    print region
    #Make a session in the region
    session = boto3.Session(
        region_name = region,
        aws_access_key_id= result["aws_access_key_id"],
        aws_secret_access_key= result["aws_secret_access_key"],
        aws_session_token= result["security_token"])
    #Make an RDS connection
    rds = session.client('rds')
    #Pass the session to the get_lop function above to get the GroupId of the desired Security Group. If there is no TT-LOP in the region we do nothing
    tt_lop = get_lop(session)
    #Pass the RDS connection to the function above to paginate and get an list of all the RDS objects
    rds_insts = get_rds(rds)
    #If there actually is SG name TT-LOP in the region
    if tt_lop:
        #cycle through the RDS instances
        for inst in rds_insts:
            #Start assuming it is already good
            update_sg = False
            targeted = False
            #Object to store current SGs
            curr_sgs = []
            #If this is a public RDS, we aren't going to do anything.  Everything should be in VPC, we aren't playing with the special snowflakes
            if inst['PubliclyAccessible']:
                print "Check the RDS security group of ",inst['DBInstanceIdentifier']," it is publicly accessible"
            else:
                #cycle through the isntances Security Groups in case there are multiple
                for sg in inst['VpcSecurityGroups']:
                    curr_sgs.append(sg['VpcSecurityGroupId'])
                    #if TT-LOP isn't the only SG we are going to update it
                    if sg['VpcSecurityGroupId'] != tt_lop:
                        update_sg = True
                #If the matching flag is set, lets check to see if the substring is in the DB name
                if args.matching != None:
                    if args.matching in inst['DBInstanceIdentifier']:
                        targeted = True
                #If the matching arg isn't set all RDS instances are targeted.
                else:
                    targeted = True
                if update_sg == True and targeted == True:
                    #print the colon separate output...there's other batter ways to do this. sorry, I'm a colon.
                    print "Updating:",inst['DBInstanceIdentifier'],":",inst['Endpoint']['Address'],":",inst['Endpoint']['Port'],":",
                    #print the current sgs in the colons
                    for curr_sg in curr_sgs:
                        print curr_sg,":",
                    #Use function above to tcping test the connectivity
                    tcp_before = test_conn(inst['Endpoint']['Address'],inst['Endpoint']['Port'])
                    print "TCP Before:",tcp_before,
                    #If we aren't open before, we aren't going to touch
                    if tcp_before != "open":
                        print inst['DBInstanceIdentifier']," is not currently available from this machine. Skipping"
                    else:
                        #If the DB is in a cluster you have to edit the cluster not the instance.  And making sure I am in execute mode
                        if 'DBClusterIdentifier' in inst and args.execute == True:
                            rds.modify_db_cluster(
                                DBClusterIdentifier=inst['DBClusterIdentifier'],
                                VpcSecurityGroupIds=[tt_lop])
                            tcp_after = test_conn(inst['Endpoint']['Address'],inst['Endpoint']['Port'])
                            print ": TCP After:",tcp_after
                            if tcp_before != tcp_after:
                                print "\n\n TCP CONNECTIVITY went from ",tcp_before," to ",tcp_after," on ",inst['DBInstanceIdentifier'],"\n\n"
                        #Just making sure I am executing
                        elif args.execute == True:
                            rds.modify_db_instance(
                                DBInstanceIdentifier=inst['DBInstanceIdentifier'],
                                VpcSecurityGroupIds=[tt_lop])
                            tcp_after = test_conn(inst['Endpoint']['Address'],inst['Endpoint']['Port'])
                            print ": TCP After:",tcp_after
                            if tcp_before != tcp_after:
                                print "\n\n TCP CONNECTIVITY went from ",tcp_before," to ", tcp_after," on ",inst['DBInstanceIdentifier'],"\n\n"

                else:
                    if update_sg == False:
                        #If TT-LOP is the only one applied print the "We Good"
                        print "Already Good:",inst['DBInstanceIdentifier'],":",inst['Endpoint']['Address'],":",inst['Endpoint']['Port'],":",
                        for sg in inst['VpcSecurityGroups']:
                            print sg['VpcSecurityGroupId'],":",
                    if targeted == False:
                        #If TT-LOP is the only one applied print the "We Good"
                        print "Not the droid we're looking for:"#,inst['DBInstanceIdentifier'],":",inst['Endpoint']['Address'],":",inst['Endpoint']['Port'],":",
                        for sg in inst['VpcSecurityGroups']:
                            print sg['VpcSecurityGroupId'],":",
                print " "
    else:
        #If there is not TT-LOP in the region check how many RDS Instances and print message on addressing.
        if len(rds_insts) > 0:
            print "There are RDS instances in ",region," but no TT-LOP"
        else:
            print "There are no RDS instances or TT-LOP group in ",region

