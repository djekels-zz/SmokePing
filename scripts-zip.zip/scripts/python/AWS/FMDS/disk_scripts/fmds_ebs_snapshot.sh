#!/bin/bash -x

DATESTAMP="$(date "+%Y-%m-%d %H:%M")"
DATESTAMP2="$(sed 's/ /_/g' <<< ${DATESTAMP})"

LOGFILE="/tmp/${0##*/}.${DATESTAMP2}.log"
exec > >(tee "${LOGFILE}")
exec 2>&1

echo "Log: ${LOGFILE}"

MY_EC2_INSTANCE_ID="$(curl --silent http://169.254.169.254/latest/meta-data/instance-id)"
VG_NAME="vgFMDS"

#VOLUME_LIST="vol-aa0ee84b
#vol-9e0cea7f
#vol-260fe9c7
#vol-db0cea3a
#vol-a50cea44
#vol-d00cea31
#vol-5b0fe9ba
#vol-310fe9d0
#vol-a20fe943
#vol-250ee8c4
#vol-d10ee830
#vol-1ca1bbf2
#vol-cc3acf65"

VOLUME_LIST="$(aws ec2 describe-volumes --no-paginate --output text --color off --filters Name=attachment.instance-id,Values=${MY_EC2_INSTANCE_ID} Name=status,Values=in-use Name=tag-key,Values="VolumeGroup" Name=tag-value,Values="${VG_NAME}" --query "Volumes[*].VolumeId" | tr "\t" "\n")"

sync
/sbin/fsfreeze -f /mnt/FMDS-EBS1
for VOL in ${VOLUME_LIST}
do
	aws ec2 create-snapshot --volume-id ${VOL} --description "FMDS EBS Snapshot $(hostname -s) ${VG_NAME} ${DATESTAMP}" &
done

wait

/sbin/fsfreeze -u /mnt/FMDS-EBS1
