#!/bin/bash -x

SNAP_LOG=${1:?"SNAP_LOG needs to be specified as the one and only argument"}

awk 'BEGIN{ FS="[\t]" }{ if( $1 ~ /^FMDS EBS Snapshot/ ) print $5 }' "${SNAP_LOG}" | while read SNAPSHOT
do
	aws ec2 modify-snapshot-attribute --snapshot-id ${SNAPSHOT} --attribute createVolumePermission --operation-type add --user-ids 464154314123
done
