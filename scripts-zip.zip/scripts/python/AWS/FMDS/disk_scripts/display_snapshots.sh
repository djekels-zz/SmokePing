#!/bin/bash

aws ec2 describe-snapshots --no-paginate --output table --color auto --filters Name=description,Values="FMDS EBS Snapshot $(hostname -s) *" --query "sort_by(Snapshots, &Description)[*].[SnapshotId, Description, State, Progress, VolumeId]"
