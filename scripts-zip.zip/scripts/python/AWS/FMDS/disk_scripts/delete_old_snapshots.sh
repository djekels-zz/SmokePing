#!/bin/bash -x

DATESTAMP="$(date "+%Y-%m-%d_%H:%M")"

LOGFILE="/tmp/${0##*/}.${DATESTAMP}.log"
exec > >(tee "${LOGFILE}")
exec 2>&1

echo "Log: ${LOGFILE}"

WEEKS_AGO="4"
DATE_X_WEEKS_AGO="$(date -d "${WEEKS_AGO} weeks ago" "+%Y-%m-%d")"

if [[ $1 == "for_reals" ]]
then
	DRYRUN=""
else
	DRYRUN="--dry-run"
fi

aws ec2 describe-snapshots --no-paginate --output text --color off --filters Name=description,Values="FMDS EBS Snapshot $(hostname -s) *" --query "Snapshots[?StartTime<=\`${DATE_X_WEEKS_AGO}\`][].SnapshotId" | tr "\t" "\n" | while read OLD_SNAPSHOT
do
	echo aws ec2 delete-snapshot ${DRYRUN} --snapshot-id ${OLD_SNAPSHOT}
done | sh -x
