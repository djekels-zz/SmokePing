#!/bin/bash

# 0 0 * * * /root/disk_scripts/cron_delete_and_snap.sh >/dev/null 2>&1

/root/disk_scripts/fmds_ebs_snapshot.sh && /root/disk_scripts/delete_old_snapshots.sh for_reals
find /tmp -type f -regextype posix-extended -regex '/.*/(fmds_ebs_snapshot|delete_old_snapshots)\.sh\..*\.log' -mtime "+30" -exec ls -ld {} \+
#find /tmp -type f -regextype posix-extended -regex '/.*/(fmds_ebs_snapshot|delete_old_snapshots)\.sh\..*\.log' -mtime "+30" -exec rm -f {} \+
