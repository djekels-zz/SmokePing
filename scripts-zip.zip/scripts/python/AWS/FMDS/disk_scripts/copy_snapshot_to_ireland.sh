#!/bin/bash -x

SNAP_LOG=${1:?"SNAP_LOG needs to be specified as the one and only argument"}

DATESTAMP="$(date "+%Y-%m-%d_%H:%M")"

LOGFILE="/tmp/${0##*/}.${DATESTAMP}.log"
exec > >(tee "${LOGFILE}")
exec 2>&1

awk 'BEGIN{ FS="[\t]" }{ if( $1 ~ /^FMDS EBS Snapshot/ ){ print "aws ec2 copy-snapshot --dry-run --source-region us-east-1 --source-snapshot-id " $5 " --description \"[Copied " $5 " from us-east-1] " $1 "\" --region eu-west-1 &" }}END{ print "wait" }' "${SNAP_LOG}" | sh -x
