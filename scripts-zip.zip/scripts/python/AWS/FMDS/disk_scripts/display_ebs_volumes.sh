#!/bin/bash

MY_EC2_INSTANCE_ID="$(curl --silent http://169.254.169.254/latest/meta-data/instance-id)"
VG_NAME="vgFMDS"

aws ec2 describe-volumes --no-paginate --output table --color auto --filters Name=attachment.instance-id,Values=${MY_EC2_INSTANCE_ID} Name=status,Values=in-use Name=tag-key,Values="VolumeGroup" Name=tag-value,Values="${VG_NAME}" --query "sort_by(Volumes, &VolumeId)[*].[VolumeId, Tags[?Key==\`VolumeGroup\`].Value | [0], Attachments[0].Device]"
