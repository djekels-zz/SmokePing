#!/bin/bash -x

SNAP_LOG=${1:?"SNAP_LOG needs to be specified as the one and only argument"}

DATESTAMP="$(date "+%Y-%m-%d_%H:%M")"

LOGFILE="/tmp/${0##*/}.${DATESTAMP}.log"
exec > >(tee "${LOGFILE}")
exec 2>&1

if [[ $2 == "for_reals" ]]
then
        DRYRUN=""
else
        DRYRUN="--dry-run"
fi

awk -v DRYRUN="${DRYRUN}" 'BEGIN{ FS="[\t]" }{ if( $1 ~ /^FMDS EBS Snapshot/ ){ print "aws ec2 create-volume " DRYRUN " --region us-east-1 --availability-zone us-east-1a --volume-type gp2 --snapshot-id " $5 " &" }}END{ print "wait" }' "${SNAP_LOG}" | sh -x
