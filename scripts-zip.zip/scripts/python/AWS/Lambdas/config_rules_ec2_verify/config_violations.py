import json
import boto3
import logging
import ldap
import datetime
from datetime import *

LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)
START = datetime.strptime('2017-09-18','%Y-%m-%d')
GRACE = datetime.utcnow() - timedelta(minutes=10)
NOW = datetime.utcnow()
TERMTIME = datetime.utcnow() + timedelta(days=21)

LDAPS = {
    '331560656580': {
        'eu-west-1': ['10.190.0.20','10.176.0.20','10.192.0.20','10.204.0.28','10.205.0.28','10.206.0.28'], 
        'us-east-1': ['10.190.0.20','10.176.0.20','10.192.0.20','10.204.0.28','10.205.0.28','10.206.0.28'],
        'ap-northeast-1': ['10.190.0.20','10.176.0.20','10.192.0.20','10.204.0.28','10.205.0.28','10.206.0.28'],
  },
    '464154314123': {
        'eu-west-1': ['10.126.0.30','10.127.0.28','10.127.0.30','10.113.0.28','10.113.0.30','10.111.0.28','10.111.0.30','10.102.0.28','10.102.0.30','10.144.0.28','10.143.0.28','10.145.0.30'],
        'us-east-1': ['10.113.0.28','10.113.0.30','10.111.0.28','10.111.0.30','10.102.0.28','10.102.0.30','10.126.0.30','10.127.0.28','10.127.0.30','10.144.0.28','10.143.0.28','10.145.0.30'], 
        'ap-northeast-1': ['10.144.0.28','10.143.0.28','10.145.0.30','10.113.0.28','10.113.0.30','10.111.0.28','10.111.0.30','10.102.0.28','10.102.0.30','10.126.0.30','10.127.0.28','10.127.0.30'], 
  }
}

# Specify desired resource types to validate
APPLICABLE_RESOURCES = ["AWS::EC2::Instance"]
VPCS = {    
    '331560656580': {
        'eu-west-1': {
            'vpc_id': 'vpc-e98b4381',
            'sec_grp': 'sg-55d5c330',
            },
        'us-east-1': {
            'vpc_id': 'vpc-a9f2ffc2',
            'sec_grp': 'sg-0bb56c6c',
            },
        'ap-northeast-1': {
            'vpc_id': 'vpc-4883f021',
            'sec_grp': 'sg-b1a6d2d4',
            },
  },
    '464154314123': {
        'eu-west-1': {
            'vpc_id': 'vpc-c2848da0',
            'sec_grp': 'sg-a97c99ce',
            },
        'us-east-1': {
            'vpc_id': 'vpc-fc01a492',
            'sec_grp': 'sg-3f087147',
            },
        'ap-northeast-1': {
            'vpc_id': 'vpc-c6d2dba4',
            'sec_grp': 'sg-505d8734',
            },
  }
}

def get_created_by_email(current_tags, account, region):
    emails = ['syseng@trade.tt']
    username = 'unknowndrone'
    fname = 'Friend'

    for tag in current_tags:
        if tag['key'] == 'created-by':
            username = tag['value']

    baseDN = "dc=int,dc=tt,dc=local"
    searchScope = ldap.SCOPE_SUBTREE
    retrieveAttributes = ["mail","givenName"]
    searchFilter = "uid="+username
    
    if username != None or username != 'root':
        for ip in LDAPS[account][region]:
            LOGGER.info("Trying "+ip)
            try:
                l = ldap.open(ip)
                l.protocol_version = ldap.VERSION3
                l.simple_bind('ldapquery', 'ldapsearch')
                ldap_result_id = l.search(baseDN, searchScope, searchFilter, retrieveAttributes)
                result_set = []
                result_type, result_data = l.result(ldap_result_id, 0)
                if result_type == ldap.RES_SEARCH_ENTRY:
                    result_set.append(result_data)
                l.unbind()
                if len(result_set) == 1 and len(result_set[0]) == 1 and len(result_set[0][0]) != 0:
                    if result_set[0][0][1].get('mail',False):
                        if len(result_set[0][0][1]['mail']) != 0:
                            emails.append(result_set[0][0][1]['mail'][0])
                    if result_set[0][0][1].get('givenName',False):
                        if len(result_set[0][0][1]['givenName']) != 0:
                            fname = result_set[0][0][1]['givenName'][0]
                break
            except Exception,e:
                LOGGER.error(e)
        return emails, fname
    else:
        return emails, fname
    

def find_tag_violation(current_tags, required_tags):
    violation = ""
#    print "Current Tags:",current_tags
#    print "Required Tags:",required_tags
    for rtag,rvalue in required_tags.iteritems():
        tag_present = False
        for tag in current_tags:
#            print rtag,' ',tag['key']
            if tag['key'] == rtag:
                value_match = False
                tag_present = True
#                rvaluesplit = rvalues.split(",")
#                for rvalue in rvaluesplit:
#                    if tag['value'] == rvalue:
#                        value_match = True
                if tag['value'] != "" and tag['value'] != None:
                    value_match = True
                    if tag['key'] == 'created-by':
                        if '.' in tag['value'] or 'root' in tag['value']:
                            value_match = False
                if value_match == False:
                    tag_present = False
        if tag_present == False:
            violation = violation + "<br />" + "Tag " + str(rtag) + " is not present or has empty/unapproved value."
    return  violation

def find_pub_violation(public_ip, region, account):
    if public_ip != None:
        return "<br />Instance has an unapproved public IP "+public_ip+"."
    else:
        return ""

def find_vpc_violation(vpc, region, account):
    
    if VPCS[account][region]['vpc_id'] == vpc:
        return ""
    else:
        return "<br />Instance is in the wrong VPC."

def find_sg_violation(security_grp, region, account):
    has_approved_sg = False
    for sg in security_grp:
        if sg['groupId'] == VPCS[account][region]['sec_grp']:
            has_approved_sg = True

    if has_approved_sg == True:
        return  ""
    else:
        return "<br />Instance does not have the right Security Group."
        
def send_email(validation, account, region, instance_id, current_tags,state,action_message):
    emails, fname = get_created_by_email(current_tags,account,region)
    LOGGER.info(emails)
    email = ['adam.claypool@trade.tt']
    tags = ""
    if account == '464154314123':
        account_name = 'Production'
    else:
        account_name = 'POC'
    
    for tag in current_tags:
        tags+= "<b>"+str(tag['key'])+": </b>"+str(tag['value'])+"<br \>"
    
    
    html_body = '<html>\
         <body>\
             <center>'\
             '<b><i><h2>Hi '+fname+', Don\'t forget to set the tags!</h2></b></i><br/>\
             <img src="https://33.media.tumblr.com/avatar_ceb5261463ec_96.png">\
             <br/>\
             Please review <a href="http://go/tags">http://go/tags</a>\
             <b><br/>'+instance_id+' in '+region+' in '+account_name+' is not configured correctly</b>\
             </center><br/>\
             <h3>Violations:</h3>'+validation+'\
             <br/>\
             <h3>Current Tags:</h3>'+tags+'\
             <br />\
             <h2>Action Taken:</h2>'+action_message+'\
             <br />\
             <b><b>\
          </body>\
    </html>'
    

    s = boto3.Session(region_name='us-east-1')
    ses_client = s.client('ses')
    ses_client.send_email(
        Source='noreply@tradingtechnologies.com',
        Destination={'ToAddresses':email},
        Message={
            'Subject': {
                'Data': 'Unapproved EC2 config: '+instance_id+' in state '+state+' in '+account_name+' region: '+region,
            },
            'Body':{
                'Html': {
                    'Data': html_body,
                }
            }
        }
    )    
        

def set_tag_and_shutdown(instance_id,region,auto_deploy,decom_plan):
    new_tag = [{'Key': 'final countdown','Value': datetime.strftime(TERMTIME, '%Y-%m-%d %H:%M:%S') }]
    ec2 = boto3.resource(
        'ec2',
        region_name = region)
    if decom_plan == False:
        inst = ec2.Instance(instance_id) 
        try:
            inst.create_tags(Tags=new_tag)
        except Exception,e:
            LOGGER.error(e)
    if not auto_deploy:
        try:
            inst.stop(Force=True)
        except Exception,e:
            LOGGER.error(e)

def term_expired_instance(instance_id,region,auto_deploy,ad_name):
    if not auto_deploy:
        LOGGER.info("Terminating Instance "+instance_id)
        ec2 = boto3.resource(
            'ec2',
            region_name = region)
        try:
            inst = ec2.Instance(instance_id)
            inst.terminate()
        except Exception,e:
            LOGGER.error(e)
    else:
        LOGGER.info("Terminating AutoScaling Group "+ad_name)
        asg = boto3.client('autoscaling', region_name = region)
        try:
            asg.delete_auto_scaling_group(
                AutoScalingGroupName = ad_name,
                ForceDelete = True)
        except Exception,e:
            LOGGER.error(e)

def evaluate_compliance(configuration_item, rule_parameters):
    running = False
    auto_deploy = False
    decom_plan = False
    ad_name = None
    launch_grace = True
    term = False
    approved = False
    action_message = ""
    LOGGER.info(configuration_item["resourceType"])
    if configuration_item["resourceType"] not in APPLICABLE_RESOURCES:
        return {
            "compliance_type": "NOT_APPLICABLE",
            "annotation": "The rule doesn't apply to resources of type " +
            configuration_item["resourceType"] + "."
        }

    if configuration_item["configurationItemStatus"] == "ResourceDeleted":
        return {
            "compliance_type": "NOT_APPLICABLE",
            "annotation": "The configurationItem was deleted and therefore cannot be validated."
        }

    current_tags = configuration_item["configuration"].get("tags","")
    account = configuration_item["awsAccountId"]
    instance_id = configuration_item["configuration"].get("instanceId","")
    public_ip = configuration_item["configuration"].get("publicIpAddress",None)
    vpc = configuration_item["configuration"].get("vpcId","")
    security_grp = configuration_item["configuration"].get("securityGroups","")
    region = configuration_item["awsRegion"]
    state = configuration_item["configuration"]["state"].get("name","")
    launch_time = datetime.strptime(configuration_item["configuration"]["launchTime"].replace('T', " ").replace('Z', "")[:-4], '%Y-%m-%d %H:%M:%S')
    if launch_time < GRACE or launch_time > START:
        launch_grace = False



    LOGGER.info(str(GRACE)+" "+str(NOW)+" "+str(launch_time))

    for tag in current_tags:
        if tag['key'] == 'violation approved':
            if tag['value'] == 'yes':
                approved = True
        elif tag['key'] == 'final countdown':
            decom_plan = True
            term_time = tag['value']
            if datetime.strptime(term_time, '%Y-%m-%d %H:%M:%S') < NOW:
                LOGGER.info("Going to Terminate")
                term = True
                LOGGER.info(term_time)
        elif tag['key'] == 'aws:autoscaling:groupName':
            auto_deploy = True
            ad_name = tag['value']

    if approved == False:
        violation = find_tag_violation(current_tags, rule_parameters)
        LOGGER.info(violation)
        violation += find_pub_violation(public_ip, region, account)
        LOGGER.info(violation)
        violation += find_vpc_violation(vpc, region, account)
        LOGGER.info(violation)
        violation += find_sg_violation(security_grp, region, account)
        LOGGER.info(violation)

        if state == "running" or state == "pending":
            running = True
        
        if violation != "":
            if running == True and launch_grace == False and term == False:
                set_tag_and_shutdown(instance_id,region,auto_deploy,decom_plan)
                if auto_deploy:
                    action_message = "Your instance is part of an automatic deployment.  You will have 14 days to correct the issue with your deployment.  After 14 days your Beanstalk or Autoscaling will be stopped."
                else:
                    action_message = "Your instance has been shutdown and will be Terminated in 14 days if it not updated to meet compliance."

    ###########Need logic for instances that have been shutdown for a long time################
            elif term == True:
                term_expired_instance(instance_id,region,auto_deploy,ad_name)
                if auto_deploy:
                    action_message = ad_name+" associated with instantce has been stopped due to non-compliant configuration."
                else:
                    action_message = "Your instance expired "+term_time+" and has been terminated"
            elif decom_plan == True:
                action_message = "Your instance will be Terminated at the following date and time: "+term_time+" unless you meet compliance"
            else:
                action_message = "Systems Engineering will be contacting you to resolve this configuration"


            send_email(violation,account,region,instance_id,current_tags,state,action_message)
            return {
                "compliance_type": "NON_COMPLIANT",
                "annotation": violation
            }
        else:
            return {
                "compliance_type": "COMPLIANT",
                "annotation": "This resource is compliant with the rule."
            }
    else:
        return {
            "compliance_type": "COMPLIANT",
            "annotation": "This resource is compliant with the rule."
        }

def lambda_handler(event, context):
    LOGGER.info(event)

    invoking_event = json.loads(event["invokingEvent"])
    configuration_item = invoking_event["configurationItem"]
    rule_parameters = json.loads(event["ruleParameters"])
    
    LOGGER.info(invoking_event)
    LOGGER.info(configuration_item)
    LOGGER.info(rule_parameters)
    
    result_token = "No token found."
    if "resultToken" in event:
        result_token = event["resultToken"]
        
    LOGGER.info(result_token)

    evaluation = evaluate_compliance(configuration_item, rule_parameters)
    LOGGER.info(evaluation)

    config = boto3.client("config")
    config.put_evaluations(
        Evaluations=[
            {
                "ComplianceResourceType":
                    configuration_item["resourceType"],
                "ComplianceResourceId":
                    configuration_item["resourceId"],
                "ComplianceType":
                    evaluation["compliance_type"],
                "Annotation":
                    evaluation["annotation"][:256],
                "OrderingTimestamp":
                    configuration_item["configurationItemCaptureTime"]
            },
        ],
        ResultToken=result_token
    )

