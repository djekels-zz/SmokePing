import boto3
import os

cmd = "ldapsearch -D \"uid=ldapquery,ou=Service Accounts,ou=Users,ou=CHI,ou=US,dc=int,dc=tt,dc=local\" -w \"ldapsearch\" -b \"dc=int,dc=tt,dc=local\" uid=aws-poc-fmds-backup | grep ntUserParms"

print cmd

execute = os.popen(cmd,"r")
output = execute.readline()
aws_key = output.split(":")[1].strip()
aws_secret = output.split(":")[2].strip()
role = 'arn:aws:iam::331560656580:role/role-fmds-berkeley-backup'
account = ''

bucket_name = 'fmds-berkeley-db-index-backup-int'

try:
    sts_client = boto3.client('sts',
        aws_access_key_id = aws_key,
        aws_secret_access_key = aws_secret)
    a_role=sts_client.assume_role(
        RoleArn = role,
        RoleSessionName = 'fmds-berkeley-backup')
    try:
        s3 = boto3.client(
            's3',
            region_name = 'us-east-1',
            aws_access_key_id=a_role["Credentials"]["AccessKeyId"],
            aws_secret_access_key=a_role["Credentials"]["SecretAccessKey"],
            aws_session_token=a_role["Credentials"]["SessionToken"])
    except Exception,e:
        print e 
except Exception,e:
    print e



directory= '/var/debesys/depthCollector/local/data/'

for root, _, files in os.walk(directory):
    for f in files:
        file_path = os.path.join(root, f)
        if f.endswith('.db'):
            print "Uploading: ",file_path
            s3.upload_file(file_path, bucket_name, f)



