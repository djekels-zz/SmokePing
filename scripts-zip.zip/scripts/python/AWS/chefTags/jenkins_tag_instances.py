#!/usr/bin/env python2.7
# -*- mode: python -*-
import boto.ec2
import boto3
import os
import logging
from boto.ses.connection import SESConnection

LOGFILE = '/tmp/tag_env.log'
logger = logging.getLogger('env')
logFileHandler = logging.FileHandler(LOGFILE, mode='w')
logFormatter = logging.Formatter('%(asctime)s %(levelname)s: %(message)s')
logFileHandler.setFormatter(logFormatter)
logger.addHandler(logFileHandler)
logger.setLevel(logging.INFO)

MONITORED_TAGS = ['vpc-vyatta','vpc-nat','infrastructure','hsm','ttid','safenet','operations','aws:cloudformation:stack-name','elasticbeanstalk:environment-name','aws:autoscaling:groupName','fixconformance','ttw','ttus','pds','message','ledger','fmds','analytics','cassandra']

CW_SUPPORTED_TYPES = ['c3','c4','m3','m4','r3','r4','t2','x1']

CLOUDWATCH_ACTIONS = {
    'production':{
        'us-east-1':{
            'action':'arn:aws:automate:us-east-1:ec2:recover',
            'notify':'arn:aws:sns:us-east-1:464154314123:syseng'
        },
        'eu-west-1':{
            'action':'arn:aws:automate:eu-west-1:ec2:recover',
            'notify':'arn:aws:sns:eu-west-1:464154314123:syseng'
        },
        'ap-northeast-1':{
            'action':'arn:aws:automate:ap-northeast-1:ec2:recover',
            'notify':'arn:aws:sns:ap-northeast-1:464154314123:syseng'
        }
    },
    None:{
        'us-east-1':{
            'action':'arn:aws:automate:us-east-1:ec2:recover',
            'notify':'arn:aws:sns:us-east-1:331560656580:adam-test'
        },
        'eu-west-1':{
            'action':'arn:aws:automate:eu-west-1:ec2:recover',
            'notify':'arn:aws:sns:eu-west-1:331560656580:adam-test'
        },
        'ap-northeast-1':{
            'action':'arn:aws:automate:ap-northeast-1:ec2:recover',
            'notify':'arn:aws:sns:ap-northeast-1:331560656580:adam-test'
        }
    }
}



class AwsInstance(object):
    def __init__(self):
        self.ec2_type = None
        self.account = None
        self.profile = None
        self.inst_obj = None
        self.region = None
        self.ops_name = None
        self.group = None
        self.env = None
        self.platform = None
        self.component = None
        self.monitor = 'no' 
        self.chef = 'no' ,
        self.id = None
        self.ip = None
        self.current_tags = None
        self.tagging_scheme = None
        self.tagged = False
        self.az = None
        self.state = None

def apply_tags(instance):
    tags = {}
    new_ge = None
    
    current_ge = instance.current_tags.get('group:env', None)
    if current_ge != None:
        new_ge = current_ge.split(':')[0]+':'+instance.env
    
    current_pcs = instance.current_tags.get('platform:component:sub-project', None)
    if current_pcs != None:
        if len(current_pcs.split(':')) == 2:
            new_pcs = current_pcs.split(':')[0]+':'+instance.component+':'
        if len(current_pcs.split(':')) == 3:
            new_pcs = current_pcs.split(':')[0]+':'+instance.component+':'+current_pcs.split(':')[2]
    current_ops_name = instance.current_tags.get('ops name', None)
    current_monitoring = instance.current_tags.get('monitoring', None)
    current_chef = instance.current_tags.get('chef', None)
    current_platform = instance.current_tags.get('platform', None)
    current_component = instance.current_tags.get('component', None)
    current_group = instance.current_tags.get('group', None)
    current_env = instance.current_tags.get('component', None)
    current_cb = instance.current_tags.get('created-by', None)
#    print current_ops_name," ",instance.ops_name
    if current_ops_name != instance.ops_name:
        tags['ops name'] = instance.ops_name
    if current_ge != new_ge:
        tags['group:env'] = new_ge
    if current_pcs != new_pcs:
        tags['platform:component:sub-project'] = new_pcs
    if current_monitoring != instance.monitor:
        tags['monitor'] = instance.monitor
    if current_chef != instance.chef:
        tags['chef'] = instance.chef
    if current_platform != instance.platform:
        tags['platform'] = instance.platform
    if current_component != instance.component:
        tags['component'] = instance.component
    if current_group != instance.group:
        tags['group'] = instance.group
    if current_env != instance.env:
        tags['environment'] = instance.env
    
#    print dir(instance.inst_obj)
    if instance.monitor == 'yes' and instance.ec2_type.split('.')[0] in CW_SUPPORTED_TYPES and instance.state == 'running':
        cloudwatch_autorecover(instance)

    print instance.id,"~",str(tags)
#    try:
#        instance.inst_obj.add_tags(tags)
#    except Exception,e:
#        print e
    

def chef_instance(instance, chef_details):

    instance.ops_name = chef_details['run']+'-'+str(instance.ip).split('.')[3]+'-'+instance.az+'-'+chef_details['env']
    instance.group = 'engineering'
    instance.env = chef_details['env']
    instance.platform = 'tt'
    instance.component = chef_details['run']
    instance.monitor = 'yes'
    instance.chef = 'yes'
    apply_tags(instance)

def cloudwatch_autorecover(instance):
    s = boto3.Session(
        profile_name = instance.profile,
        region_name = instance.region.name)

    cw_conn = s.client(
        'cloudwatch'
    )
    alarms = cw_conn.describe_alarms(
       AlarmNames = [instance.id+"-system-failed-check-autorecover"]
    )
    if len(alarms['MetricAlarms']) == 0:
        try:
            cw_conn.put_metric_alarm(
                AlarmName = instance.id+"-system-failed-check-autorecover",
                ActionsEnabled = True,
                Namespace = "AWS/EC2",
                MetricName = "StatusCheckFailed_System",
                Statistic = "Maximum",
                ComparisonOperator = "GreaterThanOrEqualToThreshold",
                Threshold = 1.0,
                Period = 60,
                EvaluationPeriods = 2,
                AlarmDescription = instance.id+"-system-failed-check-autorecover",
                Dimensions = [
                    {
                    'Name': 'InstanceId',
                    'Value': instance.id
                    },
                ],
                AlarmActions=[CLOUDWATCH_ACTIONS[instance.profile][instance.region.name]['action'],CLOUDWATCH_ACTIONS[instance.profile][instance.region.name]['notify']]
            )
        except Exception, e:
            print e

def get_chef_details(account,ip):
    chef_details = {
            'chef': None,
            'env': None,
            'run': None
    }
    if account == "production":
        cmd = "knife search node \"ipaddress:"+str(instance.ip)+"\" --config ~/.chef/knife.external.rb 2>&1 | grep \"Environment\|List\|items\""
    else:
        cmd = "knife search node \"ipaddress:"+str(instance.ip)+"\" 2>&1 | grep \"Environment\|List\|items\"" 
    execute = os.popen(cmd,"r")
    output = execute.read().strip()
    if output.split("\n")[0].strip() == "0 items found":
        chef_details['chef'] = 'no'
        return chef_details
    else:
        chef_details['env'] = output.split("\n")[1].strip().split(": ")[1].strip()
        chef_details['run'] = output.split("\n")[2].strip().replace('Run List:    ','').replace('recipe[base], ','').replace(', recipe[base]','').strip().replace(', ','|').replace('::','__').replace('recipe[','').replace(']','')
        chef_details['chef'] = 'yes'
        return chef_details


def non_chef_w_tags(instance):
    if instance.tagging_scheme != 'incomplete':
        current_ge = instance.current_tags.get('group:env', None)
        current_pcs = instance.current_tags.get('platform:component:sub-project', None)
        try:
            if len(current_pcs.split(':')) == 3:
                instance.ops_name = current_pcs.split(":")[1]+"-"+current_pcs.split(":")[2]+"-"+str(instance.ip).split(".")[3]+"-"+inst.placement+"-"+current_ge.split(":")[1]
                instance.component = current_pcs.split(":")[1]+"-"+current_pcs.split(":")[2]
            else:
                instance.ops_name = current_pcs.split(":")[1]+"-"+str(instance.ip).split(".")[3]+"-"+inst.placement+"-"+current_ge.split(":")[1]
                instance.component = current_pcs.split(":")[1]
#                print 'OPS NAME',instance.ops_name
            instance.group = current_ge.split(":")[0]
            instance.env = current_ge.split(":")[1]
            instance.platform = current_pcs.split(":")[0]
            instance.component = current_pcs.split(":")[1]
            instance.chef = 'no'
            for item in MONITORED_TAGS:
                if item in current_ge or item in current_pcs or item in instance.current_tags:
                    instance.monitor = 'yes'
            apply_tags(instance)
        except Exception,e:
            print e
            send_email(instance)
    else:
        send_email(instance)

def non_chef_wo_tags(instance):
    send_email(instance)


def send_email(instance):
    ses_conn = SESConnection(profile_name=None)
    body = 'Current_Tags:\n'
    for tag in instance.current_tags:
        body += tag+": "+instance.current_tags[tag]+"\n"
    
    source = 'noreply@tradingtechnologies.com'
    to_addresses = 'adam.claypool@trade.tt'
    subject = 'Instance '+instance.id+' needs full tags in '+instance.az
    try:
        ses_conn.send_email(source, subject, body, to_addresses, format='text' )
    except Exception,e:
        print e            


def tag_eval(instance):
    if instance.current_tags == None:
        instance.tagged = False
        instance.tagging_scheme = None
        return instance
    else:
        current_ge = instance.current_tags.get('group:env', None)
        current_pcs = instance.current_tags.get('platform:component:sub-project', None)
        current_platform = instance.current_tags.get('platform', None)
        current_component = instance.current_tags.get('component', None)
        current_env = instance.current_tags.get('component', None)
        if current_component == None and current_platform == None and current_env == None:
            if current_ge == None and current_pcs == None:
                instance.tagged = False
                instance.tagging_scheme = None
                return instance
            elif current_ge != None and current_pcs != None:
                instance.tagged = True
                instance.tagging_scheme = 'old'
                return instance
            else:
                instance.tagged = True
                instance.tagging_scheme = 'incomplete'
                return instance
        elif current_component != None and current_platform != None and current_env != None:
            instance.tagged = True
            instance.tagging_scheme = 'new'
            return instance
        else:
            instance.tagged = True
            instance.tagging_scheme = 'incomplete'
            return instance

    
if __name__ == "__main__":
    profiles = [None,'production']
    ip = None

    for profile in profiles:
        print profile
        regions = boto.ec2.connection.EC2Connection(profile_name=profile).get_all_regions()
        for region in regions:

            try:
                ec2_conn = region.connect()
            except Exception,e:
                print e
           
            reservations = ec2_conn.get_all_instances()
            for res in reservations:
                for inst in res.instances:
                    instance = AwsInstance()
                    instance.profile = profile
                    instance.state = inst.state
                    instance.ec2_type = inst.instance_type
                    instance.inst_obj = inst
                    instance.region = region
                    instance.id = inst.id
                    instance.current_tags = inst.tags
                    instance.az = inst.placement
                    instance = tag_eval(instance)
                    try:
                        instance.ip = inst.private_ip_address
                    except:
                        instance.ip = None
                    if instance.ip != None:
                        chef_details = get_chef_details(profile, ip)
                        if chef_details['chef'] == 'no':
                            if instance.tagged:
                                non_chef_w_tags(instance)
#                                print instance.id," ",instance.az," ",instance.tagged," ",instance.tagging_scheme
                            else:
                                non_chef_wo_tags(instance)
                        else:
                            chef_instance(instance, chef_details)

                            

                
                                



                

