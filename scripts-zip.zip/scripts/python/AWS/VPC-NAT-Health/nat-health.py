#!/usr/bin/env python2.7
# -*- mode: python -*-
import boto.vpc
import os
from boto.sts.connection import STSConnection
from flask import Flask, jsonify

# Gets pertinent key information from AWS_Authenticator then runs AWS task.
route_tables = {
    'poc': {
        'eu-west-1': {
            'vpc_id': 'vpc-e98b4381',
            'route_tables': ['rtb-eb8b4383','rtb-e58b438d','rtb-4f679f2a'],
            'zones': ['eu-west-1a','eu-west-1b','eu-west-1c'],
            'primary': ['i-0f7f75fea0cdc62d9','i-0841e765640a6f6e9','i-0fc1273048fb84627'],
            'backup': ['i-09eb8a1a3a573cd47','i-0f162930fcd9c5b8e','i-0f442f644ec60b003']
            },
        'us-east-1': {
            'vpc_id': 'vpc-a9f2ffc2',
            'route_tables': ['rtb-aff2ffc4','rtb-6938df04','rtb-c3d35cae'],
            'zones': ['us-east-1a','us-east-1b','us-east-1d'],
            'primary': ['i-02059fe335ad30d01','i-0ee60b5bfe7a72a92','i-04ea48a06fa69df5e'],
            'backup': ['i-03f4c046e43524786','i-0e94bf7547cdb3e4d','i-0cf3ca55d24b5989d']
            },
        'ap-northeast-1': {
            'vpc_id': 'vpc-4883f021',
            'route_tables': ['rtb-4283f02b','rtb-9f658cf7','rtb-9e658cf6'],
            'zones': ['ap-northeast-1a','ap-northeast-1b','ap-northeast-1c'],
            'primary': ['i-0f7f75fea0cdc62d9','i-0841e765640a6f6e9','i-0fc1273048fb8462'],
            'backup': ['i-0f7f75fea0cdc62d9','i-0841e765640a6f6e9','i-0fc1273048fb84627']
            },
  },
    'prod': {
        'eu-west-1': {
            'vpc_id': 'vpc-c2848da0',
            'route_tables': ['rtb-cb050da9','rtb-c8050daa','rtb-65c30300'],
            'zones': ['eu-west-1a','eu-west-1b','eu-west-1c'],
            'primary': ['i-07e59b02e9d465820','i-0e0e4c3ee1273869c','i-0aff005f9f66bf324'],
            'backup': ['i-0f47233457d03b99f','i-063947196ec631691','i-00596db901faf7c2d']
            },
        'us-east-1': {
            'vpc_id': 'vpc-fc01a492',
            'route_tables': ['rtb-fa01a494','rtb-45c1aa24','rtb-e416a481'],
            'zones': ['us-east-1a','us-east-1b','us-east-1d'],
            'primary': ['i-0901fa3e763f480e6','i-0932f6733d62d6a7c','i-0eb279dd7fe908ae2'],
            'backup': ['i-05e02ad559e70b5c2','i-06c768355948abbbf','i-079ad67ccad3f603f']
            },
        'ap-northeast-1': {
            'vpc_id': 'vpc-c6d2dba4',
            'route_tables': ['rtb-edfaf38f','rtb-eaa4ad88','rtb-e4a4ad86'],
            'zones': ['ap-northeast-1a','ap-northeast-1b','ap-northeast-1c'],
            'primary': ['i-0181f756bb047e12d','i-0dc65e7d9d98b653f','i-02028ef3eca35e5b1'],
            'backup': ['i-07d73f5a6d73962e5','i-0a7410a2cdb8884f6','i-0e35c5cc226e50ba9']
            },
  }
}
auth_info = {
    'poc':{
        'account': 'aws-poc-monitoring',
        'role': 'arn:aws:iam::331560656580:role/role-monitoring'
    },
    'prod':{
        'account': 'aws-prod-monitoring',
        'role': 'arn:aws:iam::464154314123:role/role-monitoring'
    }
}
nat_health_app = Flask(__name__)

@nat_health_app.route("/")

def check():
 
    route_states = {}
    for account in route_tables:
        #print account
        cmd = "ldapsearch -D \"uid=ldapquery,ou=Service Accounts,ou=Users,ou=CHI,ou=US,dc=int,dc=tt,dc=local\" -w \"ldapsearch\" -b \"dc=int,dc=tt,dc=local\" cn=\""+auth_info[account]['account']+"\" | grep ntUserParms"
        execute = os.popen(cmd,"r")
        output = execute.readline()
        aws_key = output.split(":")[1].strip()
        aws_secret = output.split(":")[2].strip()

        sts_conn = STSConnection(
          aws_access_key_id= aws_key,
          aws_secret_access_key= aws_secret)

        role_assume = sts_conn.assume_role(
          role_arn = auth_info[account]['role'],
          role_session_name = 'Session1',
          duration_seconds = 3600)
        #print route_tables[account]
        for region in route_tables[account]:
            regions = boto.vpc.regions()
            connect_region = regions[0]
            for r in regions:
                #print r.name,"==",region
                if r.name == region:
                    connect_region = r
            try:
                vpc_conn = boto.vpc.VPCConnection(
                  region = connect_region,
                  aws_access_key_id = role_assume.credentials.access_key,
                  aws_secret_access_key = role_assume.credentials.secret_key,
                  security_token = role_assume.credentials.session_token)
   #              debug=2)
            except Exception,e:
                print "Connection Error: ",e

            #print route_tables[account][region]['route_tables']
            #print route_tables[account][region]['vpc_id']
            try:
                rt_tables = vpc_conn.get_all_route_tables(filters={'vpc-id':route_tables[account][region]['vpc_id']})
            except Exception,e:
                print "Error:",e 
            
            #print rt_tables
            for rt_table in rt_tables:
                #print rt_table.routes
                if rt_table.id in route_tables[account][region]['route_tables']:
                    list_index = route_tables[account][region]['route_tables'].index(rt_table.id)
                    for rt in rt_table.routes:
                        #print str(rt.destination_cidr_block)
                        if str(rt.destination_cidr_block) == "0.0.0.0/0":
                            route_states[account + "-" + route_tables[account][region]['zones'][list_index]] = {
                                'state': rt.state,
                                'using_primary_path': route_tables[account][region]['primary'][list_index] == rt.instance_id,
                                'primary_instance': route_tables[account][region]['primary'][list_index],
                                'backup_instance': route_tables[account][region]['backup'][list_index],
                                'current_instance_used': rt.instance_id
                            }
                 

    return jsonify(route_states)
        
if __name__ == '__main__':
    nat_health_app.run(debug=True, host='0.0.0.0', port=5000)

