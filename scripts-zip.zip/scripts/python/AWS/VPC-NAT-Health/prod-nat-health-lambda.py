from __future__ import print_function

import boto3
import json
import logging

LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)
ROUTE_TABLES = {
    'prod': {
        'eu-west-1': {
            'vpc_id': 'vpc-c2848da0',
            'route_tables': ['rtb-cb050da9','rtb-c8050daa','rtb-65c30300'],
            'backup_route_tables': ['rtb-49b67c2e','rtb-95b17bf2','rtb-86b17be1'],
            'zones': ['eu-west-1a','eu-west-1b','eu-west-1c'],
            'primary': ['i-07e59b02e9d465820','i-0e0e4c3ee1273869c','i-0aff005f9f66bf324'],
            'backup': ['i-0f47233457d03b99f','i-063947196ec631691','i-00596db901faf7c2d']
            },
        'us-east-1': {
            'vpc_id': 'vpc-fc01a492',
            'route_tables': ['rtb-fa01a494','rtb-45c1aa24','rtb-e416a481'],
            'backup_route_tables': ['rtb-8ed27cf7','rtb-6fd37d16','rtb-40d37d39'],
            'zones': ['us-east-1a','us-east-1b','us-east-1d'],
            'primary': ['i-0901fa3e763f480e6','i-0932f6733d62d6a7c','i-0eb279dd7fe908ae2'],
            'backup': ['i-05e02ad559e70b5c2','i-06c768355948abbbf','i-079ad67ccad3f603f']
            },
        'ap-northeast-1': {
            'vpc_id': 'vpc-c6d2dba4',
            'route_tables': ['rtb-edfaf38f','rtb-eaa4ad88','rtb-e4a4ad86'],
            'backup_route_tables': ['rtb-d6bbc3b2','rtb-a7bbc3c3','rtb-a9bbc3cd'],
            'zones': ['ap-northeast-1a','ap-northeast-1b','ap-northeast-1c'],
            'primary': ['i-0181f756bb047e12d','i-0dc65e7d9d98b653f','i-02028ef3eca35e5b1'],
            'backup': ['i-07d73f5a6d73962e5','i-0a7410a2cdb8884f6','i-0e35c5cc226e50ba9']
            },
  }
}

print('Loading function')


def respond(err):
    route_states =  {}
    for region in ROUTE_TABLES['poc']:
            try:
                vpc_conn = boto3.client(
                    'ec2',
                    region_name= region)
            except Exception,e:
                LOGGER.error(str(e))

            for (pri_rt_table_id, back_rt_table_id) in zip(ROUTE_TABLES['poc'][region]['route_tables'], ROUTE_TABLES['poc'][region]['backup_route_tables']):
                try:
                    pri_rt_table = vpc_conn.describe_route_tables(
                        RouteTableIds=[pri_rt_table_id]
                    )
                    back_rt_table = vpc_conn.describe_route_tables(
                        RouteTableIds=[back_rt_table_id]
                    )
                except Exception,e:
                    LOGGER.error(str(e))
                
                #LOGGER.info(pri_rt_table['RouteTables'][0]['RouteTableId'])
                list_index = ROUTE_TABLES['poc'][region]['route_tables'].index(pri_rt_table['RouteTables'][0]['RouteTableId'])
                for rt in back_rt_table['RouteTables'][0]['Routes']:
                    if str(rt['DestinationCidrBlock']) == "0.0.0.0/0":
                        backup_route_state = rt['State']
                for rt in pri_rt_table['RouteTables'][0]['Routes']:
                    #LOGGER.info(rt)
                    if str(rt['DestinationCidrBlock']) == "0.0.0.0/0":
                        #LOGGER.info(rt)
                        primary_route_state = rt['State']
                        LOGGER.info(rt)
                        try:
                            using_primary_path = ROUTE_TABLES['poc'][region]['primary'][list_index] == rt['InstanceId']
                        except:
                            using_primary_path = 'unknown'
                        primary_instance = ROUTE_TABLES['poc'][region]['primary'][list_index]
                        primary_instance_details = vpc_conn.describe_instances(InstanceIds=[primary_instance])
                        #LOGGER.info(str(vpc_conn.describe_instances(InstanceIds=[ROUTE_TABLES['poc'][region]['primary'][list_index]])['Reservations'][0]['Instances'][0]['Tags']))
                        tags = vpc_conn.describe_instances(InstanceIds=[ROUTE_TABLES['poc'][region]['primary'][list_index]])['Reservations'][0]['Instances'][0]['Tags']
                        for tag in tags:
                            if tag['Key'] == 'Name':
                                primary_instance_name = tag['Value']
                        #LOGGER.info(primary_instance_name)
                        primary_instance_state = primary_instance_details['Reservations'][0]['Instances'][0]['State']['Name']
                        primary_instance_src_dst = primary_instance_details['Reservations'][0]['Instances'][0]['SourceDestCheck']
            'backup_route_tables': ['','',''],
                        backup_instance = ROUTE_TABLES['poc'][region]['backup'][list_index]
                        backup_instance_details = vpc_conn.describe_instances(InstanceIds=[backup_instance])
                        tags = backup_instance_details['Reservations'][0]['Instances'][0]['Tags']
                        for tag in tags:
                            if tag['Key'] == 'Name':
                                backup_instance_name = tag['Value']
                        backup_instance_state = backup_instance_details['Reservations'][0]['Instances'][0]['State']['Name']
                        backup_instance_src_dst = backup_instance_details['Reservations'][0]['Instances'][0]['SourceDestCheck']
                        try:
                            current_instance_used = rt['InstanceId']
                        except:
                            current_instance_used = 'unknown'
                            
                        if primary_route_state != "active":
                            overall_state = 'unhealthy'
                        elif primary_instance_src_dst == True:
                            overall_state = 'unhealthy'
                        elif backup_instance_src_dst == True:
                            overall_state = 'degraded'
                        elif backup_route_state != 'active':
                            overall_state = 'degraded'
                        elif primary_instance_state != 'running' or backup_instance_state != 'running':
                            overall_state = 'degraded'
                        else:
                            overall_state = 'healthy'

                        route_states[ROUTE_TABLES['poc'][region]['zones'][list_index]] = {
                            'primary_route_state': primary_route_state,
                            'backup_route_state': backup_route_state,
                            'using_primary_path': using_primary_path,
                            'primary_instance': primary_instance,
                            'primary_instance_name': primary_instance_name,
                            'primary_instance_state': primary_instance_state,
                            'primary_instance_src_dst': primary_instance_src_dst,
                            'backup_instance': backup_instance,
                            'backup_instance_name': backup_instance_name,
                            'backup_instance_state': backup_instance_state,
                            'backup_instance_state': backup_instance_state,
                            'backup_instance_src_dst': backup_instance_src_dst,
                            'current_instance_used': current_instance_used,
                            'overall_state': overall_state
                        }
    json_route_state = json.dumps(route_states)
    return {
        'statusCode': '400' if err else '200',
        'body': err.message if err else json_route_state,
        'headers': {
            'Content-Type': 'application/json',
        },
    }


def lambda_handler(event, context):
    #print("Received event: " + json.dumps(event, indent=2))

    operations = ['GET']

    operation = event['httpMethod']
    if operation in operations:
        payload = event['queryStringParameters'] if operation == 'GET' else json.loads(event['body'])
        return respond(None)
    else:
        return respond(ValueError('Unsupported method "{}"'.format(operation)))
