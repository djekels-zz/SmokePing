from __future__ import print_function

import boto3
import json
import logging

LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)
ROUTE_TABLES = {
    'poc': {
        'eu-west-1': {
            'vpc_id': 'vpc-e98b4381',
            'route_tables': ['rtb-eb8b4383','rtb-e58b438d','rtb-4f679f2a'],
            'backup_route_tables': ['rtb-bc05cbdb','rtb-8d05cbea','rtb-9605cbf1'],
            'zones': ['eu-west-1a','eu-west-1b','eu-west-1c'],
            'primary': ['i-0f7f75fea0cdc62d9','i-0841e765640a6f6e9','i-0fc1273048fb84627'],
            'backup': ['i-09eb8a1a3a573cd47','i-0f162930fcd9c5b8e','i-0f442f644ec60b003']
            },
        'us-east-1': {
            'vpc_id': 'vpc-a9f2ffc2',
            'route_tables': ['rtb-aff2ffc4','rtb-6938df04','rtb-c3d35cae'],
            'backup_route_tables': ['rtb-85e544fc','rtb-7fe44506','rtb-63e4451a'],
            'zones': ['us-east-1a','us-east-1b','us-east-1d'],
            'primary': ['i-02059fe335ad30d01','i-0ee60b5bfe7a72a92','i-04ea48a06fa69df5e'],
            'backup': ['i-03f4c046e43524786','i-0e94bf7547cdb3e4d','i-0cf3ca55d24b5989d']
            },
        'ap-northeast-1': {
            'vpc_id': 'vpc-4883f021',
            'route_tables': ['rtb-4283f02b','rtb-9f658cf7','rtb-9e658cf6'],#
            'backup_route_tables': ['rtb-f3ea9597','rtb-c0ea95a4','rtb-abea95cf'],#
            'zones': ['ap-northeast-1a','ap-northeast-1b','ap-northeast-1c'], #
            'primary': ['i-0d6dd09a0c988c73b','i-0932a86a4f903d224','i-0e3e4ed34275aa365'], #
            'backup': ['i-098ba21e3bc27f147','i-0191708c1e75ef101','i-08dfc4c37fba63012'] #
            },
  }
}

print('Loading function')


def respond(err):
    route_states =  {}
    for region in ROUTE_TABLES['poc']:
            try:
                vpc_conn = boto3.client(
                    'ec2',
                    region_name= region)
            except Exception,e:
                LOGGER.error(str(e))

            for (pri_rt_table_id, back_rt_table_id) in zip(ROUTE_TABLES['poc'][region]['route_tables'], ROUTE_TABLES['poc'][region]['backup_route_tables']):
                try:
                    pri_rt_table = vpc_conn.describe_route_tables(
                        RouteTableIds=[pri_rt_table_id]
                    )
                    back_rt_table = vpc_conn.describe_route_tables(
                        RouteTableIds=[back_rt_table_id]
                    )
                except Exception,e:
                    LOGGER.error(str(e))
                
                #LOGGER.info(pri_rt_table['RouteTables'][0]['RouteTableId'])
                list_index = ROUTE_TABLES['poc'][region]['route_tables'].index(pri_rt_table['RouteTables'][0]['RouteTableId'])
                for rt in back_rt_table['RouteTables'][0]['Routes']:
                    if str(rt['DestinationCidrBlock']) == "0.0.0.0/0":
                        backup_route_state = rt['State']
                for rt in pri_rt_table['RouteTables'][0]['Routes']:
                    #LOGGER.info(rt)
                    if str(rt['DestinationCidrBlock']) == "0.0.0.0/0":
                        #LOGGER.info(rt)
                        primary_route_state = rt['State']
                        LOGGER.info(rt)
                        try:
                            using_primary_path = ROUTE_TABLES['poc'][region]['primary'][list_index] == rt['InstanceId']
                        except:
                            using_primary_path = 'unknown'
                        primary_instance = ROUTE_TABLES['poc'][region]['primary'][list_index]
                        primary_instance_details = vpc_conn.describe_instances(InstanceIds=[primary_instance])
                        #LOGGER.info(str(vpc_conn.describe_instances(InstanceIds=[ROUTE_TABLES['poc'][region]['primary'][list_index]])['Reservations'][0]['Instances'][0]['Tags']))
                        tags = vpc_conn.describe_instances(InstanceIds=[ROUTE_TABLES['poc'][region]['primary'][list_index]])['Reservations'][0]['Instances'][0]['Tags']
                        for tag in tags:
                            if tag['Key'] == 'Name':
                                primary_instance_name = tag['Value']
                        #LOGGER.info(primary_instance_name)
                        primary_instance_state = primary_instance_details['Reservations'][0]['Instances'][0]['State']['Name']
                        primary_instance_src_dst = primary_instance_details['Reservations'][0]['Instances'][0]['SourceDestCheck']
                        backup_instance = ROUTE_TABLES['poc'][region]['backup'][list_index]
                        backup_instance_details = vpc_conn.describe_instances(InstanceIds=[backup_instance])
                        tags = backup_instance_details['Reservations'][0]['Instances'][0]['Tags']
                        for tag in tags:
                            if tag['Key'] == 'Name':
                                backup_instance_name = tag['Value']
                        backup_instance_state = backup_instance_details['Reservations'][0]['Instances'][0]['State']['Name']
                        backup_instance_src_dst = backup_instance_details['Reservations'][0]['Instances'][0]['SourceDestCheck']
                        try:
                            current_instance_used = rt['InstanceId']
                        except:
                            current_instance_used = 'unknown'
                            
                        if primary_route_state != "active":
                            overall_state = 'unhealthy'
                        elif primary_instance_src_dst == True:
                            overall_state = 'unhealthy'
                        elif backup_instance_src_dst == True:
                            overall_state = 'degraded'
                        elif backup_route_state != 'active':
                            overall_state = 'degraded'
                        elif primary_instance_state != 'running' or backup_instance_state != 'running':
                            overall_state = 'degraded'
                        else:
                            overall_state = 'healthy'

                        route_states[ROUTE_TABLES['poc'][region]['zones'][list_index]] = {
                            'primary_route_state': primary_route_state,
                            'backup_route_state': backup_route_state,
                            'using_primary_path': using_primary_path,
                            'primary_instance': primary_instance,
                            'primary_instance_name': primary_instance_name,
                            'primary_instance_state': primary_instance_state,
                            'primary_instance_src_dst': primary_instance_src_dst,
                            'backup_instance': backup_instance,
                            'backup_instance_name': backup_instance_name,
                            'backup_instance_state': backup_instance_state,
                            'backup_instance_state': backup_instance_state,
                            'backup_instance_src_dst': backup_instance_src_dst,
                            'current_instance_used': current_instance_used,
                            'overall_state': overall_state
                        }
    json_route_state = json.dumps(route_states)
    return {
        'statusCode': '400' if err else '200',
        'body': err.message if err else json_route_state,
        'headers': {
            'Content-Type': 'application/json',
        },
    }


def lambda_handler(event, context):
    #print("Received event: " + json.dumps(event, indent=2))

    operations = ['GET']

    operation = event['httpMethod']
    if operation in operations:
        payload = event['queryStringParameters'] if operation == 'GET' else json.loads(event['body'])
        return respond(None)
    else:
        return respond(ValueError('Unsupported method "{}"'.format(operation)))

