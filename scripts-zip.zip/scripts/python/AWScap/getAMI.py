#!/usr/bin/python

import boto3
import pprint
import sys
import argparse
import re
import ldap
import pprint
import datetime

end = datetime.datetime.now()
start = end - datetime.timedelta(hours=24)
from aws_authenticator import AwsAuthenticator
pp = pprint.PrettyPrinter(depth=6)
parser = argparse.ArgumentParser()
parser.add_argument("-a", dest='account',help="AWS Account (it, deb, prod)")
parser.add_argument("-r", dest='role',help="AWS Role (Read, DevAdmins, Devs, Elastic-Beanstalk, NetworkAdmins, Admins)")
parser.add_argument("-g", dest='regions',help="Define individual region (i.e us-east-1) or use 'all' for all regions")
args = parser.parse_args()

auth = AwsAuthenticator(account=args.account,role=args.role)
result = auth.getKeys()
key_id = result["aws_access_key_id"]
access_key = result["aws_secret_access_key"]
token = result["security_token"]

iamClient = boto3.client('iam',aws_access_key_id=key_id, aws_secret_access_key=access_key, aws_session_token=token)
userlist = iamClient.list_users()
accountId = userlist['Users'][0]['Arn'].split(':')[4]

if args.regions == 'all':
	regions = ['us-east-1','us-west-1','us-west-2','sa-east-1','eu-west-1','eu-central-1','ap-southeast-2','ap-southeast-1','ap-northeast-1']
else:
	regions = [args.regions]
all_images = dict()
for region in regions:
	ec2 = boto3.resource('ec2',region_name=region, aws_access_key_id=key_id, aws_secret_access_key=access_key, aws_session_token=token)
	my_images = ec2.images.filter(Owners=[accountId])
	for item in my_images:
		exists=0
		for instance in ec2.instances.all():
			if instance.image_id == item.image_id:
				exists=1
		#print (item.name,item.image_id,item.creation_date)
	if exists<1:
		print (region,item.name,item.image_id,"Is not used")

