#!/usr/bin/python

import boto3
import pprint
import sys
import argparse
import re
import ldap
import pprint
import datetime
import smtplib

end = datetime.datetime.now()
start = end - datetime.timedelta(hours=24)
from aws_authenticator import AwsAuthenticator
pp = pprint.PrettyPrinter(depth=6)
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
parser = argparse.ArgumentParser()
parser.add_argument("-a", dest='account',help="AWS Account (it, deb, prod)")
parser.add_argument("-r", dest='role',help="AWS Role (Read, DevAdmins, Devs, Elastic-Beanstalk, NetworkAdmins, Admins)")
parser.add_argument("-g", dest='regions',help="Define individual region (i.e us-east-1) or use 'all' for all regions")
args = parser.parse_args()

################# EMAIL SETUP #############
me = "systemintegration@tradingtechnologies.com"
you = "sean.case@trade.tt"
msg = MIMEMultipart('alternative')
msg['Subject'] = "AWS EC2 Metrics From " + args.account + " Account"
msg['From'] = me
msg['To'] = you
html=""
html+= "<html><h1><b>AWS EC2 Metrics From " + args.account + " Account</b></h1>"
html = """\
<table border=1><tr valign=top>
<td align=center><b>Region</b></td>
<td align=center><b>Instance ID</b></td>
<td align=center><b>Private IP</b></td>
<td align=center><b>Image ID</b></td>
<td align=center><b>Type</b></td>
<td align=center><b>Avg CPU Utilzation (%)</b></td>
<td align=center><b>Avg Mem Utilization (%)</b></td>
<td align=center><b>Avg Disk Write IO (count)</b></td>
<td align=center><b>Avg Disk Read IO (count)</b></td>
<td align=center><b>Avg Disk Write Bytes</b></td>
<td align=center><b>Avg Disk Read Bytes</b></td>
<td align=center><b>Avg Net In (b)</b></td>
<td align=center><b>Avg Net Out (b)</b></td>
"""

auth = AwsAuthenticator(account=args.account,role=args.role)
result = auth.getKeys()
key_id = result["aws_access_key_id"]
access_key = result["aws_secret_access_key"]
token = result["security_token"]

if args.regions == 'all':
	regions = ['us-east-1','us-west-1','us-west-2','sa-east-1','eu-west-1','eu-central-1','ap-southeast-2','ap-southeast-1','ap-northeast-1']
else:
	regions = [args.regions]

for region in regions:
	ec2 = boto3.resource('ec2',region_name=region, aws_access_key_id=key_id, aws_secret_access_key=access_key, aws_session_token=token)
	cw = boto3.resource('cloudwatch',region_name=region, aws_access_key_id=key_id, aws_secret_access_key=access_key, aws_session_token=token)
	instances = ec2.instances.filter(Filters=[{'Name': 'instance-state-name', 'Values': ['running']}])
	for instance in instances:
		html+= "<tr>";
		###################### CPU #################################
		metric = cw.Metric('AWS/EC2','CPUUtilization')
		listz = metric.get_statistics(StartTime=start,EndTime=end,Period=60,Statistics=['Average'], Dimensions=[{'Name' : 'InstanceId', 'Value' : instance.id},])
		for key,val in listz.items():
			if key == "Datapoints":
				avgCPUpct=0
				avgCPUtot=0
				cpucnt=0
				for item in val:
					rvalues=""
					for ki in item:
						if ki == "Average":
							cpucnt=cpucnt+1
							avgCPUtot=avgCPUtot+item[ki]
						#print ki, item[ki]
				if cpucnt>0:
					avgCPUpct = avgCPUtot / cpucnt

		###################### MEM #################################
		metric = cw.Metric('AWS/EC2','MemoryUtilization')
		listz = metric.get_statistics(StartTime=start,EndTime=end,Period=60,Statistics=['Average'], Dimensions=[{'Name' : 'InstanceId', 'Value' : instance.id},])
		for key,val in listz.items():
			if key == "Datapoints":
				avgMEM=0
				avgMEMtot=0
				cpucnt=0
				for item in val:
					rvalues=""
					for ki in item:
						if ki == "Average":
							cpucnt=cpucnt+1
							avgMEMtot=avgMEMtot+item[ki]
				#print ki, item[ki]
				if cpucnt>0:
					avgMEM = avgMEMtot / cpucnt

		###################### DiskWriteOps #################################
		metric = cw.Metric('AWS/EC2','DiskWriteOps')
		listz = metric.get_statistics(StartTime=start,EndTime=end,Period=60,Statistics=['Average'], Dimensions=[{'Name' : 'InstanceId', 'Value' : instance.id},])
		for key,val in listz.items():
			if key == "Datapoints":
				avgDWIO=0
				avgDWIOtot=0
				cpucnt=0
				for item in val:
					rvalues=""
					for ki in item:
						if ki == "Average":
							cpucnt=cpucnt+1
							avgDWIOtot=avgDWIOtot+item[ki]
						#print ki, item[ki]
				if cpucnt>0:
					avgDWIO = avgDWIOtot / cpucnt

		###################### DiskReadOps #################################
		metric = cw.Metric('AWS/EC2','DiskReadOps')
		listz = metric.get_statistics(StartTime=start,EndTime=end,Period=60,Statistics=['Average'], Dimensions=[{'Name' : 'InstanceId', 'Value' : instance.id},])
		for key,val in listz.items():
			if key == "Datapoints":
				avgDRIO=0
				avgDRIOtot=0
				cpucnt=0
				for item in val:
					rvalues=""
					for ki in item:
						if ki == "Average":
							cpucnt=cpucnt+1
							avgDRIOtot=avgDRIOtot+item[ki]
						#print ki, item[ki]
				if cpucnt>0:
					avgDRIO = avgDRIOtot / cpucnt

		###################### DiskWriteBytes #################################
		metric = cw.Metric('AWS/EC2','DiskWriteBytes')
		listz = metric.get_statistics(StartTime=start,EndTime=end,Period=60,Statistics=['Average'], Dimensions=[{'Name' : 'InstanceId', 'Value' : instance.id},])
		for key,val in listz.items():
			if key == "Datapoints":
				avgDWB=0
				avgDWBtot=0
				cpucnt=0
				for item in val:
					rvalues=""
					for ki in item:
						if ki == "Average":
							cpucnt=cpucnt+1
							avgDWBtot=avgDWBtot+item[ki]
						#print ki, item[ki]
				if cpucnt>0:
					avgDWB = avgDWBtot / cpucnt

		###################### DiskReadBytes #################################
		metric = cw.Metric('AWS/EC2','DiskReadBytes')
		listz = metric.get_statistics(StartTime=start,EndTime=end,Period=60,Statistics=['Average'], Dimensions=[{'Name' : 'InstanceId', 'Value' : instance.id},])
		for key,val in listz.items():
			if key == "Datapoints":
				avgDRB=0
				avgDRBtot=0
				cpucnt=0
				for item in val:
					rvalues=""
					for ki in item:
						if ki == "Average":
							cpucnt=cpucnt+1
							avgDRBtot=avgDRBtot+item[ki]
						#print ki, item[ki]
				if cpucnt>0:
					avgDRB = avgDRBtot / cpucnt


		###################### Network In #################################
		metric = cw.Metric('AWS/EC2','NetworkIn')
		listz = metric.get_statistics(StartTime=start,EndTime=end,Period=60,Statistics=['Average'], Dimensions=[{'Name' : 'InstanceId', 'Value' : instance.id},])
		for key,val in listz.items():
			if key == "Datapoints":
				avgNETI=0
				avgNETItot=0
				cpucnt=0
				for item in val:
					rvalues=""
					for ki in item:
						if ki == "Average":
							cpucnt=cpucnt+1
							avgNETItot=avgNETItot+item[ki]
						#print ki, item[ki]
				if cpucnt>0:
					avgNETI = avgNETItot / cpucnt

		###################### Network Out #################################
		metric = cw.Metric('AWS/EC2','NetworkOut')
		listz = metric.get_statistics(StartTime=start,EndTime=end,Period=60,Statistics=['Average'], Dimensions=[{'Name' : 'InstanceId', 'Value' : instance.id},])
		for key,val in listz.items():
			if key == "Datapoints":
				avgNETO=0
				avgNETOtot=0
				cpucnt=0
				for item in val:
					rvalues=""
					for ki in item:
						if ki == "Average":
							cpucnt=cpucnt+1
							avgNETOtot=avgNETOtot+item[ki]
						#print ki, item[ki]
				if cpucnt>0:
					avgNETO = avgNETOtot / cpucnt

		html+= "<td>" + region + "</td>\n";
		html+= "<td>" + instance.id + "</td>\n";
		html+= "<td>" + instance.private_ip_address + "</td>\n";
		html+= "<td>" + instance.image.id + "</td>\n";
		html+= "<td>" + instance.instance_type + "</td>\n";
		html+= "<td>" + str(avgCPUpct) + "</td>\n";
		html+= "<td>" + str(avgMEM) + "</td>\n";
		html+= "<td>" + str(avgDWIO) + "</td>\n";
		html+= "<td>" + str(avgDRIO) + "</td>\n";
		html+= "<td>" + str(avgDWB) + "</td>\n";
		html+= "<td>" + str(avgDRB) + "</td>\n";
		html+= "<td>" + str(avgNETI) + "</td>\n";
		html+= "<td>" + str(avgNETO) + "</td>\n";
		print region + "," + instance.id + "," +instance.image.id + "," +instance.instance_type + "," +instance.private_ip_address + "," + str(avgCPUpct) + "," + str(avgMEM) + "," + str(avgDWIO) + "," + str(avgDRIO) + "," + str(avgDWB) + "," + str(avgDRB) + "," + str(avgNETI) + "," + str(avgNETO)
html+="</html>"
mailpart = MIMEText(html, 'html')
msg.attach(mailpart)
s = smtplib.SMTP('localhost')
s.sendmail(me, you, msg.as_string())
s.quit()
