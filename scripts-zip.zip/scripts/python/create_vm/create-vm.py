import atexit

from pyVim.connect import SmartConnect, Disconnect
import argparse
import ssl
from pyVmomi import vim
import sys
import yaml
from hurry.filesize import size, iec


def get_args():
    parser = argparse.ArgumentParser(
        description='Process args for retrieving all the Virtual Machines')
    parser.add_argument('-s', '--host', required=False, action='store', help='Remote host to connect to')
    parser.add_argument('-o', '--port', type=int, default=443, action='store', help='Port to connect on')
    parser.add_argument('-u', '--user', required=False, action='store', help='User name to use when connecting to host')
    parser.add_argument('-p', '--password', required=False, action='store', help='Password to use when connecting to host')
    parser.add_argument('-c', '--config', required=False, action='store', help='YAML config file from SE repo')
    parser.add_argument('-d', '--datacenter', required=True, action='store', help="datacenter name abbreviation, ex: m-ar, ln, ch")
    args = parser.parse_args()
    return args

def load_config(config):
   with open(config) as y:
      doc = yaml.load(y)

   return doc


def find_host(cluster, ratio):
    print ("Checking for host that match esx ratio")
    for h in cluster.host:
        count = 0

        for vm in h.vm:
            if vm.runtime.powerState == "poweredOn":
                count += 1

        if count < ratio:
            print "Using %s with %d vms" % (h.name, count)
            return h

        if count > ratio:
            continue


def get_object(content, vimtype, name):
    mob = None
    container = content.viewManager.CreateContainerView(
        content.rootFolder, vimtype, True)

    for i in container.view:
        if i.name == name or name in i.name:
            mob = i
            break

    if mob is None:
        print("ERROR: OBJECT NOT FOUND: " + name)
        sys.exit(1)

    return mob

def main():
    args = get_args()
    config = load_config(args.config)

    ssl._create_default_https_context = ssl._create_unverified_context
    si = None

    #TODO get vm info from service now
    vm_name = "llavin-test"

    dc = args.datacenter
    try:
        si = SmartConnect(host=config[dc]['esxhost'],
                          user=config[dc]['esxuser'],
                          pwd=config[dc]['esxpwd'],
                          port=int(args.port))

        content = si.content

    except vim.fault.InvalidLogin:
        print "ERROR: Invalid Login - Could not connect to vCenter server."
        exit(1)


    datacenter_name = config[dc]['esxdatacenter']
    cluster_name = config[dc]['cluster']
    esx_ratio = config[dc]['esxratio']

    print "DATE:", si.CurrentTime()

    datacenter = get_object(content, [vim.Datacenter], datacenter_name)
    cluster = get_object(content, [vim.ClusterComputeResource], cluster_name)

    host = find_host(cluster, esx_ratio)
    vm_folder = datacenter.vmFolder
    #TODO find_datastore()

    for ds in host.datastore:
        print ds.name
        print ds.summary.freeSpace, "bytes"
        print bytes_to_size(ds.summary.freeSpace, "Gi"), "GiB"

    datastore = "[MTN-AR-3PAR-8200:m-ar0vmh-Datastore1]"
    datastore_path = datastore + vm_name

    vmx_file = vim.vm.FileInfo(logDirectory=None,
                               snapshotDirectory=None,
                               suspendDirectory=None,
                               vmPathName=datastore_path)

    vm_config = vim.vm.ConfigSpec(name="llavin-test", memoryMB=2048, numCPUs=2,
                                  files=vmx_file, guestId='centos64Guest', version='vmx-10')

    #vm_folder.CreateVM_Task(config=vm_config, pool=cluster.resourcePool)

    atexit.register(Disconnect, si)

def bytes_to_size(num, unit):
    for fmt in ['Ki','Mi','Gi','Ti','Pi','Ei','Zi']:
        num /= 1024
        if unit in fmt:
           return num


if __name__ == '__main__':
    main()

