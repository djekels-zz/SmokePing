import unittest
import rstr
import logging
import names
import random
from pprint import pprint
from SiteServer.tools.argv import args_parser, classify_host_gen, sna_lookup_gen, add_args_parser

class AddArgsParserTest(unittest.TestCase):
    def setUp(self):
        self.options = lambda: None
        self.lgr = logging.getLogger(__name__)

    def test_classify_host_gen(self):
        self.hosts = [
            'ch0log151',
            'gla0ss28',
            'ar2vm91',
            'ny2vm59',
            'sg0srv214',
            'ty0srv32',
            'ln2vm103'
        ]

        for _ in range(1, 11):
            self.options.action = 'add'
            self.options.name = random.choice(self.hosts)
            self.options.ip = rstr.xeger(r'^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$')
            self.options.mac = rstr.xeger(r'^([0-9a-fA-F][0-9a-fA-F]:){5}([0-9a-fA-F][0-9a-fA-F])$')
            self.options.os_ver = rstr.xeger(r'^(6\.9|6\.10|7\.4\.1708|7\.6\.1810)$')
            self.options.hst_type = rstr.xeger(r'^(oc|OC|gp|GP|vm|VM|esxi|ESXI)$')
            self.options.hst_gen = rstr.xeger(r'^((gen|Gen)(7|8|9|10|11)|)$')
            self.options.not_snow = None
            args = add_args_parser(options=self.options)
            pprint(args)
            self.lgr.info("Found the following Driverdisk: %s", args.drv_dsk)
            self.assertRegex(args.drv_dsk, r'(.*\.iso|)')
            self.lgr.info("Found the following Host Gen: %s", args.hst_gen)
            self.assertRegex(args.hst_gen, r'(Gen([ ]{0,1})(6|7|8|9|10|11)|)')

class ClassifyHostTest(unittest.TestCase):
    def setUp(self):
        self.sn_host = {}
        self.options = lambda: None
        self.lgr = logging.getLogger(__name__)

    def test_classify_host_gen(self):
        self.sn_host['model_id'] = {}
        for _ in range(1, 11):
            self.sn_host['model_id']['display_value'] = rstr.xeger(r'^(gen|Gen|g|G)([ ]{0,1})(6|7|8|9|10|11)$')
            self.options.os_ver = rstr.xeger(r'^(6\.9|6\.10|7\.4\.1708|7\.6\.1810)$')
            self.options.hst_gen = ""
            self.lgr.info("Testing os_ver: %s - hst_gen: %s", self.options.os_ver, \
                          self.sn_host['model_id']['display_value'])
            classify = classify_host_gen(self.sn_host, self.options)
            self.lgr.info("Found the following Driverdisk: %s", classify.drv_dsk)
            self.assertRegex(classify.drv_dsk, r'(.*\.iso|)')
            self.lgr.info("Found the following Host Gen: %s", classify.hst_gen)
            self.assertRegex(classify.hst_gen, r'(Gen (6|7|8|9|10|11))')

class SnowPullTest(unittest.TestCase):
    def setUp(self):
        self.hosts = [
            'ch0log151',
            'gla0ss28',
            'ar2vm91',
            'ny2vm59',
            'sg0srv214',
            'ty0srv32',
            'ln2vm103'
        ]
        self.options = lambda: None
        self.lgr = logging.getLogger(__name__)

    def test_classify_host_gen(self):
        logging.basicConfig(level=logging.INFO)
        for _ in range(1, 11):
            self.options.name = random.choice(self.hosts)
            self.lgr.info("Testing SNOW Lookup with hostname: %s", self.options.name)
            lookup = sna_lookup_gen(self.options)
            self.assertIsNotNone(lookup)

class ParserTest(unittest.TestCase):
    def setUp(self):
        self.parser = args_parser()
        self.lgr = logging.getLogger(__name__)

    def test_version_short(self):
        parsed = self.parser.parse_args(['-v'])
        self.assertTrue(parsed.version)

    def test_version_long(self):
        parsed = self.parser.parse_args(['--version'])
        self.assertTrue(parsed.version)

    def test_cron_short(self):
        parsed = self.parser.parse_args(['-c'])
        self.assertTrue(parsed.cron)

    def test_cron_long(self):
        parsed = self.parser.parse_args(['--cron'])
        self.assertTrue(parsed.cron)

    def test_add_short(self):
        parsed = self.parser.parse_args(['-a'])
        self.assertTrue(parsed.add)

    def test_add_long(self):
        parsed = self.parser.parse_args(['--add'])
        self.assertTrue(parsed.add)

    def test_delete_short(self):
        parsed = self.parser.parse_args(['-d'])
        self.assertTrue(parsed.delete)

    def test_delete_long(self):
        parsed = self.parser.parse_args(['--delete'])
        self.assertTrue(parsed.delete)

    def test_lookup_short(self):
        parsed = self.parser.parse_args(['-l'])
        self.assertTrue(parsed.lookup)

    def test_lookup_long(self):
        parsed = self.parser.parse_args(['--lookup'])
        self.assertTrue(parsed.lookup)

    def test_only_files_short(self):
        parsed = self.parser.parse_args(['-of'])
        self.assertTrue(parsed.only_files)

    def test_only_files_long(self):
        parsed = self.parser.parse_args(['--only_files'])
        self.assertTrue(parsed.only_files)

    def test_software_raid_short(self):
        parsed = self.parser.parse_args(['-swr'])
        self.assertTrue(parsed.software_raid)

    def test_software_raid_long(self):
        parsed = self.parser.parse_args(['--software_raid'])
        self.assertTrue(parsed.software_raid)

    def test_not_snow_short(self):
        parsed = self.parser.parse_args(['-nsn'])
        self.assertTrue(parsed.not_snow)

    def test_not_snow_long(self):
        parsed = self.parser.parse_args(['--not_snow'])
        self.assertTrue(parsed.not_snow)

    def test_from_it_short(self):
        parsed = self.parser.parse_args(['-fit'])
        self.assertTrue(parsed.from_it)

    def test_from_it_long(self):
        parsed = self.parser.parse_args(['--from_it'])
        self.assertTrue(parsed.from_it)

    def test_name_short(self):
        for _ in range(1, 11):
            host = rstr.xeger(r'((?:m\-|m)(ch|CH|ar|AR|ny|NY|ty|TY)|(ch|CH|ar|AR|ny|NY|ty|TY))([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])(srv|SRV|vm|VM|vmh|VMH)([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])')
            self.lgr.info("Testing Hostname %s", host)
            parsed = self.parser.parse_args(['-n', host])
            self.assertEqual(parsed.name, host)

    def test_name_long(self):
        for _ in range(1, 11):
            host = rstr.xeger(r'((?:m\-|m)(ch|CH|ar|AR|ny|NY|ty|TY)|(ch|CH|ar|AR|ny|NY|ty|TY))([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])(srv|SRV|vm|VM|vmh|VMH)([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])')
            self.lgr.info("Testing Hostname %s", host)
            parsed = self.parser.parse_args(['--name', host])
            self.assertEqual(parsed.name, host)

    def test_ip_short(self):
        for _ in range(1, 11):
            ip_addr = rstr.xeger(r'^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$')
            print("Testing IP Address %s" % ip_addr)
            parsed = self.parser.parse_args(['-i', ip_addr])
            self.assertEqual(parsed.ip, ip_addr)

    def test_ip_long(self):
        for _ in range(1, 11):
            ip_addr = rstr.xeger(r'^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$')
            print("Testing IP Address %s" % ip_addr)
            parsed = self.parser.parse_args(['--ip', ip_addr])
            self.assertEqual(parsed.ip, ip_addr)

    def test_mac_short(self):
        for _ in range(1, 11):
            mac = rstr.xeger(r'^([0-9a-fA-F][0-9a-fA-F]:){5}([0-9a-fA-F][0-9a-fA-F])$')
            print("Testing MAC Address %s" % mac)
            parsed = self.parser.parse_args(['-m', mac])
            self.assertEqual(parsed.mac, mac)

    def test_mac_long(self):
        for _ in range(1, 11):
            mac = rstr.xeger(r'^([0-9a-fA-F][0-9a-fA-F]:){5}([0-9a-fA-F][0-9a-fA-F])$')
            print("Testing MAC Address %s" % mac)
            parsed = self.parser.parse_args(['--mac', mac])
            self.assertEqual(parsed.mac, mac)

    def test_os_ver_short(self):
        for _ in range(1, 11):
            os_ver = rstr.xeger(r'^(6\.9|6\.10|7\.4\.1708|7\.6\.1810)$')
            print("Testing os ver Address %s" % os_ver)
            parsed = self.parser.parse_args(['-o', os_ver])
            self.assertEqual(parsed.os_ver, os_ver)

    def test_os_ver_long(self):
        for _ in range(1, 11):
            os_ver = rstr.xeger(r'^(6\.9|6\.10|7\.4\.1708|7\.6\.1810)$')
            print("Testing os ver Address %s" % os_ver)
            parsed = self.parser.parse_args(['--os_ver', os_ver])
            self.assertEqual(parsed.os_ver, os_ver)

    def test_bootloader_short(self):
        for _ in range(1, 11):
            bootloader = rstr.xeger(r'^(mbr|MBR|efi|EFI)$')
            print("Testing bootloader Address %s" % bootloader)
            parsed = self.parser.parse_args(['-b', bootloader])
            self.assertEqual(parsed.bootloader, bootloader)

    def test_bootloader_long(self):
        for _ in range(1, 11):
            bootloader = rstr.xeger(r'^(mbr|MBR|efi|EFI)$')
            print("Testing bootloader Address %s" % bootloader)
            parsed = self.parser.parse_args(['--bootloader', bootloader])
            self.assertEqual(parsed.bootloader, bootloader)

    def test_hst_type_short(self):
        for _ in range(1, 11):
            hst_type = rstr.xeger(r'^(oc|OC|gp|GP|vm|VM|esxi|ESXI)$')
            print("Testing hst_type %s" % hst_type)
            parsed = self.parser.parse_args(['-ht', hst_type])
            self.assertEqual(parsed.hst_type, hst_type)

    def test_hst_type_long(self):
        for _ in range(1, 11):
            hst_type = rstr.xeger(r'^(oc|OC|gp|GP|vm|VM|esxi|ESXI)$')
            print("Testing hst_type %s" % hst_type)
            parsed = self.parser.parse_args(['--hst_type', hst_type])
            self.assertEqual(parsed.hst_type, hst_type)

    def test_hst_gen_short(self):
        for _ in range(1, 11):
            hst_gen = rstr.xeger(r'^(gen|Gen)(7|8|9|10|11)$')
            print("Testing hst_gen %s" % hst_gen)
            parsed = self.parser.parse_args(['-hg', hst_gen])
            self.assertEqual(parsed.hst_gen, hst_gen)

    def test_hst_gen_long(self):
        for _ in range(1, 11):
            hst_gen = rstr.xeger(r'^(gen|Gen)(7|8|9|10|11)$')
            print("Testing hst_gen %s" % hst_gen)
            parsed = self.parser.parse_args(['--hst_gen', hst_gen])
            self.assertEqual(parsed.hst_gen, hst_gen)

    def test_vlan_base_short(self):
        for _ in range(1, 11):
            vlan_base = rstr.xeger(r'^[1-9]{1,2}$')
            print("Testing vlan_base %s" % vlan_base)
            parsed = self.parser.parse_args(['-vb', vlan_base])
            self.assertEqual(parsed.vlan_base, vlan_base)

    def test_vlan_base_long(self):
        for _ in range(1, 11):
            vlan_base = rstr.xeger(r'^[1-9]{1,2}$')
            print("Testing vlan_base %s" % vlan_base)
            parsed = self.parser.parse_args(['--vlan_base', vlan_base])
            self.assertEqual(parsed.vlan_base, vlan_base)

    def test_it_user_short(self):
        for _ in range(1, 11):
            fname = names.get_first_name()
            lname = names.get_last_name()
            it_user = "%s%s" % (fname[:1].lower(), lname.lower())
            self.lgr.info("Testing it_user %s", it_user)
            parsed = self.parser.parse_args(['-iu', it_user])
            self.assertEqual(parsed.it_user, it_user)

    def test_it_user_long(self):
        for _ in range(1, 11):
            fname = names.get_first_name()
            lname = names.get_last_name()
            it_user = "%s%s" % (fname[:1].lower(), lname.lower())
            self.lgr.info("Testing it_user %s", it_user)
            parsed = self.parser.parse_args(['--it_user', it_user])
            self.assertEqual(parsed.it_user, it_user)

if __name__ == '__main__':
    unittest.main()
