import logging
import os
import shutil
import threading

import unittest

if not os.environ.get("DISABLE_LOGGING", False):
    logging.basicConfig(
        level=logging.INFO,
        # Also make sure to set up timestamping for more sanity when debugging.
        format="[%(relativeCreated)s]\t%(levelname)s:%(name)s:%(message)s",
        datefmt="%H:%M:%S",
    )

