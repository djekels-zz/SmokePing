import unittest
import rstr
import logging
import names
import random
from pprint import pprint
from SiteServer.tools.hpe import TTHpe


class DriverDiskTest(unittest.TestCase):
    def setUp(self):
        self.gen = None
        self.os_name = "centos"
        self.os_ver = None
        self.hpe = TTHpe()
        self.lgr = logging.getLogger(__name__)

    def test_driver_disk(self):
        for _ in range(1, 11):
            self.gen = rstr.xeger(r'^((gen|Gen)(7|8|9|10|11))$')
            self.os_name = "centos"
            self.os_ver = rstr.xeger(r'^(6\.9|6\.10|7\.4\.1708|7\.6\.1810)$')
            test = self.hpe.driver_disk(gen=self.gen, os_name=self.os_name, os_ver=self.os_ver)
            self.assertRegex(str(test), r'(.*\.iso|)')

class BlackListTest(unittest.TestCase):
    def setUp(self):
        self.gen = None
        self.hpe = TTHpe()
        self.lgr = logging.getLogger(__name__)

    def test_driver_disk(self):
        for _ in range(1, 11):
            self.gen = rstr.xeger(r'^((gen|Gen)(7|8|9|10|11))$')
            test = self.hpe.black_list(gen=self.gen)
            self.assertRegex(str(test), r'(ahci|)')

if __name__ == '__main__':
    unittest.main()
