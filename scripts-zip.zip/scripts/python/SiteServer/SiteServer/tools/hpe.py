"""hpe.py

This is where we put specific defaults for varios hpe systems...
"""
import logging
from stringcase import pascalcase, snakecase

HPE = {
    'Gen6': {
        'centos': {
            '6.9': {
                'driver_disk': ''
            },
            '6.10': {
                'driver_disk': ''
            },
            '7.4.1708': {
                'driver_disk': ''
            },
            '7.6.1810': {
                'driver_disk': ''
            },
            '7.8.2003': {
                'driver_disk': ''
            },
            '7.9.2009': {
                'driver_disk': ''
            },
            '8.0.1905': {
                'driver_disk': ''
            },
            '8.1.1911': {
                'driver_disk': ''
            },
            '8.2.2004': {
                'driver_disk': ''
            }
        },
        'black_list': ''
    },
    'Gen7': {
        'centos': {
            '6.9': {
                'driver_disk': ''
            },
            '6.10': {
                'driver_disk': ''
            },
            '7.4.1708': {
                'driver_disk': ''
            },
            '7.6.1810': {
                'driver_disk': ''
            },
            '7.8.2003': {
                'driver_disk': ''
            },
            '7.9.2009': {
                'driver_disk': ''
            },
            '8.0.1905': {
                'driver_disk': ''
            },
            '8.1.1911': {
                'driver_disk': ''
            },
            '8.2.2004': {
                'driver_disk': ''
            }
        },
        'black_list': ''
    },
    'Gen8': {
        'centos': {
            '6.9': {
                'driver_disk': 'hpvsa-1.2.16-122.rhel6u9.x86_64.iso'
            },
            '6.10': {
                'driver_disk': 'hpvsa-1.2.16-122.rhel6u10.x86_64.dd'
            },
            '7.4.1708': {
                'driver_disk': 'hpvsa-1.2.16-121.rhel7u4.x86_64.iso'
            },
            '7.6.1810': {
                'driver_disk': 'hpvsa-1.2.16-125.rhel7u6.x86_64.iso'
            },
            '7.8.2003': {
                'driver_disk': ''
            },
            '7.9.2009': {
                'driver_disk': ''
            },
            '8.0.1905': {
                'driver_disk': ''
            },
            '8.1.1911': {
                'driver_disk': ''
            },
            '8.2.2004': {
                'driver_disk': ''
            }
        },
        'black_list': 'ahci'
    },
    'Gen9': {
        'centos': {
            '6.9': {
                'driver_disk': 'hpdsa-1.2.10-139.rhel6u9.x86_64.iso'
            },
            '6.10': {
                'driver_disk': 'hpdsa-1.2.10-139.rhel6u10.x86_64.iso'
            },
            '7.4.1708': {
                'driver_disk': 'hpdsa-1.2.10-139.rhel7u4.x86_64.iso'
            },
            '7.6.1810': {
                'driver_disk': 'hpdsa-1.2.10-176.rhel7u6.x86_64.iso'
            },
            '7.9.2009': {
                'driver_disk': ''
            },
            '7.8.2003': {
                'driver_disk': 'hpdsa-1.2.10-179.rhel7u8.x86_64.iso'
            },
            '8.0.1905': {
                'driver_disk': 'hpdsa-1.2.10-160.rhel8u0.x86_64.iso'
            },
            '8.1.1911': {
                'driver_disk': ''
            },
            '8.2.2004': {
                'driver_disk': ''
            }
        },
        'black_list': 'ahci'
    },
    'Gen10': {
        'centos': {
            '6.9': {
                'driver_disk': ''
            },
            '6.10': {
                'driver_disk': ''
            },
            '7.4.1708': {
                'driver_disk': ''
            },
            '7.6.1810': {
                'driver_disk': ''
            },
            '7.8.2003': {
                'driver_disk': ''
            },
            '7.9.2009': {
                'driver_disk': 'hpdsa-1.2.10-184.rhel7u9.x86_64.iso'
            },
            '8.0.1905': {
                'driver_disk': ''
            },
            '8.1.1911': {
                'driver_disk': ''
            },
            '8.2.2004': {
                'driver_disk': ''
            }
        },
        'black_list': ''
    },
    'Gen11': {
        'centos': {
            '6.9': {
                'driver_disk': ''
            },
            '6.10': {
                'driver_disk': ''
            },
            '7.4.1708': {
                'driver_disk': ''
            },
            '7.6.1810': {
                'driver_disk': ''
            },
            '7.9.2009': {
                'driver_disk': ''
            },
            '7.8.2003': {
                'driver_disk': ''
            },
            '8.0.1905': {
                'driver_disk': ''
            },
            '8.1.1911': {
                'driver_disk': ''
            },
            '8.2.2004': {
                'driver_disk': ''
            }
        },
        'black_list': ''
    }
}

class TTHpe(object):
    """TTHpe

    Class for getting data about HPE hardware

    Doing presentation for team

    """
    def __init__(self):
        self.hpe = HPE
        self.log = logging.getLogger(__name__)

    def driver_disk(self, gen, os_name, os_ver):
        """
        Function: driver_disk
        Summary: search the list of hardware to get the right driver disk image...
        Examples: driver_disk(gen="Gen 8", os_ver="6.9") ||
                  driver_disk(gen="Gen10", os_ver="7.4.1708")
        Attributes:
            @param (gen):HPE Gen
            @param (os_name):OS to use (CentOS|Ubuntu|...)
                       (this is more for future use...)
            @param (os_ver): Which OS Version you are looking to use
        Returns: Driver Disk iso name
        """

        gen = pascalcase("".join(gen.split()))
        ret = HPE.get(gen, {}).get(os_name, {}).get(os_ver, {}).get('driver_disk')
        self.log.info("Found driver disk for: %s for %s", ret, gen)

        return ret

    def black_list(self, gen):
        """
        Function: black_list
        Summary: Get blacklist from list of HPE settings
        Examples: black_list(gen="Gen 8")
        Attributes:
            @param (gen):HPE Gen
        Returns: Blacklist string
        """

        gen = pascalcase("".join(gen.split()))
        ret = HPE.get(gen, {}).get('black_list')
        self.log.info("Found blacklist disk driver: %s for %s", ret, gen)

        return ret
