import sqlite3

CON = sqlite3.connect('/opt/debesys/SysEng/siteserver.sqlite3')

class Stats():
    def __init__(self):
        self.con = sqlite3.connect('/opt/debesys/SysEng/siteserver.sqlite3')
        self.cur = self.con.cursor()


        leases_sql = """
        CREATE TABLE if not exists leases  (
            leaseId integer PRIMARY KEY,
            hostname text not null,
            added datetime,
            removed datetime,
            pointer_filepath text,
            ks_filepath text,
            mac text not null,
            mac2 text,
            mac3 text,
            mac4 text,
            mac5 text,
            ip_addr text not null,
            vlan_base text not null,
            os_ver text not null,
            timezone text not null,
            hst_type text not null,
            hst_gen text,
            software_raid boolean,
            via text not null)"""

        self.cur.execute(leases_sql)

    def addLease(self, args):
        ins = "INSERT INTO leases (hostname, added, mac, \
               mac2, mac3, mac4, mac5, ip_addr, vlan_base, os_ver, timezone, hst_type, \
               hst_gen, software_raid, via) VALUES('%s', DateTime('now'), '%s', '%s', \
               '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')" % \
               (args['hostname'], args['mac'], args['mac2'], args['mac3'], \
               args['mac4'], args['mac5'], args['ip_addr'], args['vlan_base'], \
               args['os_ver'], args['timezone'], args['hst_type'], args['hst_gen'], \
               args['software_raid'], args['via'])
        self.cur.execute(ins)
        self.con.commit()

    def addLeaseFiles(self, args):
        if args['fileType'] == "pointer":
            upd = "UPDATE leases SET pointer_filepath = %s WHERE hostname = '%s' " \
                  "AND mac = '%s'" % (args['filepath'], args['hostname'], args['mac'])
        elif args['fileType'] == "ks":
            upd = "UPDATE leases SET ks_filepath = %s WHERE hostname = '%s' " \
                  "AND mac = '%s'" % (args['filepath'], args['hostname'], args['mac'])
        self.cur.execute(upd)
        self.con.commit()

