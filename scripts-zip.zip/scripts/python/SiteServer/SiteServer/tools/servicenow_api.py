import json
import requests
import argparse
import logging
import time
import uuid
import random
from requests.exceptions import Timeout as RequestsTimeout

logger = logging.getLogger(__name__)

sn_user = 'svc-elsrw'
sn_pwd = 'P8pcqQdf'
sn_url = 'https://tradingtech.service-now.com/api'

class ServiceNowTableLock(object):
    def __init__(self, table_name):
        self.table_to_lock = table_name
        self.sn_user = sn_user
        self.sn_pwd = sn_pwd
        self.lock_table = 'u_ip_table_lock'
        self.sn_url = sn_url + "/now/table/" + self.lock_table
        self.sn_auth = (self.sn_user, self.sn_pwd)
        self.headers = {"Accept": "application/json", "Content-Type": "application/json"}
        self.guid = str(uuid.uuid4())
        self.sys_id = None
        self.timeout = 30 #minutes

    def is_locked(self):
        """Check if the table is locked.  Return False if not, otherwise return GUID holding the lock."""

        logger.info("Checking lock status for table {}".format(self.table_to_lock))
        querystring = {'sysparm_limit': '10', 'sysparm_display_value': 'true', 'sysparm_query': 'u_table_name=' + self.table_to_lock}

        try:
            r = requests.get(self.sn_url, auth=self.sn_auth, headers=self.headers, params=querystring, timeout=1)
            response = r.json()
            r.raise_for_status()
        except RequestsTimeout:
            # If we're unable to check the lock due to a timeout, pretend that the table is locked so we'll just wait and try again later
            logger.info("Timed out checking lock status")
            return "Timedout"
        except Exception as e:
            errmsg = "Error querying ServiceNow API: {}".format(str(e))
            logger.error(errmsg)
            raise Exception(errmsg)

        if len(response['result']) > 1:
            errmsg = "More than one row in {} matches search for u_table_name of {}".format(self.lock_table, self.table_to_lock)
            logger.error(errmsg)
            raise ValueError(errmsg)

        if len(response['result']) < 0:
            # This can't happen, right?
            errmsg = "Fewer than zero rows in {} match search for u_table_name of {}.  What does that mean?".format(self.lock_table, self.table_to_lock)
            logger.error(errmsg)
            raise ValueError(errmsg)

        if len(response['result']) == 0:
            return False
        
        try:
            # Take this opportunity to save the sys_id for this row for later
            self.sys_id = response['result'][0]['sys_id']
            if response['result'][0]['u_guid'] == "":
                return False
            else:
                return response['result'][0]['u_guid']
        except KeyError as e:
            errmsg = "Error finding sys_id or u_guid field in {}.  Error message was: {}".format(self.lock_table, str(e))
            logger.error(errmsg)
            raise KeyError(errmsg)

    def __attempt_get_lock(self):
        """Try to lock the table.  Return True if successful, False if unsuccessful."""

        lock = self.is_locked()
        if lock == self.guid:
            logger.debug("I already own the lock")
            return True
        elif lock:
            logger.debug("Lock is held by someone else")
            return False
        else:
            logger.debug("No one has the lock, attempting to grab it")
            payload = {'u_guid': self.guid}

            try:
                if self.sys_id == None:
                    logger.debug("No record for table {} was found, creating.".format(self.table_to_lock))
                    payload['u_table_name'] = self.table_to_lock
                    r = requests.post(self.sn_url, auth=self.sn_auth, headers=self.headers, timeout=1, data=json.dumps(payload))
                    r.raise_for_status()
                else:
                    logger.debug("Updating record for table {}".format(self.table_to_lock))
                    r = requests.put(self.sn_url + "/" + self.sys_id, auth=self.sn_auth, headers=self.headers, timeout=1, data=json.dumps(payload))
                    r.raise_for_status()
            except RequestsTimeout:
                # If our call to Service Now times out, just count it as a failed attempt and move on.  We'll probably try again, anyways.
                logger.info("Timed out trying to grab lock")
                pass

            # Sleep for a short period and then check to see if we sucessfully got the lock
            # There could be a second or two between our first check and setting the lock, so I think
            # checking again after a short sleep should help us detect if our lock has been trampled
            time.sleep(6)
            if self.is_locked() == self.guid:
                logger.debug("Looks like I was successful getting the lock")
                return True
            else:
                logger.debug("Someone trampled me")
                return False

    def get_lock(self):
        """Repeatedly attempts to grab the lock until the self.timeout period has elapsed"""
        start_time = time.time()

        while True:
            got_lock = self.__attempt_get_lock()
            elapsed_time = time.time() - start_time

            if got_lock:
                logger.info('Got lock in {} seconds'.format(elapsed_time))
                return True
            
            if elapsed_time > self.timeout * 60:
                errmsg = 'Giving up on locking {} after {} seconds'.format(self.table_to_lock, elapsed_time)
                logger.critical(errmsg)
                raise Exception(errmsg)

            # Sleep for a random number of seconds to reduce chances of multiple runs retrying at the exact same time
            time.sleep(random.randint(5, 30))

    def release_lock(self):
        """Release the lock"""

        lock = self.is_locked()

        if lock and lock != self.guid:
            errmsg = "Trying to release a lock we don't own!"
            logger.error(errmsg)
            raise Exception(errmsg)
        else:
            payload = {'u_guid': ""}

            try:
                r = requests.put(self.sn_url + "/" + self.sys_id, auth=self.sn_auth, headers=self.headers, timeout=1, data=json.dumps(payload))
                r.raise_for_status()
            except Exception as e:
                errmsg = "Error talking to ServiceNow trying to release the lock: {}".format(str(e))
                logger.error(errmsg)
                raise Exception(errmsg)

    def __enter__(self):
        self.get_lock()

    def __exit__(self, type, value, traceback):
        self.release_lock()


class ServiceNowAPI(object):
    def __init__(self):
        self.sn_user = sn_user
        self.sn_pwd = sn_pwd
        self.sn_url = sn_url
        self.headers = {"Accept": "application/json", "Content-Type": "application/json"}
        self.host_type = None

    def get_ip(self, ip_octets, host_type):
        logger.info("Get IP from ServiceNow")
        # ServiceNow query
        if host_type == "srv":
            third_octet = "0"
        if host_type == "vm":
            third_octet = ["2", "3"]

        query = "ip_addressSTARTSWITH{}.{}.^u_hostnameISEMPTY^u_active=false^ORDERBYip_address".format(ip_octets,
                                                                                                      third_octet)
        url = "{}/now/table/u_cmdb_ci_debesys_ip?sysparm_limit=1024&sysparm_query={}&sysparm_display_value=true".format(
            self.sn_url,
            query)

        for octet in third_octet:
            query = "ip_addressSTARTSWITH{}.{}.^u_hostnameISEMPTY^u_active=false^ORDERBYip_address".format(ip_octets,
                                                                                                          octet)
            url = "{}/now/table/u_cmdb_ci_debesys_ip?sysparm_limit=1024&sysparm_query={}&sysparm_display_value=true".format(
                self.sn_url,
                query)

            mgmt_ip = self.request_ip_from_sn(url)
            if mgmt_ip != None:
                break

        return mgmt_ip

    def request_ip_from_sn(self, url):
        # USE requests to look for ip_address
        try:
            response = requests.get(url, auth=(self.sn_user, self.sn_pwd), headers=self.headers, timeout=10).json()
            return response['result'][0]['ip_address']
        except IndexError as e:
            logger.error("NO IPS FOUND")
    
    def update_sn_ip_status(self, ip, hostname, active):
        # Reserving the VLAN IP address in Service Now
        logger.info("UPDATE {} and {} with active = {}".format(ip, hostname, active))
        try:
            query = "ip_address={}".format(ip)
            url = "{}/now/table/u_cmdb_ci_debesys_ip?sysparm_limit=1&sysparm_query={}&sysparm_display_value=true".format(
                self.sn_url,
                query)

            response = requests.get(url, auth=(self.sn_user, self.sn_pwd), headers=self.headers, timeout=10).json()
            sys_id = response['result'][0]['sys_id']

            url = '{}/now/table/u_cmdb_ci_debesys_ip/{}'.format(self.sn_url, sys_id)

            if active == True:
                payload = {"u_active": "true", "u_hostname": hostname}
            if active == False:
                payload = {"u_active": "false", "u_hostname": ""}

            response = requests.put(url, auth=(self.sn_user, self.sn_pwd), headers=self.headers, timeout=10,
                                    data=json.dumps(payload))
        except Exception as ex:
            logger.error(
                "Failed to reserve IP {} for {} in ServiceNow. PLEASE CONTACT SYSTEMS ENGINEERING!\n\nException: {}".format(
                    ip, hostname, ex))
