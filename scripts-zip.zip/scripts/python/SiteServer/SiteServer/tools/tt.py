
import logging
import re
from ttsyseng.selfservice.helpers.conf_data import DCS

class TTInfo(object):
    def __init__(self):
        self.dcs = DCS
        self.log = logging.getLogger(__name__)

    def get_dc(self, dc_name):

        self.log.info("Trying to locate DC: %s", dc_name)
        if re.search('^(gl).*', dc_name):
            for key, val in self.dcs['Glados'].items():
                if re.search(key, dc_name):
                    ret = {
                        'dc_name': dc_name,
                        'dc_env': 'Glados',
                        'vlan_base': val['vlan_base']
                    }
                    self.log.info("Found the following DC: %s", ret)
        elif re.search('^(?:m|m-).*$', dc_name):
            for key, val in self.dcs['Mock'].items():
                if re.search(key, dc_name):
                    ret = {
                        'dc_name': dc_name,
                        'dc_env': 'Mock',
                        'vlan_base': val['vlan_base']
                    }
                    self.log.info("Found the following DC: %s", ret)
        elif re.search('^(?:sqe).*$', dc_name):
            for key, val in self.dcs['SQE'].items():
                if re.search(key, dc_name):
                    ret = {
                        'dc_name': dc_name,
                        'dc_env': 'SQE',
                        'vlan_base': val['vlan_base']
                    }
                    self.log.info("Found the following DC: %s", ret)
        elif re.search('^(i).*$', dc_name):
            for key, val in self.dcs['TTI'].items():
                if re.search(key, dc_name):
                    ret = {
                        'dc_name': dc_name,
                        'dc_env': 'TTI',
                        'vlan_base': val['vlan_base']
                    }
                    self.log.info("Found the following DC: %s", ret)
        elif re.search('^([a-z]{2,3})$', dc_name):
            for key, val in self.dcs['Prod'].items():
                if re.search(key, dc_name):
                    ret = {
                        'dc_name': dc_name,
                        'dc_env': 'Prod',
                        'vlan_base': val['vlan_base']
                    }
                    self.log.info("Found the following DC: %s", ret)
        else:
            ret = {
                'dc_name': None,
                'dc_env': None,
                'vlan_base': 4 
            }
            self.log.info("Failed to locate DC, Returning defaults.... %s", ret)
        return ret
