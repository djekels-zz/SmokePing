#!/bin/env python
"""args.py

Provides a platform to get and proces argv into variables that can be used elsewhere in the app.
"""
import argparse
import os
import sys
import re
import pysnow
import logging
import socket
from pprint import pprint
from SiteServer.tools.tt import TTInfo
from SiteServer.tools.hpe import HPE

if sys.stdin.isatty():
    CHECK = u"\033[32m[\033[0;34m\u2714\033[32m]\033[0m -"
    EXX = u"\033[91m[\033[0;31m\u2718\033[91m]\033[0m -"
    WARN = u"\033[94m[\033[95m\u00A1\033[94m]\033[0m -"
else:
    CHECK = ""
    EXX = ""
    WARN = ""

def check_hostname(arg_value,
                  pat=re.compile(r'((?:m\-|m)[a-zA-Z]{2,3}|(?:sqe\-|sqe)[a-zA-Z]{2,3}|[a-zA-Z]{2,3})([0-9]{1,3})([a-zA-Z]{2,5})([0-9]{1,3})')
                  ):
    """check_hostname

    validate that hostname provided by user fits our pattern...

    Arguments:
        arg_value {string} -- hostname to check
    Returns:
        [string] -- valid hostname string
    """
    if not pat.match(arg_value):
        raise argparse.ArgumentTypeError("Hostname Does not Match our regex pattern...")
    return arg_value

def check_ip_addr(arg_value,
                  pat=re.compile(r'^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$')):
    """check_ip_addr

    validate that ip_addr provided by user fits our pattern...

    Arguments:
        arg_value {string} -- ip_addr to check
    Returns:
        [string] -- valid ip_addr string
    """
    if not pat.match(arg_value):
        raise argparse.ArgumentTypeError("ip_addr Does not Match our regex pattern...")
    return arg_value

def check_mac(arg_value,
                  pat=re.compile(r'^([0-9a-fA-F][0-9a-fA-F]:){5}([0-9a-fA-F][0-9a-fA-F])$')):
    """check_mac

    validate that mac provided by user fits our pattern...

    Arguments:
        arg_value {string} -- mac to check
    Returns:
        [string] -- valid mac string
    """
    if not pat.match(arg_value):
        raise argparse.ArgumentTypeError("mac Does not Match our regex pattern...")
    return arg_value



def args_parser():
    """
    Function: args_parser
    Summary: Parse argv and return the values.
    Returns: options dictionary for use elsewhere in app.
    """
    parser = argparse.ArgumentParser(description="SiteServer CLI")
    parser.add_argument("-v", "--version", help="Display SiteServer Package Version",
                        action="store_true", default=False)
    parser.add_argument("-c", "--cron", help="Running as cron, do no print ascii art or colors",
                        action="store_true", default=False)
    parser.add_argument("-a", "--add", help="Add new Host", action="store_true", default=False)
    parser.add_argument("-d", "--delete", help="Delete new Host", action="store_true",
                        default=False)
    parser.add_argument("-l", "--lookup", help="lookup Host", action="store_true", default=False)
    parser.add_argument("-n", "--name", type=check_hostname,
                        help="Host Name. Used with: Add, Del, Lookup options")

    parser.add_argument("-i", "--ip", type=check_ip_addr,
                        help="IP Address. Used with: Add, Del, Lookup options", \
                        default="0.0.0.0")

    parser.add_argument("-m", "--mac", help="MAC Address. (ie: 01:23:45:67:89:ab) Used with:" \
                        " Add, Del, Lookup options", default="01:23:45:67:89:ab", type=check_mac)
    parser.add_argument("-m2", "--mac2", help="2nd Interface MAC Address (ie: 01:23:45:67:89:ab)", \
                        default=False)
    parser.add_argument("-m3", "--mac3", help="3rd Interface MAC Address (ie: 01:23:45:67:89:ab)", \
                        default=False)
    parser.add_argument("-m4", "--mac4", help="4th Interface MAC Address (ie: 01:23:45:67:89:ab)", \
                        default=False)
    parser.add_argument("-m5", "--mac5", help="5th Interface MAC Address (ie: 01:23:45:67:89:ab)", \
                        default=False)
    parser.add_argument("-m6", "--mac6", help="6th Interface MAC Address (ie: 01:23:45:67:89:ab)", \
                        default=False)
    parser.add_argument("-o", "--os_ver", help="Operating System Version (6.9|6.10|" \
                        "7.4.1708|7.6.1810|7.8.2003|7.9.2009|8.0.1905|8.1.1911|8.2.2004) Default: 7.6.1810", default="7.6.1810",
                        choices=('6.9', '6.10', '7.4.1708', '7.6.1810', '7.7.1908', '7.8.2003', '7.9.2009', '8.0.1905', '8.1.1911', '8.2.2004'))
    parser.add_argument("-b", "--bootloader", help="Bootloader (mbr|efi) Default: mbr" \
                        , default="mbr", choices=('mbr', 'MBR', 'efi', 'EFI'))
    parser.add_argument("-ht", "--hst_type", help="Install Type (OC|GP|VM|ESXI) Default: GP" \
                        , default="GP", choices=('gp', 'GP', 'vm', 'VM', 'oc', 'OC', 'esxi', \
                        'ESXI', 'cap', 'CAP'))
    parser.add_argument("-hg", "--hst_gen", help="HPE Gen Type (Gen7|Gen8|Gen9|Gen10)", default="",
                        choices=('gen7', 'Gen7', 'gen8', 'Gen8', 'gen9', 'Gen9', 'gen10', 'Gen10' \
                        , 'gen11', 'Gen11'))
    parser.add_argument("-p", "--password", help="Root Password (Default: Tt12345678)" \
                        , default="Tt12345678")
    parser.add_argument("-of", "--only_files", help="Only Output Files, Do NOT register " \
                        "with dhcpd.", action="store_true", default=False)
    parser.add_argument("-swr", "--software_raid", help="Use Software Raid",
                        action="store_true", default=False)
    parser.add_argument("-nsn", "--not_snow", help="DO NOT lookup SNOW",
                        action="store_true", default=False)
    parser.add_argument("-up", "--update", help="This flag will run the SPP ISO to auto " \
                        "update the os.", action="store_true", default=False)
    parser.add_argument("-spp", "--spp_url", help="SPP URL for use with the hp ilo")
    parser.add_argument("-vb", "--vlan_base", help="Vlan Prefix (Default: 4)", default=4)
    parser.add_argument("-fit", "--from_it", help=argparse.SUPPRESS,
                        action="store_true", default=False)
    parser.add_argument("-iu", "--it_user", help=argparse.SUPPRESS)

    return parser

def sna_lookup_gen(options):
    lgr = logging.getLogger(__name__)
    sna = pysnow.Client(instance='tradingtech', user='svc-elsrw', password='P8pcqQdf')
    sna.parameters.display_value = True

    try:
        sn_host = sna.resource(api_path='/table/cmdb_ci_server')
        sn_host_resp = sn_host.get(query={'name': options.name}).one_or_none()
        return sn_host_resp
    except Exception as err:
        lgr.info("Failed to locate host (%s) in service now \n %s", options.name, err)

def classify_host_gen(sn_host, options):
    lgr = logging.getLogger(__name__)
    ret = lambda: None

    if re.match(r'(g|gen)([ ]{0,1})(6)', sn_host['model_id']['display_value'], re.IGNORECASE) \
       or re.match(r'(g|gen)([ ]{0,1})(6)', options.hst_gen, re.IGNORECASE):
        lgr.info("Identified host as Gen 6")
        ret.drv_dsk = HPE['Gen6']['centos'][options.os_ver]['driver_disk']
        ret.hst_gen = "Gen 6"
    elif re.match(r'(g|gen)([ ]{0,1})(7)', sn_host['model_id']['display_value'], re.IGNORECASE) \
       or re.match(r'(g|gen)([ ]{0,1})(7)', options.hst_gen, re.IGNORECASE):
        lgr.info("Identified host as Gen 7")
        ret.drv_dsk = HPE['Gen7']['centos'][options.os_ver]['driver_disk']
        ret.hst_gen = "Gen 7"
    elif re.match(r'(g|gen)([ ]{0,1})(8)', sn_host['model_id']['display_value'], re.IGNORECASE) \
       or re.match(r'(g|gen)([ ]{0,1})(8)', options.hst_gen, re.IGNORECASE):
        lgr.info("Identified host as Gen 8")
        ret.drv_dsk = HPE['Gen8']['centos'][options.os_ver]['driver_disk']
        ret.hst_gen = "Gen 8"
    elif re.match(r'(g|gen)([ ]{0,1})(9)', sn_host['model_id']['display_value'], re.IGNORECASE) \
       or re.match(r'(g|gen)([ ]{0,1})(9)', options.hst_gen, re.IGNORECASE):
        lgr.info("Identified host as Gen 9")
        ret.drv_dsk = HPE['Gen9']['centos'][options.os_ver]['driver_disk']
        ret.hst_gen = "Gen 9"
    elif re.match(r'(g|gen)([ ]{0,1})(10)', sn_host['model_id']['display_value'], re.IGNORECASE) \
       or re.match(r'(g|gen)([ ]{0,1})(10)', options.hst_gen, re.IGNORECASE):
        lgr.info("Identified host as Gen 10")
        ret.drv_dsk = HPE['Gen10']['centos'][options.os_ver]['driver_disk']
        ret.hst_gen = "Gen 10"
    elif re.match(r'(g|gen)([ ]{0,1})(11)', sn_host['model_id']['display_value'], re.IGNORECASE) \
       or re.match(r'(g|gen)([ ]{0,1})(11)', options.hst_gen, re.IGNORECASE):
        lgr.info("Identified host as Gen 11")
        ret.drv_dsk = HPE['Gen11']['centos'][options.os_ver]['driver_disk']
        ret.hst_gen = "Gen 11"
    else:
        ret.drv_dsk = ''
        ret.hst_gen = ''

    return ret

def add_args_parser(options):
    """
    Function: add_args_parser
    Summary: Takes options dictionary and validates required fields are there.
             If so parses data and adds some required fields based on input.
    Attributes:
        @param (options): options dictionary from args_parser
    Returns: options dictionary for use elsewhere in app.
    """
    lgr = logging.getLogger(__name__)
    hostname = socket.gethostname()
    ssip = socket.gethostbyname(hostname)
    tt = TTInfo()
    options.action = "add"
    if not options.name:
        print("Please provide a hostname (-n|--name)")
        sys.exit()

    if not options.ip:
        print( "Please provide a ip (-i|--ip)...")
        sys.exit()

    if not options.mac:
        print("Please provide a mac (-m|--mac)...")
        sys.exit()

    if options.os_ver not in ['6.9', '6.10', '7.4.1708', '7.6.1810', '7.7.1908', '7.8.2003', '7.9.2009', '8.0.1905', '8.1.1911', '8.2.2004']:
        print("The OS version provided is not yet supported. Please " \
              "contact Systems Engineering for more details.")
        sys.exit()

    if ('srv' in options.name or 'ss' in options.name or 'vmh' in options.name) and \
       (options.hst_type != "VM") and (options.not_snow != True):

        try:
            sn_host = sna_lookup_gen(options)
            in_opts = classify_host_gen(sn_host, options)
            options.drv_dsk = in_opts.drv_dsk
            options.hst_gen = in_opts.hst_gen
        except:
            print("%s DANGER WILL ROBINSON, DANGER, Could not identify host Gen... " \
                  "Please set via CLI or ensure the host is properly added in service" \
                  " now..." % WARN)
            sys.exit()
    else:
        options.drv_dsk = ""

    host_split = re.search(r'((?:m\-|m)[a-zA-Z]{2,3}|[a-zA-Z]{2,3})([0-9]{1,3})'
                           '([a-zA-Z]{2,5})([0-9]{2,3})', options.name)
    options.vlan_base = tt.get_dc(dc_name=host_split[1])['vlan_base']

    return options

def get_args():
    """
    Function: get_args
    Summary: Takes argv[] and converts to opt variable.
    Returns: options dictionary for use elsewhere in app.
    """

    options = args_parser().parse_args()

    if options.add:
        options = add_args_parser(options)
    elif options.delete:
        options.action = "delete"
    elif options.lookup:
        options.action = "lookup"
    elif options.version:
        options.action = "version"
    else:
        print("Please provide at least one opperator option. -a or -d or -l")

    return options
