"""@package docstring
files.py

This class is used to interact with the different
files for the pxe process.
"""
import crypt
import coloredlogs
import logging
import os
import sys
import re
from jinja2 import Environment, PackageLoader
import pypureomapi
import tzlocal
from SiteServer.tools.hpe import TTHpe
from SiteServer.tools.tt import TTInfo



KEYNAME = b"omapi_key"
KEY = b"s9hWnukYk+16gdCW1YoDsKvONmW60x4GM6JEX5fkYJL0jvjCKYkHbolkjwFlwZI1zpeOBDRgWKQsQ+a2xn8Qvg=="
DHCPD_IP = "127.0.0.1"
DHCPD_PORT = 7911

OMAPI = pypureomapi.Omapi(DHCPD_IP, DHCPD_PORT, KEYNAME, KEY)
ENV = Environment(loader=PackageLoader('SiteServer', 'templates'))
SSIP = os.popen("/bin/hostname -I").read().split(" ")[0]

if sys.stdin.isatty():
    CHECK = u"\033[32m[\033[0;34m\u2714\033[32m]\033[0m -"
    EXX = u"\033[91m[\033[0;31m\u2718\033[91m]\033[0m -"
    WARN = u"\033[94m[\033[95m\u00A1\033[94m]\033[0m -"
else:
    CHECK = ""
    EXX = ""
    WARN = ""


class Files(object):
    """Files

    Create the files required for pxe booting.
    """

    def __init__(self):
        self.hpe = TTHpe()

    def create_pointer(self, args):
        """create_pointer

        create the tftp pointer file and job to remove it.

        Arguments:
            host {[type]} -- [description]
            mac {[type]} -- [description]
            os_ver {[type]} -- [description]
            hst_gen {[type]} -- [description]
        """
        logger = logging.getLogger(__name__)
        args['fileType'] = "pointer"
        args['hdwaddr'] = "01-%s" % args['mac'].replace(':', '-')
        
        if args['hostname'].lower().startswith('m-in'):
           SSIP="10.207.129.30"
        elif args['hostname'].lower().startswith('iar'):
           SSIP="10.102.129.30"
        elif args['hostname'].lower().startswith('ich'):
           SSIP="10.111.129.30"
        elif args['hostname'].lower().startswith('ifr'):
           SSIP="10.127.129.30"
        elif args['hostname'].lower().startswith('iln'):
           SSIP="10.126.129.30"
        elif args['hostname'].lower().startswith('iny'):
           SSIP="10.113.129.30"
        else:
           SSIP = os.popen("/bin/hostname -I").read().split(" ")[0]

        if args['bootloader'] == "mbr":
            args['filepath'] = "/opt/debesys/SysEng/tftpboot/pxelinux.cfg/%s" \
                               % args['hdwaddr'].lower()
            template = ENV.get_template('pointer/mbr.txt')
        else:
            args['filepath'] = "/opt/debesys/SysEng/tftpboot/EFI/BOOT/%s" % args['hdwaddr'].upper()
            template = ENV.get_template('pointer/efi.txt')
        fwrite = open(args['filepath'], "w")
        if args['hst_type'] != "vm" and args['hst_type'] != "VM":
            try:
                if args['os_ver'] == "6.9" or args['os_ver'] == "6.10":
                    args['blklst'] = "blacklist=%s" % self.hpe.black_list(args['hst_gen'])
                else:
                    args['blklst'] = "modprobe.blacklist=%s" % self.hpe.black_list(args['hst_gen'])

                args['drv_dsk'] = self.hpe.driver_disk(args['hst_gen'], 'centos', args['os_ver'])
            except Exception as err:
                logger.info("Failed to classify host: %s", err)
                args['blklst'] = ""
                args['drv_dsk'] = ""
        else:
            args['blklst'] = ""
            args['drv_dsk'] = ""

        data = template.render(host=args['hostname'], os_ver=args['os_ver'], \
                               ssip=SSIP, file=args['hdwaddr'].lower(), blklst=args['blklst'], \
                               mac=args['mac'], bootloader=args['bootloader'], \
                               drv_dsk=args['drv_dsk'])
        fwrite.write(data)
        fwrite.close()
        logger.info("Created pointer file: %s", args['filepath'])

    @staticmethod
    def create_ksf(args):
        """[summary]

        [description]

        Arguments:
            args {[dict]} -- dict of variables used for creating vm.
        """
        logger = logging.getLogger(__name__)
        args['fileType'] = "ks"
        args['os_ver_short'] = args['os_ver'][0:1]
        args['hdwaddr'] = "01-%s" % args['mac'].replace(':', '-')
        args['filepath'] = "/opt/debesys/SysEng/www/ks/%s" % args['hdwaddr'].lower()
        split = re.search(r'((?:m\-|m)[a-zA-Z]{2,3}|(?:sqe\-|sqe)[a-zA-Z]{2,3}|[a-zA-Z]{2,3})([0-9]{1,3})([a-zA-Z]{2,5})([0-9]{1,3})', args['hostname'])
        args['type'] = split.group(3)
        args['dc_short'] = split.group(1)

        if args['hostname'].lower().startswith('m-in'):
           SSIP="10.207.129.30"
        elif args['hostname'].lower().startswith('iar'):
           SSIP="10.102.129.30"
        elif args['hostname'].lower().startswith('ich'):
           SSIP="10.111.129.30"
        elif args['hostname'].lower().startswith('ifr'):
           SSIP="10.127.129.30"
        elif args['hostname'].lower().startswith('iln'):
           SSIP="10.126.129.30"
        elif args['hostname'].lower().startswith('iny'):
           SSIP="10.113.129.30"
        else:
           SSIP = os.popen("/bin/hostname -I").read().split(" ")[0]

        fwrite = open(args['filepath'], "w")
        if "ESXI" in args['hst_type']:
            template = ENV.get_template('vmh/kickstart.txt')
        elif "CAP" in args['hst_type']:
            template = ENV.get_template('cap/kickstart.txt')
        elif args['hst_type'].lower().startswith('oc'):
            template = ENV.get_template('oc/kickstart.txt')
        else:
            template = ENV.get_template('linux/kickstart.txt')

        args['timezone'] = tzlocal.get_localzone().zone
        args['root_pw'] = crypt.crypt(args['root_pw'], crypt.mksalt(crypt.METHOD_SHA512))
        if "OC" in args['hst_type']:
            args['disk'] = "md126"
        elif "CAP" in args['hst_type']:
            args['disk'] = "nvme0n1"
        else:
            args['disk'] = "sda"

        if "efi" in args['bootloader']:
            args['bl_loc'] = "partition"
        else:
            args['bl_loc'] = "mbr"

        args['split_ip'] = args['ip_addr'].split('.')
        args['split_ip'][2] = int(args['split_ip'][2])
        args['gw_oct'] = 1

        if args['hst_gen'].lower().startswith('gen') and args['hst_type'].lower() != "vm":
            args['grub_opts'] = "intel_idle.max_cstate=0 " \
                                "processor.max_cstate=0 " \
                                "nosoftlockup mce=ignore_ce"
        elif args['hst_type'].lower().startswith('oc'):
            args['grub_opts'] = "intel_idle.max_cstate=0 processor.max_cstate=0 nosoftlockup " \
            "mce=ignore_ce idle=poll pcie_aspm=off"
        else:
            args['grub_opts'] = ""

        data = template.render(host=args['hostname'], mac=args['mac'], mac2=args['mac2'],
                               mac3=args['mac3'], mac4=args['mac4'], mac5=args['mac5'],
                               mac6=args['mac6'], ip_addr=args['ip_addr'],
                               split_ip=args['split_ip'], vlan_base=args['vlan_base'],
                               os_ver=args['os_ver'], disk=args['disk'],
                               timezone=args['timezone'], root_pw=args['root_pw'], ssip=SSIP,
                               os_ver_short=args['os_ver_short'], bl_loc=args['bl_loc'],
                               gw_oct=args['gw_oct'], grub_opts=args['grub_opts'],
                               hst_type=args['hst_type'], drv_dsk=args['drv_dsk'],
                               software_raid=args['software_raid'], dc_short=args['dc_short'],
                               from_it=args['from_it'], it_usr=args['it_user'])
        fwrite.write(data)
        fwrite.close()
        logger.info("Created KS File for host: %s at %s", args['hostname'], args['filepath'])

    @staticmethod
    def cleanup(mac):
        """
        Function: cleanup
        Summary: clean up files used to kickstart a host.
        This includes the pointer file and kickstart file.
        Examples: cleanup("14:02:ec:71:76:e0")
        Attributes:
          @param (mac): String of the hosts primary mac address used for pxe booting.
        Returns: Nothing
        """
        filename = "01-%s" % mac.replace(':', '-').lower()
        if os.path.exists("/opt/debesys/SysEng/tftpboot/pxelinux.cfg/%s" % filename):
            print("%s Cleanup: /opt/debesys/SysEng/tftpboot/pxelinux.cfg/%s" % (WARN, filename))
            os.remove("/opt/debesys/SysEng/tftpboot/pxelinux.cfg/%s" % filename)

        if os.path.exists("/opt/debesys/SysEng/tftpboot/EFI/BOOT/%s" % filename.upper()):
            print("%s Cleanup: /opt/debesys/SysEng/tftpboot/EFI/BOOT/%s" % (WARN, filename.upper()))
            os.remove("/opt/debesys/SysEng/tftpboot/EFI/BOOT/%s" % filename.upper())

        if os.path.exists("/opt/debesys/SysEng/www/ks/%s" % filename):
            print("%s Cleanup: /opt/debesys/SysEng/www/ks/%s" % (WARN, filename))
            os.remove("/opt/debesys/SysEng/www/ks/%s" % filename)
