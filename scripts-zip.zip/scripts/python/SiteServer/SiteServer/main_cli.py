# -*- coding: UTF-8 -*-
"""@package docstring
SSCLI

SiteServer CLI App. This is to interact with the SiteServer at the CLI Level
"""
import os
import coloredlogs
import logging
import datetime
import sys
import re
from pprint import pprint
import pysnow
import pypureomapi
from SiteServer.tools.files import Files
from SiteServer.tools.stats import Stats
from SiteServer.tools.argv import get_args

KEYNAME = b"omapi_key"
KEY = b"s9hWnukYk+16gdCW1YoDsKvONmW60x4GM6JEX5fkYJL0jvjCKYkHbolkjwFlwZI1zpeOBDRgWKQsQ+a2xn8Qvg=="
DHCPD_IP = "127.0.0.1"
DHCPD_PORT = 7911

OMAPI = pypureomapi.Omapi(DHCPD_IP, DHCPD_PORT, KEYNAME, KEY)
SSIP = os.popen("/bin/hostname -I").read().split(" ")[0]

SNA = pysnow.Client(instance='tradingtech', user='svc-elsrw', password='P8pcqQdf')
SNA.parameters.display_value = True
STATS = Stats()

def init_log():
    """init_log

    Setup the logger functions for later use...

    Returns:
        logger (object) -- Logger object for use elsewhere...
    """
    if sys.stdin.isatty():
        coloredlogs.install()

    logpath = '/var/log/debesys/processor.log'
    logdir = os.path.dirname(logpath)
    try:
        if not os.path.isdir(logdir):
            os.mkdir(logdir)
    except OSError as err:
        print("Failed to create %s (%s)" % logdir, err)

    logger = logging.getLogger(__name__)

    return logger

def startup():
    """
    Function: startup
    Summary: Display ASCII Art
    Examples: startup()
    Returns: ASCII Art Strings
    """

    now = datetime.datetime.now()

    print("""
\t\t                      \033[96m.,,,\033[0m
\t\t                    \033[96m.,,,,,,,\033[0m
\t\t                  \033[96m,,,,,,,\033[0m   \033[01;34m ((\033[0m
\t\t                 \033[96m,,,,,,,\033[0m   \033[01;34m(((((\033[0m
\t\t               \033[96m,,,,,,,\033[0m   \033[01;34m/((((((((\033[0m
\t\t             \033[96m,,,,,,,\033[0m   \033[01;34m/((((((((((((\033[0m
\t\t           \033[96m,,,,,,,\033[0m   \033[01;34m*((((((((((((((((\033[0m
\t\t         \033[96m,,,,,,,\033[0m    \033[01;34m((((((((((((((((((((\033[0m
\t\t       \033[96m,,,,,,,\033[0m   \033[00;34m,(   \033[01;34m((((((((((((((((((((\033[0m
\t\t     \033[96m,,,,,,,\033[0m   \033[00;34m.(((((   \033[01;34m((((((((((((((((((((\033[0m
\t\t   \033[96m,,,,,,,\033[0m   \033[00;34m.((((((((\\   \033[01;34m((((((((((((((((((((\033[0m
\t\t     \033[96m,,,\033[0m    \033[00;34m(((((((((((((\\   \033[01;34m((((((((((((((((\033[0m
\t\t          \033[00;34m((((((((  (((((((*   \033[01;34m((((((((((((\033[0m
\t\t         \033[00;34m((((((      (((((((*   \033[01;34m((((((((\033[0m
\t\t          \033[00;34m(((   \033[00;30m/%%%   \033[00;34m(((((((,   \033[01;34m((((\033[0m
\t\t              \033[00;30m*%%%%%%%   \033[00;34m((((((((.\033[0m
\t\t              \033[00;30m.%%%%%%%%%   \033[00;34m((((((((\033[0m
\t\t               \033[00;30m,%%%%%%%%%   \033[00;34m(((((\033[0m
\t\t                \033[00;30m,%%%%%%%%%\033[0m
\t\t                 \033[00;30m`*%%%%%%%\033[0m
\t\t                    \033[00;30m/%%%%                       \033[0m""")
    print("\n\t\t\t    \033[01;34mTrading Technologies, Inc.\033[0m\n\n")
    print("Welcome to \033[1;34mSite Server CLI\t\t\t  \033[1;32m%s\033[0m" \
          % now.isoformat())
    print("\033[1;32m-------------------------------------------------------------------" \
          "-----------------\033[0m")


def register_host(opt):
    """
    Function: register_host
    Summary: Used to run logic around the kickstart file.
    Examples: register_host(opts)
    Attributes:
        @param (opt): Variable passed from argv module that pasres app args.
    Returns: Null
    """

    logger = logging.getLogger(__name__)
    args = {
        "hostname": opt.name,
        "ip_addr": opt.ip,
        "mac": opt.mac,
        "mac2": opt.mac2,
        "mac3": opt.mac3,
        "mac4": opt.mac4,
        "mac5": opt.mac5,
        "mac6": opt.mac6,
        "os_ver": opt.os_ver,
        "bootloader": opt.bootloader,
        "drv_dsk": opt.drv_dsk,
        "hst_type": opt.hst_type,
        "hst_gen": opt.hst_gen,
        "root_pw": opt.password,
        "vlan_base": opt.vlan_base,
        "software_raid": opt.software_raid,
        "via": "CLI",
        "from_it": opt.from_it,
        "it_user": opt.it_user
    }
    fls = Files()

    if args['mac'] and not args['mac2']:
        logger.info("MAC2 was not provided, grabbing mac2 based on mac (%s)...", args['mac'])
        mac = re.sub(r"(\:|\.|\-|\ )", '', args['mac'])
        mac_int = int(mac, 16) + 1
        mac_hex = "{:012x}".format(mac_int)
        args['mac2'] = ":".join(mac_hex[i:i+2] for i in range(0, len(mac_hex), 2))
        logger.info("Assembled mac2: %s", args['mac2'])

    try:
        logger.info("Attempting to create pointer file...")
        fls.create_pointer(args)
        logger.info("Attempting to create kickstart file...")
        Files.create_ksf(args)

        if opt.only_files:
            logger.info("-of flag passed... Writing files without trying to register host " \
                        "with the dhcpd service...")
        else:
            logger.info("Registering host with DHCP server")
            OMAPI.add_host_supersede_name(ip=args['ip_addr'], mac=args['mac'],
                                          name=args['hostname'])
            OMAPI.lookup_host(args['hostname'])

        if (args['hst_type'] != "OC") and ("srv" in args['hostname'] or "ss" in args['hostname']):
            logger.info("Created Host:")
            logger.info("\t\tHostname: \033[01;34m%s\033[0m", args['hostname'])
            logger.info("\t\tIP: \033[01;34m%s\033[0m", args['ip_addr'])
            logger.info("\t\tMAC: \033[01;34m%s\033[0m", args['mac'])
            logger.info("\t\tOS: \033[01;34m%s\033[0m", args['os_ver'])
            logger.info("\t\tHW Gen: \033[01;34m%s\033[0m", args['hst_gen'])
        else:
            logger.info("Created Host:")
            logger.info("\t\tHostname: \033[01;34m%s\033[0m", args['hostname'])
            logger.info("\t\tIP: \033[01;34m%s\033[0m", args['ip_addr'])
            logger.info("\t\tMAC: \033[01;34m%s\033[0m", args['mac'])
        STATS.addLease(args)
    except Exception as err:
        logger.error("Failed to register host (%s)... %s", opt.name, err)

def delete_host(opt):
    """
    Function: delete_host
    Summary: Delete Host Registration from system...
    Examples: delete_host(opts)
    Attributes:
        @param (opt): Variable passed from argv module that pasres app args.
    Returns: Null
    """
    logger = logging.getLogger(__name__)
    try:
        if not opt.only_files:
            host = OMAPI.lookup_host(opt.name)
            logger.info("Removing Host (%s) registration from DHCP server...", opt.name)
            OMAPI.del_host(host['mac'])

        Files.cleanup(host['mac'])
        logger.info("Deleted host:\n\tHostname: \033[01;34m%s\033[0m\n\tIP: \033[01;34m%s"
                    "\033[0m\n\tMAC: \033[01;34m%s\033[0m\n", host['hostname'],
                    host['ip'], host['mac'])
    except Exception as err:
        logger.error("Failed to register host (%s)... %s", opt.name, err)

def lookup_host(opt):
    """
    Function: delete_host
    Summary: Delete Host Registration from system...
    Examples: delete_host(opts)
    Attributes:
        @param (opt): Variable passed from argv module that pasres app args.
    Returns: Null
    """
    logger = logging.getLogger(__name__)
    if opt.name:
        try:
            host = OMAPI.lookup_host(opt.name)
            if host:
                logger.info("Found Host:\n\tHostname: \033[01;34m%s\033[0m\n\tIP: \033[01;34m"
                            "%s\033[0m\n\tMAC: \033[01;34m%s\033[0m\n",
                            host['hostname'], host['ip'], host['mac'])
        except Exception as err:
            logger.error("Could not find registration for host: %s\n%s", opt.name, err)
    elif opt.mac:
        try:
            host = OMAPI.lookup_mac(mac=opt.mac.lower())
            if host:
                print("%s Found Host:\n\tHostname: \033[01;34m%s\033[0m\n\tIP: " \
                      "\033[01;34m%s\033[0m \n\tMAC: \033[01;34m%s\033[0m\n" % \
                      (CHECK, host['hostname'], host['ip'], host['hardware-address']))
        except Exception as err:
            logger.error("Could not find registration for MAC Address: %s\n%s", opt.name, err)
    elif opt.ip_addr:
        try:
            host = OMAPI.lookup_by_host(ip=opt.ip_addr)
            if host:
                print("%s Found Host:\n\tHostname: \033[01;34m%s\033[0m\n\tIP: \033[01;34m%s\033[0m"
                      "\n\tMAC: \033[01;34m%s\033[0m\n" %
                      (CHECK, host['hostname'], host['ip'], host['mac']))
        except Exception as err:
            logger.error("Could not find registration for IP Address: %s\n%s", opt.name, err)

def main():
    startup()

    logger = init_log()
    opt = get_args()
    logger.info("Attempting to %s host: %s", opt.action, opt.name)

    if "add" in opt.action:
        register_host(opt)
    elif "delete" in opt.action:
        delete_host(opt)
    elif "lookup" in opt.action:
        lookup_host(opt)
if __name__ == '__main__':
    main()
