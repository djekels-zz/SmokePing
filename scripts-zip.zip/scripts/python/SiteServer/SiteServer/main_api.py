"""@package docstring

This is the primary script for the ssapi. This will turn
up the flasgger runner that handles the API.
"""
import os
import logging
import re
import sys
import pkg_resources
import netifaces
import subprocess
import time
from pprint import pprint
from flask import Flask, jsonify, request
from flasgger import Swagger
import pypureomapi
from logging.config import dictConfig
from SiteServer.tools.files import Files
from SiteServer.tools.tt import TTInfo
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

KEYNAME = b"omapi_key"
KEY = b"s9hWnukYk+16gdCW1YoDsKvONmW60x4GM6JEX5fkYJL0jvjCKYkHbolkjwFlwZI1zpeOBDRgWKQsQ+a2xn8Qvg=="
DHCPD_IP = "127.0.0.1"
DHCPD_PORT = 7911

SSIP = os.popen("/bin/hostname -I").read().split(" ")[0]

def tail(f, n):
    proc = subprocess.Popen(['tail', '-n', n, f], stdout=subprocess.PIPE)
    lines = proc.stdout.readlines()
    return lines

os.environ['TZ'] = 'UTC'
time.tzset()

dictConfig({
    'version': 1,
    'formatters': {'default': {
        'format': '%(asctime)s %(levelname)s [%(module)s]: %(message)s',
    }},
    'handlers': {'wsgi': {
        'class': 'logging.StreamHandler',
        'formatter': 'default'
    }},
    'root': {
        'level': 'INFO',
        'handlers': ['wsgi']
    }
})

# Create an APISpec
app = Flask(__name__)

app.config['SWAGGER'] = {
    "title": "TT SiteServer API",
}

Swagger(app)

@app.route('/host/lookup/<string:hostname>', methods=['GET'])
def lookup(hostname):
    """
    lookup a host in the dhcpd leases. return the data.
    ---
    tags:
        - Hosts
    parameters:
    - in: path
      name: hostname
      type: string
      required: true

    responses:
        200:
            description: A single host entry from the dhcp server
        404:
            description: Host not found.
    """
    logger = logging.getLogger(__name__)
    logger.info("Looking up host: %s", hostname)
    if request.method == 'GET':
        try:
            omapi = pypureomapi.Omapi(DHCPD_IP, DHCPD_PORT, KEYNAME, KEY)
            data = omapi.lookup_host(hostname)
            json_data = jsonify(data)
            logger.info("Found host: %s", hostname)
            omapi.close()
            return json_data
        except:
            logger.info("Failed to locate host: %s", hostname)
            return "HOST not found", 404

@app.route("/host/add/<string:hostname>", methods=['POST'])
def add_host(hostname):
    """
    Create a new host on the DHCP server.
    ---
    tags:
        - Hosts
    parameters:
        - in: path
          name: hostname
          description: Host to create Entry for
          type: string
          required: true
        - in: query
          description: IP Address for the host
          name: ip
          type: string
          required: true
        - in: query
          name: mac
          description: MAC Hardware Address for the host
          type: string
          required: true
        - in: query
          name: mac2
          description: Second MAC Hardware Address for the host
          type: string
          required: true
        - in: query
          name: mac3
          description: Third MAC Hardware Address for the host
          type: string
          required: true
        - in: query
          name: mac4
          description: Fourth MAC Hardware Address for the host
          type: string
          required: true
        - in: query
          name: mac5
          description: Fifth MAC Hardware Address for the host
          type: string
          required: true
        - in: query
          name: os_ver
          description: Which OS to install (full OS version) (6.9 | 6.10 | 7.4.1708 | 7.6.1810 | 7.7.1908 | 7.8.2003 | 7.9.2009 | 8.0.1905 | 8.1.1911 | 8.2.2004)
          type: string
          enum: ['6.9', '6.10', '7.4.1708', '7.6.1810', '7.7.1908', '7.8.2003', '7.9.2009', '8.0.1905', '8.1.1911', '8.2.2004']
          required: true
        - in: query
          name: bootloader
          description: Bootloader (mbr|efi)
          default: mbr
          type: string
          enum: ['mbr', 'efi']
          required: true
        - in: query
          name: hst_type
          description: Host Type (OC | GP | CAP | SS | VM)
          type: string
          enum: ['GP', 'OC', 'CAP', 'SS', 'VM']
          required: true
          default: GP
        - in: query
          name: hst_gen
          description: Host Generation (Gen7 | Gen8 | Gen9 | Gen10)
          type: string
        - in: query
          name: root_pw
          description: Root Password to deploy with. (optional)
          type: string
          default: Tt12345678
        - in: query
          name: vlan_base
          description: Base VLAN for network trunks. ie. 400, 432, 448
          default: "4"
          type: string
        - in: query
          name: software_raid
          description: If we should enable software Raid or not.
          default: "False"
          type: boolean
        - in: query
          name: from_it
          description: Is this a request from IT. NO ONE OUTSIDE CORP IT SHOULD
                       EVER USE THIS FEATURE...
          default: "False"
          type: boolean
        - in: query
          name: it_user
          description: Is this a request from IT. NO ONE OUTSIDE CORP IT SHOULD
                       EVER USE THIS FEATURE...
          default: ""
          type: string
    responses:
        200:
            description: Results of creating a DHCP Host Reservation.
        500:
            destination: Failed to create host registration...
    """
    logger = logging.getLogger(__name__)
    logger.info("Attempting to create host: %s", hostname)
    omapi = pypureomapi.Omapi(DHCPD_IP, DHCPD_PORT, KEYNAME, KEY)
    format = request.args.get('format', 'json')
    args = {
        "hostname": hostname,
        "ip_addr": request.args.get('ip'),
        "mac": request.args.get('mac'),
        "mac2": request.args.get('mac2'),
        "mac3": request.args.get('mac3'),
        "mac4": request.args.get('mac4'),
        "mac5": request.args.get('mac5'),
        "mac6": request.args.get('mac6'),
        "os_ver": request.args.get('os_ver'),
        "bootloader": request.args.get('bootloader'),
        "hst_type": request.args.get('hst_type'),
        "hst_gen": request.args.get('hst_gen'),
        "root_pw": request.args.get('root_pw'),
        "vlan_base": request.args.get('vlan_base'),
        "software_raid": request.args.get('software_raid'),
        "from_it": request.args.get('from_it'),
        "it_user": request.args.get('it_user'),
    }

    tt = TTInfo()

    host_split = re.search(r'((?:m\-|m)[a-zA-Z]{2,3}|(?:sqe\-|sqe)[a-zA-Z]{2,3}|[a-zA-Z]{2,3})([0-9]{1,3})([a-zA-Z]{2,5})([0-9]{1,3})', hostname)
    args['vlan_base'] = tt.get_dc(dc_name=host_split[1])['vlan_base']

    if not args['software_raid']:
        args['software_raid'] = False

    try:
        fls = Files()
        fls.create_pointer(args=args)
        Files.create_ksf(args)
        omapi.add_host_supersede_name(ip=args['ip_addr'], mac=args['mac'], name=hostname)
        data = jsonify(omapi.lookup_host(hostname))
        omapi.close()

        logger.info("Created host: %s (%s)", hostname, args)

        return data
    except Exception as exp:
        logger.info("Falied to create host: %s (%s - %s)", hostname, args, exp)
        return "Failed to add host", 500

@app.route("/host/delete/<string:hostname>", methods=['DELETE'])
def delete_host(hostname):
    """
    Delete host from given hostname
    ---
    tags:
        - Hosts
    parameters:
        - in: path
          name: hostname
          description: Host to remove from system
          type: string
          required: true
    responses:
        200:
            description: Results of removing a DHCP Host Reservation.
        500:
            description: Failed to delete host.
    """
    logger = logging.getLogger(__name__)
    logger.info("Attempting to delete host: %s", hostname)
    try:
        omapi = pypureomapi.Omapi(DHCPD_IP, DHCPD_PORT, KEYNAME, KEY)
        host = omapi.lookup_host(hostname)
        omapi.del_host(host['mac'])
        Files.cleanup(host['mac'])
        omapi.close()
        logger.info("Successfuly Deleted host: %s", hostname)
        return "{} is deleted.".format(hostname), 200
    except Exception as err:
        logger.info("Failed to deleted host: %s (%s)", hostname, err)
        return "Failed to delete {}".format(hostname), 500

@app.route('/mac/<string:mac>', methods=['GET'])
def get_mac(mac):
    """
    Find MAC address by hostname
    ---
    tags:
        - MAC
    parameters:
        - in: path
          name: mac
          description: Hostname to lookup
          type: string
          required: true
    responses:
        200:
          description: Results of trying to locate MAC addreess by looking up the hostname.
        404:
          description: MAC Address not found.
    """
    logger = logging.getLogger(__name__)
    logger.info("Attempting to lookup mac: %s", mac)
    try:
        omapi = pypureomapi.Omapi(DHCPD_IP, DHCPD_PORT, KEYNAME, KEY)
        data = omapi.lookup_mac(mac)
        json_data = jsonify(data)
        omapi.close()
        logger.info("Found Mac: %s (%s)", mac, data)
        return json_data
    except Exception as err:
        return "MAC not found", 404

@app.route('/my/version', methods=['GET'])
def get_version():
    """
    Return version of API
    ---
    tags:
        - General
    responses:
        200:
          description: Version of API
    """
    version = pkg_resources.require("SiteServer")[0].version
    return jsonify(version)

@app.route('/my/hostname', methods=['GET'])
def get_hostname():
    """
    Return version of API
    ---
    tags:
        - General
    responses:
        200:
          description: Version of API
    """
    uname = os.uname()
    return jsonify(uname.nodename)


def get_vip():
    logger = logging.getLogger(__name__)
    ints = netifaces.interfaces()
    intf = filter(lambda x: 'vip' in x,ints)
    ret = lambda: None
    ret.ips = []
    ret.state = "<span style='color: Blue; font-weight: bolder;'>Slave</span>"

    for iface in intf:
        logger.debug("Found interface: %s", iface)

        rex = re.compile(r'vip')
        if rex.findall(iface):
            logger.debug("Interface %s identified as VIP Interface. We are the master node!!!", iface)
            ret.state = "<span style='color: Green; font-weight: bolder;'>Master</span>"
            ips = netifaces.ifaddresses(iface)
            for ipa in ips[2]:
                logger.debug("Interface: %s IP: %s", iface, ipa['addr'])
                ret.ips.append(ipa['addr'])
    return ret

@app.route("/")
def hello():
    uname = os.uname()
    version = pkg_resources.require("SiteServer")[0].version
    vip = get_vip()
    rvip = ""
    for v in vip.ips:
        rvip = "%s <br />\n%s" % (rvip, v)

    rlines = ""
    for l in tail(f="/var/log/debesys/ttss-api.log", n="300"):
        rlines = "%s %s" % (rlines, l.decode("utf-8").replace('\\n', '\n'))

    return """
        <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Trading Technologies International, Inc. - SSAPI (%s)</title>
            <style>
                html {
                   font-size: 10px;
                   font-family: sans-serif;
                }
                body {
                    font-family: 'Avenir Next Pro',Arial,Helvetica,Verdana,sans-serif;
                    color:
                    #000;
                    font-size: 16px;
                    line-height: 1.5em;
                }
                .content-wrap {
                    min-height: 100%%;
                    height: auto !important;
                    height: 100%%;
                    margin: 0 auto -60px;
                }
                .div-body {
                    width: 66%%;
                    margin: auto;
                    padding: 10px;
                }
                .vips {
                    color: #07b0d2;
                    font-weight: bolder;
                    margin-left: 45px;
                    font-size: 12px;
                    margin-top: -50px;
                    line-height: 14px;
                }
                .logs {
                    font-weight: bolder;
                    margin-left: 45px;
                    font-size: 12px;
                    margin-top: -30px;
                    line-height: 14px;
                }
            </style>
        </head>
        <body>
            <div class="content-wrap">
                <header>
                    <img src="https://id.tradingtechnologies.com/content/images/logo-words.svg?version=1575301933719" height="43px" width="205px">
                </header>
                <div class="div-body">
                    <h1> Welcome to TT SSAPI - %s</h1>
                    <p>
                        Version: <span style="font-weight: bolder; color: #6607d2">%s</span><br />
                        State: %s<br />
                        Vips: <div class="vips">%s</div><br />
                        Logs: <textarea rows="50" cols="175">%s</textarea>
                    </p>
                </div>
            </div>
        </body>
    """ % (uname.nodename, uname.nodename, version, vip.state, rvip,
           rlines)

def main():
    logger = logging.getLogger(__name__)
    logging.Formatter.converter = time.gmtime
    uname = os.uname()
    logger.info("Starting up SSAPI (v: %s) on host: %s",
                pkg_resources.require("SiteServer")[0].version, uname.nodename)
    app.run(host="0.0.0.0")

if __name__ == "__main__":
    main()
