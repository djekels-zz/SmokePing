
"""@package docstring

Python setup.py for packing. Nothing to see here.
"""
from codecs import open as openpath
from os import path
from setuptools import setup, find_packages

HERE = path.abspath(path.dirname(__file__))

# Get the long description from the README file
with openpath(path.join(HERE, 'README.md'), encoding='utf-8') as f:
    LONG_DESCRIPTION = f.read()

setup(
    name='SiteServer',
    version="0.2.42",
    python_requires='>3.6',
    description='Trading Technologies - TT Site Server Setup',
    long_description=LONG_DESCRIPTION,
    url='https://github.com/tradingtechnologies/systens_engineering',
    author='Systems Engineering',
    author_email='syseng@tradingtechnologies.com',
    license='Proprietary. All Rights Reserved',
    keywords='TTI SiteServer',     # What does your project relate to?
    include_package_data=True,
    test_suite="tests",
    packages=find_packages(exclude=['contrib', 'docs', 'tests'], include=['*']),
    package_data={'': ['templates/pointer/efi.txt',
                       'templates/pointer/mbr.txt',
                       'templates/linux/kickstart.txt',
                       'templates/linux/network.txt',
                       'templates/linux/partitions.txt',
                       'templates/linux/packages.txt',
                       'templates/linux/post.txt',
                       'templates/linux/it.txt',
                       'templates/oc/kickstart.txt',
                       'templates/oc/network.txt',
                       'templates/oc/partitions.txt',
                       'templates/oc/packages.txt',
                       'templates/oc/post.txt',
                       'templates/oc/it.txt',
                       'templates/cap/kickstart.txt',
                       'templates/cap/network.txt',
                       'templates/cap/packages.txt',
                       'templates/cap/partitions.txt',
                       'templates/cap/post.txt',
                       'templates/vmh/kickstart.txt']},
    install_requires=[
        'flasgger==0.9.3',
        'flask==1.1.1',
        'Flask-RESTful==0.3.7',
        'pypureomapi==0.8',
        'pprint==0.1',
        'pysnow==0.7.9',
        'uWSGI==2.0.18',
        'coloredlogs==10.0',
        'tzlocal==2.0.0',
        'ttsyseng==1.1.81',
        'netifaces==0.10.9',
        'Jinja2==2.10.1',
        'paramiko==2.5.1',
        'python-hpilo==4.3',
        'pyvmomi==6.7.3',
        'rstr',
        'names',
        'stringcase'
    ],
    dependency_links=[
        'https://pypi.debesys.net/pypi/ttsyseng'
    ],
    # command line tool
    entry_points={
        'console_scripts': [
            'sscli=SiteServer.main_cli:main',
            'ssapi=SiteServer.main_api:main'
        ]
    }
)
