#!/usr/bin/python

import boto3
import pprint
import sys
import argparse
import re
import ldap
import pprint
from aws_authenticator import AwsAuthenticator

parser = argparse.ArgumentParser()
parser.add_argument("-g", dest='regions',help="Define individual region (i.e us-east-1) or use 'all' for all regions")
parser.add_argument("-s", dest='showenvs',help="se=Show all availble environments.  sg=Show all available security groups.")
parser.add_argument("-e", dest='envs',help="Define the environments to execute upon, use '*' as wildcard.")
parser.add_argument("-t", dest='sgroupid',help="Define the security group ID to execute upon.")
parser.add_argument("-i", dest='instanceid',help="Define the EC2 Instance ID to execute upon.")
parser.add_argument("-w", dest='write',help="Write Changes")
parser.add_argument("-r", dest='role',help="AWS Role (Read, DevAdmins, Devs, Elastic-Beanstalk, NetworkAdmins, Admins)")
parser.add_argument("-a", dest='account',help="AWS Account (it, deb, prod)")
parser.add_argument("-p", dest='sgroupidpass',help="Security Group ID to assign.")
args = parser.parse_args()

if not args.role:
	print "You must define a role (-r) (Read, DevAdmins, Devs, Elastic-Beanstalk, NetworkAdmins, Admins)\n"
	sys.exit()
if not args.account:
	print "You must define an account (-a) (it, deb, prod)\n"
	sys.exit()
if not args.sgroupidpass and args.write:
	print "You must define a security group ID to assign (-p)\n"
	sys.exit()
m=''
sgroupid=''
sgroupid=args.sgroupid

#print(sgroupid)
#sys.exit()

auth = AwsAuthenticator(account=args.account,role=args.role)
result = auth.getKeys()
key_id = result["aws_access_key_id"]
access_key = result["aws_secret_access_key"]
token = result["security_token"]
pp = pprint.PrettyPrinter(depth=6)

def showenv():
	envlist=[]
	regions = ['us-east-1','us-west-1','us-west-2','sa-east-1','eu-west-1','eu-central-1','ap-southeast-2','ap-southeast-1','ap-northeast-1']
	for region in regions:
		ec2 = boto3.resource('ec2',region_name=region, aws_access_key_id=key_id, aws_secret_access_key=access_key, aws_session_token=token)
		if args.showenvs == "e":
			instances = ec2.instances.filter(Filters=[{'Name': 'instance-state-name', 'Values': ['running']}])
			for instance in instances:
				for tag in instance.tags:
					if tag['Key'] == 'group:env':
						envlist.append(tag['Value'])
		if args.showenvs == "g":
			for sg in ec2.security_groups.iterator():
				envlist.append(region + "\t" + sg.group_name + "\t" + sg.group_id)
	envset = set(envlist)
	sorted(envset)
	for item in envset:
		print (item)
	sys.exit()

def writechange(instance,ec2):
	print("Changing ",instance.private_ip_address,instance.id)
	sg_string_list = [args.sgroupidpass]
	instance.modify_attribute(
                Groups=sg_string_list
	)

if args.showenvs:
	ret = showenv()
if args.regions == 'all':
	regions = ['us-east-1','us-west-1','us-west-2','sa-east-1','eu-west-1','eu-central-1','ap-southeast-2','ap-southeast-1','ap-northeast-1']
else:
	regions = [args.regions]
if args.envs is None:
	print "No -e defined, assuming you want all environments."
else:
	m = re.search("\*", args.envs)

#### LOAD IN SGIDS #####


for region in regions:
	ec2 = boto3.resource('ec2',region_name=region, aws_access_key_id=key_id, aws_secret_access_key=access_key, aws_session_token=token)
	if args.instanceid:
		instances = ec2.instances.filter(InstanceIds=[args.instanceid])
	else:
		instances = ec2.instances.filter(Filters=[{'Name': 'instance-state-name', 'Values': ['running']}])
	for instance in instances:
		for sgtag in instance.security_groups:
			if sgroupid:
				if sgtag['GroupId'] == sgroupid:
					for tag in instance.tags:
						if tag['Key'] == 'group:env':
							if args.envs is not None:
								if m:
									if re.search(args.envs, tag['Value']):
										print(args.envs,tag['Value'])
										print instance.id + "," + instance.instance_type + "," + instance.private_ip_address + "," + tag['Value'] + "," + region + "," + sgtag['GroupName']
										if args.write:
											ret = writechange(instance,ec2)
								else:
									if tag['Value'] == args.envs:
										print instance.id + "," + instance.instance_type + "," + instance.private_ip_address + "," + tag['Value'] + "," + region + "," + sgtag['GroupName']
										if args.write:
											ret = writechange(instance,ec2)
							else:
								print instance.id + "," + instance.instance_type + "," + instance.private_ip_address + "," + tag['Value'] + "," + region + "," + sgtag['GroupName'] + "," + sgtag['GroupName']
								if args.write:
									ret = writechange(instance,ec2)
			else:
				if sgtag['GroupName'] != "TT-LOP" and sgtag['GroupName'] != "IT-LOP":
					for tag in instance.tags:
						if tag['Key'] == 'group:env':
							if args.envs is not None:
								if m:
									if re.search(args.envs, tag['Value']):
										print(args.envs,tag['Value'])
										print instance.id + "," + instance.instance_type + "," + instance.private_ip_address + "," + tag['Value'] + "," + region + "," + sgtag['GroupName']
										if args.write:
											ret = writechange(instance,ec2)
								else:
									if tag['Value'] == args.envs:
										print instance.id + "," + instance.instance_type + "," + instance.private_ip_address + "," + tag['Value'] + "," + region + "," + sgtag['GroupName']
										if args.write:
											ret = writechange(instance,ec2)
							else:
								print instance.id + "," + instance.instance_type + "," + instance.private_ip_address + "," + tag['Value'] + "," + region + "," + sgtag['GroupName'] + "," + sgtag['GroupName']
								if args.write:
									ret = writechange(instance,ec2)
		if args.instanceid:
			sys.exit()
