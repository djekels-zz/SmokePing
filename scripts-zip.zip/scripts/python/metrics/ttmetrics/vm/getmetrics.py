#!/bin/env python3
"""getmetrics.py

Pull VM Metrics from vcenter and push them into service now.
"""
from pprint import pprint
from tools.vmware import vmware
from tools.datacenter import datacenter as DC

def sizeof_fmt(num):
    """
    Returns the human readable version of a file size
    :param num:
    :return:
    """
    for item in ['bytes', 'KB', 'MB', 'GB']:
        if num < 1024.0:
            return "%3.1f%s" % (num, item)
        num /= 1024.0
    return "%3.1f%s" % (num, 'TB')

def main():
    vmw = vmware(host="172.17.250.184", user="intad\pivcapiuser", passwd="NoMoreL0v3", port=443).vcnt_con()

    content = vmw.RetrieveContent()
    perf = content.perfManager
    counter_info = {}

    for perfd in perf.perfCounter:
        prefix = perfd.groupInfo.key
        fullname = "%s.%s.%s" % (perfd.groupInfo.key, perfd.nameInfo.key, perfd.rollupType)
        counter_info[fullname] = perfd.key

    dcntr = content.rootFolder.childEntity

    for dcnt in dcntr:
        clstrs = dcnt.hostFolder.childEntity
        for clstr in clstrs:
            hosts = clstr.host
            if (hasattr(clstr.configuration.dasConfig.admissionControlPolicy,
                        'cpuFailoverResourcesPercent')
                    and hasattr(clstr.configuration.dasConfig.admissionControlPolicy,
                                'memoryFailoverResourcesPercent')
                    and hasattr(clstr.summary.admissionControlInfo,
                                'currentCpuFailoverResourcesPercent')
                    and hasattr(clstr.summary.admissionControlInfo,
                                'currentMemoryFailoverResourcesPercent')):

                cluster = {
                    'cluster_name': clstr.name,
                    'type': 'esxi',
                    'hosts': clstr.summary.numHosts,
                    'cpu_total': clstr.summary.totalCpu,
                    'cpu_cores': clstr.summary.numCpuCores,
                    'cpu_threads': clstr.summary.numCpuThreads,
                    'cpu_failover': clstr.configuration.dasConfig.admissionControlPolicy.cpuFailoverResourcesPercent,
                    'cpu_cur_failover': clstr.summary.admissionControlInfo.currentCpuFailoverResourcesPercent,
                    'mem_total': clstr.summary.totalMemory,
                    'mem_failover': clstr.configuration.dasConfig.admissionControlPolicy.memoryFailoverResourcesPercent,
                    'mem_cur_failover': clstr.summary.admissionControlInfo.currentMemoryFailoverResourcesPercent,
                    'vm_count': 0
                }

                #Check each Host for some stats
                for host in hosts:
                    ip_split = str(host.summary.config.name).split('.')
                    sitenet = ip_split[0] + "." + ip_split[1]
                    sn_dc = DC.dcname(sitenet=sitenet)

                    host_ret = {
                        'datacenter': sn_dc,
                        'cluster': clstr.name,
                        'hostname': "%s%svmh%s" % (sn_dc, ip_split[2], ip_split[3]),
                        'ip': host.summary.config.name,
                        'hw_vendor': host.summary.hardware.vendor,
                        'hw_model': host.summary.hardware.model,
                        'cpu_model': host.summary.hardware.cpuModel,
                        'cpu_mhz': host.summary.hardware.cpuMhz,
                        'cpu_count': host.summary.hardware.numCpuPkgs,
                        'cpu_cores': host.summary.hardware.numCpuCores,
                        'cpu_threads': host.summary.hardware.numCpuThreads,
                        'cpu_cap': (host.summary.hardware.cpuMhz *
                                    host.summary.hardware.numCpuCores),
                        'memory': sizeof_fmt(host.summary.hardware.memorySize),
                        'os_name': host.summary.config.product.fullName,
                        'os_version': host.summary.config.product.version,
                        'os_build': host.summary.config.product.build,
                        'vm_count': len(host.vm),
                    }

                    cluster['vm_count'] = (cluster['vm_count'] + len(host.vm))

                    storage = host.configManager.storageSystem
                    fsm = storage.fileSystemVolumeInfo.mountInfo

                    for fs in fsm:
                        if fs.volume.type == "VMFS":
                            exts = fs.volume.extent
                            for e in exts:
                                pprint(e)
                            filesystem = {
                                'hostname': "%s%svmh%s" % (sn_dc, ip_split[2], ip_split[3]),
                                'name': fs.volume.name,
                                'uuid': fs.volume.uuid,
                                'capacity': sizeof_fmt(fs.volume.capacity),
                                'ssd': fs.volume.ssd,
                                'local': fs.volume.local
                            }
                            pprint(filesystem)

                cluster['vm_ratio'] = round((cluster['vm_count'] / len(hosts)), 2)
                pprint(cluster)

main()