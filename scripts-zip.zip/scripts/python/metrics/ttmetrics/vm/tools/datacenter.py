#!/bin/env python3

"""datacenter.py


"""


class datacenter():
    def __init__(self):
        """
        Function: __init__
        Summary: Initiliation for class
        Attributes: 
            @param (self):
            @param (host):vcenter Host to connect to. 
            @param (user):User to connect as
            @param (passwd):Password to use
            @param (port):Port to connect to.
        """

    def dcname(sitenet):
        dcs = {
            '10.204': "m-ar",
            '10.205': "m-fr",
            '10.206': "m-ch",
            '10.102': "ar",
            '10.111': "ch",
            '10.113': "ny",
            '10.126': "ln",
            '10.127': "fr",
            '10.142': "ty",
            '10.143': "sg",
            '10.144': "sy",
            '10.145': "hk",
            '10.147': "bk",
            '10.148': "sp",
        }
        return dcs.get(sitenet, "Invalid Sitenet")
