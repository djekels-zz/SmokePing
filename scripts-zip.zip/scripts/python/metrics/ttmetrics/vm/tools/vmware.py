#!/bin/env python3

"""vmware.py

This python submodule is used for interacting with vmware as needed.
"""
import ssl
from pyVim.connect import SmartConnect, Disconnect
from pyVmomi import vmodl
from pyVmomi import vim

class vmware():
    def __init__(self, host, user, passwd, port):
        """
        Function: __init__
        Summary: Initiliation for class
        Attributes: 
            @param (self):
            @param (host):vcenter Host to connect to. 
            @param (user):User to connect as
            @param (passwd):Password to use
            @param (port):Port to connect to.
        """
        self.host = host
        self.user = user
        self.passwd = passwd
        self.port = int(port)

    def vcnt_con(self):
        """
        Function: vcnt_con
        Summary: Connect to vcenter.
        Examples: InsertHere
        Attributes: 
            @param (self):self from __init__
        Returns: vcenter Connection from pyvmomi
        """
        
        try:
            _create_unverified_https_context = ssl._create_unverified_context
        except AttributeError:
            # Legacy Python that doesn't verify HTTPS certificates by default
            pass
        else:
            # Handle target environment that doesn't support HTTPS verification
            ssl._create_default_https_context = _create_unverified_https_context

        return SmartConnect(
            host=self.host,
            user=self.user,
            pwd=self.passwd,
            port=self.port,
        )


