from setuptools import setup, find_packages
from codecs import open
from os import path

here = path.abspath(path.dirname(__file__))

setup(
    name='ttsyseng-metrics',
    version='1.0.15',
    description='Trading Technologies - SysEng Metrics',
    long_description='Trading Technologies - SysEng Metrics',
    url='https://github.com/tradingtechnologies/systems_engineering',
    author='Jeremy May',
    author_email='j@tradingtechnologies.com',
    license='Proprietary. All Rights Reserved',
    keywords='SysEng Metrics',     # What does your project relate to?
    include_package_data=True,
    packages=find_packages(exclude=['contrib', 'docs', 'tests'], include=['*']),

    install_requires=[
        'requests',
        'pyvmomi',
        'PyYAML',
        'scp',
        'paramiko'
    ],

    # command line tool
    entry_points={
        'console_scripts': [
            'metrics=ttmetrics.vm.getmetrics:main'
        ]
    }
)
