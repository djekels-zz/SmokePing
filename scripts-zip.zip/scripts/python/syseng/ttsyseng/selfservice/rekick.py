"""rekick.py

Selfservice Rekickstart Script

"""
import argparse
import logging
import re
import sys
import requests
from pprint import pprint
from pyghmi.ipmi import command
from pyghmi.ipmi.private import session
from ttsyseng.selfservice.helpers.conf_data import DCS
from ttsyseng.selfservice.helpers.tools import init_log, ssh_alive_check, startup
from ttsyseng.selfservice.helpers.ttoob import TTOob


LOGFILE = '/tmp/SelfService_rekick.log'
LOG = logging


def find_dc(name):
    if re.search('^(gl).*', name):
        ### This is Glados
        for key, val in DCS['Glados'].items():
            if re.search(key, name):
                octet = val['octet']
    elif re.search('^(?:m|m-).*$', name):
        ### This is Mock
        for key, val in DCS['Mock'].items():
            if re.search(key, name):
                octet = val['octet']
    elif re.search('^(?:sqe).*$', name):
        ### This is SQE
        for key, val in DCS['SQE'].items():
            if re.search(key, name):
                octet = val['octet']
    elif re.search('^(i).*$', name):
        ### This is TTI
        for key, val in DCS['TTI'].items():
            if re.search(key, name):
                octet = val['octet']
    else:
        ### This is prod
        for key, val in DCS['Prod'].items():
            if re.search(key, name):
                octet = val['octet']
    return octet

def args_parser():
    log = logging.getLogger(__name__)
    parser = argparse.ArgumentParser(description="BM Re-Kick")
    parser.add_argument("-H", "--host", help="Host that you would like to rekick!", required=True)
    parser.add_argument("-os", "--os_ver", help="OS Version to use!", required=True)
    parser.add_argument("-ii", "--ilo_ip", help="ilo IP, If different from our standard")
    parser.add_argument("-iu", "--ilo_user", help="ilo User, If different from our standard")
    parser.add_argument("-ip", "--ilo_pass", help="ilo Pass, If different from our standard")
    parser.add_argument(
        '-o',
        '--stdout',
        action='store_true',
        dest="stdout",
        default=False,
        help="Print output to console.")

    opts = parser.parse_args()

    split = re.search(r'((?:m\-|m)[a-zA-Z]{2,3}|[a-zA-Z]{2,3})([0-9]{1,3})([a-zA-Z]{2,5})([0-9]{2,3})' \
                      , opts.host)
    opts.dcname = split.group(1)
    opts.dcoctet = find_dc(opts.dcname)
    opts.third_octet = int(split.group(2))
    opts.type = split.group(3)
    opts.fourth_octet = int(split.group(4))
    opts.ip_addr = "10.%i.%i.%i" % (opts.dcoctet, opts.third_octet, opts.fourth_octet)
    opts.pxe_server = "10.%i.%i.30" % (opts.dcoctet, opts.third_octet)

    if not opts.ilo_ip:
        log.info("No OOB IP was passed. Attempting to use default known user...")
        if 195 <= opts.dcoctet <= 199:
            opts.dcoctet = 192
            ilo = int(opts.third_octet) + 8
            opts.ilo_ip = "10.%i.%i.%i" % (opts.dcoctet, ilo, opts.fourth_octet)
            log.info("Using OOB IP: %s", opts.ilo_ip)
        else:
            ilo = int(opts.third_octet) + 8
            opts.ilo_ip = "10.%i.%i.%i" % (opts.dcoctet, ilo, opts.fourth_octet)
            log.info("Using OOB IP: %s", opts.ilo_ip)

    else:
        log.info("OOB IP passed: %s. Using this to connect...", opts.ilo_ip)

    if not opts.ilo_user:
        log.info("No OOB User was passed. Attempting to use default known user...")
        if "gla" in opts.dcname or "glb" in opts.dcname or "glc" in opts.dcname:
            if opts.type == "srv":
                log.info("Host passed is a Glados SRV using Glados OOB username (ttadmxxx100)...")
                opts.ilo_user = "ttadmxxx100"
        else:
            log.info("host is a mock/prod srv using standard TT login (ttnet)...")
            opts.ilo_user = "ttnet"
    else:
        log.info("OOB User: %s passed. Attempting to use it...", opts.ilo_user)

    if not opts.ilo_pass:
        log.info("No OOB Password was passed. Attempting to use default known user...")
        if "gla" in opts.dcname or "glb" in opts.dcname or "glc" in opts.dcname:
            if opts.type == "srv":
                log.info("Host passed is a Glados SRV using Glados OOB Password...")
                opts.ilo_pass = "Tt12345678"
        else:
            log.info("host is a mock/prod srv using standard TT Password...")
            opts.ilo_pass = "18273645"
    else:
        log.info("OOB Password was passed. Attempting to use it...")

    return opts



def main():
    startup(app="ss_rekick")
    log = init_log()
    opts = lambda: None
    opts = args_parser()
    tto = TTOob()

    log.info("Rekickstart request for host: %s (%s)", opts.host, opts.ip_addr)

    log.info("Attempting to rekickstart using ilo: %s (%s/********)", opts.ilo_ip, opts.ilo_user)

    tmp = tto.get_hrdw(opts)

    opts.mac = tmp.mac
    opts.mac2 = tmp.mac2
    opts.host_gen = tmp.host_gen
    opts.type = tmp.type
    opts.bl = tmp.bl

    log.info("Registering host %s with site server (%s).", opts.host, opts.pxe_server)

    try:
        headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }

        if opts.os_ver == "7.4":
            opts.os_ver = "7.4.1708"
        elif opts.os_ver == "7.6":
            opts.os_ver = "7.6.1810"
        elif opts.os_ver == "7.7":
            opts.os_ver = "7.7.1908"
        elif opts.os_ver == "7.8":
            opts.os_ver = "7.8.2003"
        elif opts.os_ver == "7.9":
            opts.os_ver = "7.9.2009"
        elif opts.os_ver == "8.0":
            opts.os_ver = "8.0.1905"
        elif opts.os_ver == "8.1":
            opts.os_ver = "8.1.1911"
        elif opts.os_ver == "8.2":
            opts.os_ver = "8.2.2004"

        payload = {
            "ip": opts.ip_addr,
            "mac": opts.mac,
            "mac2": opts.mac2,
            "os_ver": opts.os_ver,
            "hst_gen": opts.host_gen,
            "hst_type": opts.type,
            "bootloader": opts.bl,
            "root_pw": "Tt12345678"
        }

        log.info("Checking if old host entry exists for: %s", opts.host)
        ssapi = "http://%s:8000/host/lookup/%s" % (opts.pxe_server, opts.host)
        response = requests.get(ssapi, headers=headers)
        if response.status_code == 200:
            #Cleaning Up Kickstart File and Kickstart Pointer File
            log.info("Found Old KS Registration for %s, Removing Old kickstart" \
                     " registration.", opts.host)
            ssapi = "http://%s:8000/host/delete/%s" % (opts.pxe_server, opts.host)
            response = requests.delete(ssapi, headers=headers)

        ssapi = "http://%s:8000/host/add/%s" % (opts.pxe_server, opts.host)
        response = requests.post(ssapi, params=payload, headers=headers)
        if response.status_code == 200:
            json_response = response.json()
            log.info("Registered Host: %s (%s/%s)", json_response['hostname'], \
                     json_response['ip'], json_response['mac'])
    except Exception as err:
        log.error("Failed to register Host. \n%s", err)

    if opts.type == "GP":
        tto.do_reboot(type="HPE", opts=opts)
    else:
        tto.do_reboot(type="OC", opts=opts)

    # Test SSH access to the Host to figure out when its fully booted up.
#    if not ssh_alive_check(ipa=opts.ip_addr):
#        log.error("Failed SSH tests. Host likely still powering on.")
#        sys.exit()
    try:
        # this will go into the while loop and wait for 200 times
        ssh_alive_check(ipa=opts.ip_addr)

        # need more time to develop the next step for baremetal
        #when completed, check if host is ready for bootstrapping
        #host_ready_bootstrap(opts.ip_addr)

    except Exception:
        log.error("Failed SSH tests. Host likely still powering on.")
        sys.exit()


if __name__ == '__main__':
    main()
