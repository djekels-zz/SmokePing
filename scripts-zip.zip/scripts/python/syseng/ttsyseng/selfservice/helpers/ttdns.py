#!/usr/bin/env python3
"""ttdns.py
DNS functions for use translating
"""
import os
import logging
import re
from ttsyseng.selfservice.helpers.conf_data import DCS, PROD, ESXI


class TTDns(object):
    """TTDns()

    Class for translating TT specific data from ip to hostname and back...
    """
    def __init__(self):
        self.esxi = ESXI
        self.log = logging.getLogger(__name__)
        self.dcs = DCS

    def get_dc(self, dc_name):

        if re.search('^(gl).*', dc_name):
            for key, val in self.dcs['Glados'].items():
                if re.search(key, dc_name):
                    ret = {
                        'dc_name': dc_name,
                        'dc_octet': val['octet'],
                        'dc_env': 'Glados',
                        'vlan_base': val['vlan_base'],
                        'domain': 'pi.domain'
                    }
        elif re.search('^(?:m|m-).*$', dc_name):
            for key, val in self.dcs['Mock'].items():
                if re.search(key, dc_name):
                    ret = {
                        'dc_name': dc_name,
                        'dc_octet': val['octet'],
                        'dc_env': 'Mock',
                        'vlan_base': val['vlan_base'],
                        'domain': 'pi.domain'
                    }
        elif re.search('^(?:sqe).*$', dc_name):
            for key, val in self.dcs['SQE'].items():
                if re.search(key, dc_name):
                    ret = {
                        'dc_name': dc_name,
                        'dc_octet': val['octet'],
                        'dc_env': 'SQE',
                        'vlan_base': val['vlan_base'],
                        'domain': 'pi.domain'
                    }
        else:
            ret = {
                'dc_name': None,
                'dc_env': None,
                'vlan_base': 4,
                'domain': 'debesys.net'
            }
        return ret


    def ttdns(self, octet):
        """
        Function: ttdns
        Summary: primary function to farm request to proper env sub-function
        Examples: ttdns(205)
        Attributes:
            @param (octet): [int] - Integer of Octet to look up.
        Returns: Datacenter Short Name
        """
        octet = int(octet)
        if octet >= 204 and octet <= 207:
            short = self.ttdns_mock(octet)
        elif octet >= 192 and octet <= 199:
            short = self.ttdns_glados(octet)
        elif octet >= 184 and octet <= 191:
            short = self.ttdns_sqe(octet)
        elif octet >= 102 and octet <= 148:
            short = self.ttdns_prod(octet)

        return short

    @staticmethod
    def ttdns_mock(octet):
        """
        Function: ttdns_mock
        Summary: sub-function for mock env.
        Examples: ttdns_mock(205)
        Attributes:
            @param (octet): [int] - Integer of Octet to look up.
        Returns: Datacenter Short Name
        """
        if octet == 204:
            short = "m-ar"
        elif octet == 205:
            short = "m-ch"
        elif octet == 206:
            short = "m-fr"
        elif octet == 207:
            short = "m-bk"

        return short

    @staticmethod
    def ttdns_glados(octet):
        """
        Function: ttdns_glados
        Summary: sub-function for glados env.
        Examples: ttdns_glados(205)
        Attributes:
            @param (octet): [int] - Integer of Octet to look up.
        Returns: Datacenter Short Name
        """
        if octet == 192:
            short = "gla"
        elif octet == 193:
            short = "glb"
        elif octet == 194:
            short = "glc"
        elif octet == 195:
            short = "gld"
        elif octet == 196:
            short = "gle"
        elif octet == 197:
            short = "glf"
        elif octet == 198:
            short = "glg"
        elif octet == 199:
            short = "glh"

        return short

    @staticmethod
    def ttdns_sqe(octet):
        """
        Function: ttdns_sqe
        Summary: sub-function for SQE env.
        Examples: ttdns_sqe(205)
        Attributes:
            @param (octet): [int] - Integer of Octet to look up.
        Returns: Datacenter Short Name
        """
        if octet == 184:
            short = "sqech"
        elif octet == 185:
            short = "sqeny"
        elif octet == 186:
            short = "sqear"
        elif octet == 187:
            short = "sqefr"
        elif octet == 188:
            short = "sqesg"
        elif octet == 189:
            short = "sqesy"
        elif octet == 190:
            short = "sqeln"
        elif octet == 191:
            short = "sqetk"

        return short

    @staticmethod
    def ttdns_prod(octet):
        """
        Function: ttdns_prod
        Summary: sub-function for prod env.
        Examples: ttdns_prod(205)
        Attributes:
            @param (octet): [int] - Integer of Octet to look up.
        Returns: Datacenter Short Name
        """
        if octet == 102:
            short = "ar"
        elif octet == 111:
            short = "ch"
        elif octet == 113:
            short = "ny"
        elif octet == 125:
            short = "ba"
        elif octet == 126:
            short = "ln"
        elif octet == 127:
            short = "fr"
        elif octet == 141:
            short = "se"
        elif octet == 142:
            short = "ty"
        elif octet == 143:
            short = "sg"
        elif octet == 144:
            short = "sy"
        elif octet == 145:
            short = "hk"
        elif octet == 147:
            short = "bk"
        elif octet == 148:
            short = "sp"

        return short

    def trslt_names(self, name):
        """
        Function: trslt_names
        Summary: convert long DC name to Short DC Name
        Examples: mock-chicago to m-ch
        Attributes:
          @param (name): Long name of DC
        Returns: Short name of DC
        """
        if "mock" in name.lower():
            short = self.trslt_mock(name)
        elif "glados" in name.lower():
            short = self.trslt_glados(name)
        elif "sqe" in name.lower():
            short = self.trslt_sqe(name)
        else:
            short = self.trslt_prod(name)

        return short

    @staticmethod
    def trslt_mock(name):
        """
        Function: trslt_mock
        Summary: translate mock to shortnames
        Examples: mock-frankfurt to m-fr
        Attributes:
            @param (name): Name to translate
        Returns: Short Name
        """
        if "mock" in name.lower():
            if "chicago" in name.lower():
                short = "m-ch"
            elif "aurora" in name.lower():
                short = "m-ar"
            elif "frankfurt" in name.lower():
                short = "m-fr"

        return short

    @staticmethod
    def trslt_glados(name):
        """
        Function: trslt_glados
        Summary: translate glados to shortnames
        Examples: glados-a to gla
        Attributes:
            @param (name): Name to translate
        Returns: Short Name
        """
        if "glados" in name.lower():
            if "-a" in name.lower():
                short = "gla"
            elif "-b" in name.lower():
                short = "glb"
            elif "-c" in name.lower():
                short = "glc"
            elif "-d" in name.lower():
                short = "gld"

        return short

    @staticmethod
    def trslt_sqe(name):
        """
        Function: trslt_sqe
        Summary: translate SQE to shortnames
        Examples: sqe-aurora to sqear
        Attributes:
            @param (name): Name to translate
        Returns: Short Name
        """
        if "sqe" in name.lower():
            if "aurora" in name.lower():
                short = "sqear"
            elif "chicago" in name.lower():
                short = "sqech"
            elif "frankfurt" in name.lower():
                short = "sqefr"
            elif "london" in name.lower():
                short = "sqeln"
            elif "new_york" in name.lower():
                short = "sqeny"
            elif "singapore" in name.lower():
                short = "sqesg"
            elif "sydney" in name.lower():
                short = "sqesy"
            elif "tokyo" in name.lower():
                short = "sqetk"

        return short

    @staticmethod
    def trslt_prod(name):
        """
        Function: trslt_prod
        Summary: translate Prod to shortnames
        Examples: frankfurt to fr
        Attributes:
            @param (name): Name to translate
        Returns: Short Name
        """
        if "chicago" in name.lower():
            short = "ch"
        elif "aurora" in name.lower():
            short = "ar"
        elif "frankfurt" in name.lower():
            short = "fr"
        elif "london" in name.lower():
            short = "ln"
        elif "new_york" in name.lower():
            short = "ny"
        elif "singapore" in name.lower():
            short = "sg"
        elif "sydney" in name.lower():
            short = "sy"
        elif "tokyo" in name.lower():
            short = "tk"
        elif "hong_kong" in name.lower():
            short = "hk"
        elif "sao_paulo" in name.lower():
            short = "sp"
        elif "basildon" in name.lower():
            short = "ba"
        elif "bangkok" in name.lower():
            short = "bk"


        return short
