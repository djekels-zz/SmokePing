import atexit
import ssl
import time
import os
import paramiko
import platform
from pyVmomi import vim
from pyVim.connect import SmartConnect, Disconnect
from paramiko import SSHClient
from scp import SCPClient
import logging

logger = logging.getLogger(__name__)


# -d m-ar -y C:\Users\lauren\Documents\repos\systems_engineering\Spacewalk\etc\demo_kickstart_config.yml

class VSphereAPI(object):
    def __init__(self, host, user, passwd, port):
        self.host = host
        self.user = user
        self.passwd = passwd
        self.port = port
        self.si = None

    def __enter__(self):
        ssl._create_default_https_context = ssl._create_unverified_context

        self.si = SmartConnect(host=self.host,
                               user=self.user,
                               pwd=self.passwd,
                               port=self.port)
        return self

    def __exit__(self, exception_type, exception_value, traceback):
        atexit.register(Disconnect, self.si)

    def get_datastore(self, cluster, cluster_name, ratio, size, disktype):
        logger.info("Find Datastore for new VM")
        size = long(size)
        for h in cluster.host:
            count = 0

            for vm in h.vm:
                if vm.runtime.powerState == "poweredOn":
                    count += 1

            if count > ratio:
                continue

            for ds in h.datastore:
                free_space = ds.summary.freeSpace / 1073741824

                if "Infrastructure" in cluster_name:
                    if "Infra" in ds.name and free_space > int(size):
                        return ds

                else:
                    if disktype == "ssd" and "SSD" in ds.name and free_space > size:
                        return ds

                    elif disktype == "san" and "3PAR" in ds.name and free_space > size:
                        return ds

        raise Exception("Required host and datastore not found for {}".format(disktype))


    def get_datacenter(self, name):
        return self.get_object([vim.Datacenter], name)

    def get_cluster(self, name):
        return self.get_object([vim.ClusterComputeResource], name)

    def get_object(self, vimtype, name):
        mob = None
        container = self.si.content.viewManager.CreateContainerView(
            self.si.content.rootFolder, vimtype, True)

        for i in container.view:
            if i.name == name or name in i.name:
                mob = i
                break

        if mob is None:
            raise Exception("ERROR: Object not found {}".format(name))

        return mob


    def create_vm(self, vm_name, cpu, memory, size, datastore, guest, vers, datacenter, resource_pool, networks):
        # Create VM after specifying datastore and configuration
        logging.info("CREATING: {} on {} with {} GigaGib DISK and {} CPUs and {} MEMORY".format(vm_name, datastore.name, size, cpu, memory))
        datastore_path = "[%s] %s" % (datastore.name, vm_name)
        vm_folder = datacenter.vmFolder
        vmx_file = vim.vm.FileInfo(logDirectory=None,
                                   snapshotDirectory=None,
                                   suspendDirectory=None,
                                   vmPathName=datastore_path)

        vm_config = vim.vm.ConfigSpec(name=vm_name, memoryMB=(long(memory) * 1024), numCPUs=int(cpu),
                                      files=vmx_file, guestId=guest, version=vers)

        vm_task = vm_folder.CreateVM_Task(config=vm_config, pool=resource_pool)
        self.wait_for_task(vm_task)

        new_vm = self.get_object([vim.VirtualMachine], vm_name)

        self.add_controller(new_vm)
        self.add_disk(new_vm, size)

        for nic in networks:

            self.add_nic(new_vm, nic)

        #self.set_boot_device(new_vm, networks[0])

        return new_vm


    def add_controller(self, vm):
        task = vm.ReconfigVM_Task(
            spec=vim.vm.ConfigSpec(
                deviceChange=[
                    vim.vm.device.VirtualDeviceSpec(
                        operation=vim.vm.device.VirtualDeviceSpec.Operation.add,
                        device=vim.vm.device.VirtualLsiLogicSASController(
                            sharedBus=vim.vm.device.VirtualSCSIController.Sharing.noSharing
                        ),
                    )
                ]
            )
        )
        self.wait_for_task(task)

    def add_disk(self, vm, disk_size):
        spec = vim.vm.ConfigSpec()
        # get all disks on a VM, set unit_number to the next available
        unit_number = 0
        for dev in vm.config.hardware.device:
            if hasattr(dev.backing, 'fileName'):
                unit_number = int(dev.unitNumber) + 1
                # unit_number 7 reserved for scsi controller
                if unit_number == 7:
                    unit_number += 1
                if unit_number >= 16:
                    logger.info("we don't support this many disks")
                    return
            if isinstance(dev, vim.vm.device.VirtualSCSIController):
                controller = dev
        # add disk here
        dev_changes = []
        new_disk_kb = int(disk_size) * 1024 * 1024
        disk_spec = vim.vm.device.VirtualDeviceSpec()
        disk_spec.fileOperation = "create"
        disk_spec.operation = vim.vm.device.VirtualDeviceSpec.Operation.add
        disk_spec.device = vim.vm.device.VirtualDisk()
        disk_spec.device.backing = \
            vim.vm.device.VirtualDisk.FlatVer2BackingInfo()
        # if disk_type == 'thin':
        #    disk_spec.device.backing.thinProvisioned = True
        disk_spec.device.backing.diskMode = 'persistent'
        disk_spec.device.unitNumber = unit_number
        disk_spec.device.capacityInKB = new_disk_kb
        disk_spec.device.controllerKey = controller.key
        dev_changes.append(disk_spec)
        spec.deviceChange = dev_changes

        task = vm.ReconfigVM_Task(spec=spec)
        self.wait_for_task(task)

        logger.info("%sGB disk added to %s" % (disk_size, vm.config.name))

    def search_port(self, dvs, portgroupkey):

        search_portkey = []
        criteria = vim.dvs.PortCriteria()
        criteria.connected = False
        criteria.inside = True
        criteria.portgroupKey = portgroupkey
        ports = dvs.FetchDVPorts(criteria)

        for port in ports:
            search_portkey.append(port.key)

        return search_portkey[0]

    def find_port(self, dvs, key):
        obj = None
        ports = dvs.FetchDVPorts()

        for i in ports:
            if i.key == key:
                obj = i
        if obj is not None:
            return obj
        else:
            raise Exception("ERROR: NO PORTS FOUND FOR DVS")

    def add_nic(self, vm, network):
        logger.info("add_nic starting")
        portgroup = self.get_object([vim.dvs.DistributedVirtualPortgroup], network)
        dvs = portgroup.config.distributedVirtualSwitch

        port_key = self.search_port(dvs, portgroup.key)
        port = self.find_port(dvs, port_key)

        spec = vim.vm.ConfigSpec()
        nic_changes = []

        nic_spec = vim.vm.device.VirtualDeviceSpec()
        nic_spec.operation = vim.vm.device.VirtualDeviceSpec.Operation.add

        nic_spec.device = vim.vm.device.VirtualVmxnet3()
        nic_spec.device.deviceInfo = vim.Description()
        nic_spec.device.deviceInfo.summary = 'tt_vsphere_api_add_nic'

        nic_spec.device.backing = \
            vim.vm.device.VirtualEthernetCard.DistributedVirtualPortBackingInfo()
        nic_spec.device.backing.port = vim.dvs.PortConnection()
        nic_spec.device.backing.port.portgroupKey = port.portgroupKey
        nic_spec.device.backing.port.switchUuid = port.dvsUuid
        nic_spec.device.backing.port.portKey = port.key

        nic_spec.device.connectable = vim.vm.device.VirtualDevice.ConnectInfo()
        nic_spec.device.connectable.startConnected = True
        nic_spec.device.connectable.allowGuestControl = True
        nic_spec.device.connectable.connected = True
        nic_spec.device.connectable.status = 'untried'

        nic_spec.device.wakeOnLanEnabled = True
        nic_spec.device.addressType = 'assigned'

        nic_changes.append(nic_spec)
        spec.deviceChange = nic_changes

        task = vm.ReconfigVM_Task(spec=spec)
        self.wait_for_task(task)

        logger.info("{} NIC ADDED".format(network))

    def set_boot_device(self, vm, network):
        boot_nic = self.get_object([vm.config.hardware.device], "VLAN400")
        vm_boot = vim.vm.ConfigSpec()
        vm_boot.bootOptions = vim.vm.BootOptions.BootableEthernetDevice(boot_nic)

        task = vm.ReconfigVM_Task(vm_boot)
        self.wait_for_task(task)

    def migrate_vm(self, vm, host, priority):
        task = vm.Migrate(pool=vm.resourcePool, host=host, priority=priority)
        self.wait_for_task(task)


    def get_mac(self, vm, network):

        net = self.get_object([vim.dvs.DistributedVirtualPortgroup], network)

        for dev in vm.config.hardware.device:
            if "Network adapter" in dev.deviceInfo.label:
                if dev.backing.port.portgroupKey == net.key:
                    return dev.macAddress

    def delete_vm(self):
        logger.info("Attempting to Deleting vm %s", vm_name)
        vm = self.get_object([vim.VirtualMachine], vm_name)
        if vm.runtime.powerState == "poweredOn":
            task = vm.PowerOff()
            self.wait_for_task(task)

        task = vm.Destroy_Task()
        self.wait_for_task(task)

    def wait_for_task(self, task):
        count = 0
        while task.info.state != "success" or task.info.state == "error":
            time.sleep(1)
            count += 1
            if count > 120:
                break

        if task.info.state != "success":
            raise Exception("ERROR: VM Task took too long or did not complete successfully: {}".format(task.info.state))
