"""conf_data.py

Settings used for the self service scripts/files

Variables:
    SETTINGS {dict} -- Settings used in various scripts
    ESXI {dict} -- ESXi Cluster settings
"""
import os

SETTINGS = {
    'ssh': {
        'attempts': 200,
        'wait': 10
    },
    'jenkins': {
        'user': os.environ.get("JENKINS_USER"),
        'token': os.environ.get("JENKINS_TOKEN")
    }
}

DCS = {
    'Glados': {
        'gla': {
            'name': "glados-a",
            'octet': 192,
            'vlan_base': 31
        },
        'glb': {
            'name': "glados-b",
            'octet': 193,
            'vlan_base': 32
        },
        'glc': {
            'name': "glados-c",
            'octet': 194,
            'vlan_base': 33
        },
        'gld': {
            'name': "glados-d",
            'octet': 195,
            'vlan_base': 34
        },
        'gle': {
            'name': "glados-e",
            'octet': 196,
            'vlan_base': 35
        },
        'glf': {
            'name': "glados-f",
            'octet': 197,
            'vlan_base': 36
        }
    },
    'Mock': {
        '(mar|m-ar)': {
            'octet': 204,
            'vlan_base': 4
        },
        '(mch|m-ch)': {
            'octet': 205,
            'vlan_base': 14
        },
        '(mfr|m-fr)': {
            'octet': 206,
            'vlan_base': 4
        },
        '(mny|m-ny)': {
            'octet': 207,
            'vlan_base': 4
        },
        '(mty|m-ty)': {
            'octet': 201,
            'vlan_base': 4
        },
        '(miny|m-iny)': {
            'octet': 207,
            'vlan_base': 4
        }
    },
    'SQE': {
        'sqeln': {
            'name': "sqe-ln",
            'octet': 190,
            'vlan_base': 21
        },
        'sqetk': {
            'name': "sqe-tk",
            'octet': 191,
            'vlan_base': 22
        },
        'sqech': {
            'name': "sqe-ch",
            'octet': 184,
            'vlan_base': 23
        },
        'sqeny': {
            'name': "sqe-ny",
            'octet': 185,
            'vlan_base': 24
        },
        'sqear': {
            'name': "sqe-ar",
            'octet': 186,
            'vlan_base': 25
        },
        'sqefr': {
            'name': "sqe-fr",
            'octet': 187,
            'vlan_base': 26
        },
        'sqesg': {
            'name': "sqe-sg",
            'octet': 188,
            'vlan_base': 27
        },
        'sqesy': {
            'name': "sqe-sy",
            'octet': 189,
            'vlan_base': 28
        }
    },
    'Prod': {
        'ar': {
            'name': "ar",
            'octet': 102,
            'vlan_base': 4
        },
        'ch': {
            'name': "ch",
            'octet': 111,
            'vlan_base': 14
        },
        'ny': {
            'name': "ny",
            'octet': 113,
            'vlan_base': 4
        },
        'ba': {
            'name': "ba",
            'octet': 125,
            'vlan_base': 4
        },
        'ln': {
            'name': "ln",
            'octet': 126,
            'vlan_base': 4
        },
        'fr': {
            'name': "fr",
            'octet': 127,
            'vlan_base': 4
        },
        'se': {
            'name': "se",
            'octet': 141,
            'vlan_base': 4
        },
        'ty': {
            'name': "sy",
            'octet': 142,
            'vlan_base': 4
        },
        'sg': {
            'name': "sg",
            'octet': 143,
            'vlan_base': 4
        },
        'sy': {
            'name': "sy",
            'octet': 144,
            'vlan_base': 4
        },
        'hk': {
            'name': "hk",
            'octet': 145,
            'vlan_base': 4
        },
        'bk': {
            'name': "bk",
            'octet': 147,
            'vlan_base': 4
        },
        'sp': {
            'name': "sp",
            'octet': 148,
            'vlan_base': 4
        },
        'jch': {
            'name': "jch",
            'octet': 211,
            'vlan_base': 11
        },
        'jln': {
            'name': "jln",
            'octet': 226,
            'vlan_base': 12
        }
    },
    'TTI': {
        'iar': {
            'name': "iar",
            'octet': 102,
            'vlan_base': 4
        },
        'ich': {
            'name': "ich",
            'octet': 111,
            'vlan_base': 4
        },
        'ifr': {
            'name': "ifr",
            'octet': 127,
            'vlan_base': 4
        },
        'iln': {
            'name': "iln",
            'octet': 126,
            'vlan_base': 4
        },
        'iny': {
            'name': "iny",
            'octet': 113,
            'vlan_base': 4
        }
    }
}

PROD = {
    'Prod': {
        'ar': {
            'octet': 102,
            'vlan_base': 4
        },
        'ch': {
            'octet': 111,
            'vlan_base': 14
        },
        'ny': {
            'octet': 113,
            'vlan_base': 4
        },
        'ba': {
            'octet': 125,
            'vlan_base': 4
        },
        'ln': {
            'octet': 126,
            'vlan_base': 4
        },
        'fr': {
            'octet': 127,
            'vlan_base': 4
        },
        'se': {
            'octet': 141,
            'vlan_base': 4
        },
        'ty': {
            'octet': 142,
            'vlan_base': 4
        },
        'sg': {
            'octet': 143,
            'vlan_base': 4
        },
        'sy': {
            'octet': 144,
            'vlan_base': 4
        },
        'hk': {
            'octet': 145,
            'vlan_base': 4
        },
        'bk': {
            'octet': 147,
            'vlan_base': 4
        },
        'sp': {
            'octet': 148,
            'vlan_base': 4
        }
    }
}

ESXI = {
    'mock': {
        'vcenter': {
            'host': '172.17.250.170',
            'port': '443',
            'user': 'administrator@vsphere.local',
            'passwd': "39'G2&TH*a6,dr_~YaH/"
        },
        'clusters': {
            'm-ar': {
                'sitename': 'Mock Aurora',
                'site_oct': '204',
                'esxi_dc_name': 'MOCK-Aurora-Debesys',
                'esxi_clstr_name': 'MOCK-AR-Cluster',
                'esxi_infra_name': None,
                'esx_ratio': 18,
                'native_vlan': '4',
                'domain': 'm-ar.debesys.net',
                'timezone': 'America/Chicago',
                'networks': {
                    'esxnet1': 'M-AR-VLAN400',
                    'esxnet2': 'M-AR-VLAN432',
                    'esxnet3': 'M-AR-VLAN448',
                    'esxnet4': 'M-AR-VLAN464'
                },
                'vm_ver': 'vmx-13',
                'osid': 'centos64Guest'
            },
            'm-ch': {
                'sitename': 'Mock Chicago',
                'site_oct': '205',
                'esxi_dc_name': 'MOCK-Chicago-Debesys',
                'esxi_clstr_name': 'MOCK-CH-Cluster',
                'esxi_infra_name': None,
                'esx_ratio': 18,
                'native_vlan': '14',
                'domain': 'm-ch.debesys.net',
                'timezone': 'America/Chicago',
                'networks': {
                    'esxnet1': 'M-CH-MTN-VLAN1400',
                    'esxnet2': 'M-CH-MTN-VLAN1432',
                    'esxnet3': 'M-CH-MTN-VLAN1448',
                    'esxnet4': 'M-CH-MTN-VLAN1464'
                },
                'vm_ver': 'vmx-13',
                'osid': 'centos64Guest'
            },
            'm-fr': {
                'sitename': 'Mock Frankfurt',
                'site_oct': '206',
                'esxi_dc_name': 'MOCK-Frankfurt-Debesys',
                'esxi_clstr_name': 'MOCK-FR-Cluster',
                'esxi_stor_clstr_name': 'DEBM-FR Storage Cluster',
                'esxi_infra_name': None,
                'esx_ratio': 18,
                'native_vlan': '4',
                'domain': 'm-fr.debesys.net',
                'timezone': 'Europe/Berlin',
                'networks': {
                    'esxnet1': 'M-FR-MTN-VLAN400',
                    'esxnet2': 'M-FR-MTN-VLAN432',
                    'esxnet3': 'M-FR-MTN-VLAN448',
                    'esxnet4': 'M-FR-MTN-VLAN464'
                },
                'vm_ver': 'vmx-13',
                'osid': 'centos64Guest'
            },
            'm-ny': {
                'sitename': 'Mock New York',
                'site_oct': '207',
                'esxi_dc_name': 'MOCK-NewYork-Debesys',
                'esxi_clstr_name': 'MOCK-NY-Cluster',
                'esxi_stor_clstr_name': 'DEBM-NY Storage Cluster',
                'esxi_infra_name': None,
                'esx_ratio': 18,
                'native_vlan': '4',
                'domain': 'm-ny.debesys.net',
                'timezone': 'America/NewYork',
                'networks': {
                    'esxnet1': 'M-NY-VLAN400',
                    'esxnet2': 'M-NY-VLAN432',
                    'esxnet3': 'M-NY-VLAN448',
                    'esxnet4': 'M-NY-VLAN464'
                },
                'vm_ver': 'vmx-13',
                'osid': 'centos64Guest'
            },
            'm-ty': {
                'sitename': 'Mock Tokyo',
                'site_oct': '201',
                'esxi_dc_name': 'MOCK-Tokyo-Debesys',
                'esxi_clstr_name': 'MOCK-TY-Cluster',
                'esxi_infra_name': 'MOCK TY Infrastructure',
                'esxi_stor_clstr_name': 'DEBM-TY Storage Cluster',
                'esx_ratio': 18,
                'native_vlan': '4',
                'domain': 'm-ty.debesys.net',
                'timezone': 'Asia/Tokyo',
                'networks': {
                    'esxnet1': 'M-TY-VLAN400',
                    'esxnet2': 'M-TY-VLAN432',
                    'esxnet3': 'M-TY-VLAN448',
                    'esxnet4': 'M-TY-VLAN464'
                },
                'vm_ver': 'vmx-13',
                'osid': 'centos64Guest'
            }
        }
    },
    'prod': {
        'vcenter': {
            'host': '172.17.250.184',
            'port': '443',
            'user': 'pivcapiuser@int.tt.local',
            'passwd': 'NoMoreL0v3'
        },
        'clusters': {
            'ar': {
                'sitename': 'Aurora',
                'site_oct': 102,
                'esxi_dc_name': 'Debesys-Aurora',
                'esxi_clstr_name': 'AR SL210t G8 Cluster',
                'esxi_infra_name': 'TT AR Infrastructure',
                'esx_ratio': 18,
                'native_vlan': '4',
                'domain': 'ar.debesys.net',
                'timezone': 'America/Chicago',
                'networks': {
                    'esxnet1': 'AR-VLAN400',
                    'esxnet2': 'AR-VLAN432',
                    'esxnet4': 'AR-VLAN448'
                },
                'vm_ver': 'vmx-13',
                'osid': 'centos64Guest'
            },
            'ch': {
                'sitename': 'Chicago',
                'site_oct': 111,
                'esxi_dc_name': 'Debesys-Chicago',
                'esxi_clstr_name': 'CH SL210t G8 Cluster',
                'esxi_infra_name': 'TT CH Infrastructure',
                'esx_ratio': 18,
                'native_vlan': '14',
                'domain': 'ch.debesys.net',
                'timezone': 'America/Chicago',
                'networks': {
                    'esxnet1': 'CH-VLAN1400',
                    'esxnet2': 'CH-VLAN1432',
                    'esxnet4': 'CH-VLAN1448'
                },
                'vm_ver': 'vmx-13',
                'osid': 'centos64Guest'
            },
            'ny': {
                'sitename': 'New York',
                'site_oct': 113,
                'esxi_dc_name': 'Debesys-NewYork',
                'esxi_clstr_name': 'NY SL210t G8 Cluster',
                'esxi_infra_name': 'TT NY Infrastructure',
                'esx_ratio': 18,
                'native_vlan': '4',
                'domain': 'ny.debesys.net',
                'timezone': 'America/New_York',
                'networks': {
                    'esxnet1': 'NY-VLAN400',
                    'esxnet2': 'NY-VLAN432',
                    'esxnet4': 'NY-VLAN448'
                },
                'vm_ver': 'vmx-13',
                'osid': 'centos64Guest'
            },
            'sp': {
                'sitename': 'Sao Paulo',
                'site_oct': 148,
                'esxi_dc_name': 'Debesys-SaoPaulo',
                'esxi_clstr_name': 'SP DL360 G10 Cluster',
                'esxi_infra_name': 'TT SP Infrastructure',
                'esx_ratio': 18,
                'native_vlan': '4',
                'domain': 'sp.debesys.net',
                'timezone': 'America/Sao_Paulo',
                'networks': {
                    'esxnet1': 'SP-VLAN400',
                    'esxnet2': 'SP-VLAN432',
                    'esxnet4': 'SP-VLAN448'
                },
                'vm_ver': 'vmx-13',
                'osid': 'centos64Guest'
            },
            'ln': {
                'sitename': 'London',
                'site_oct': 126,
                'esxi_dc_name': 'Debesys-London',
                'esxi_clstr_name': 'LN DL360 G9 Cluster',
                'esxi_infra_name': 'TT LN Infrastructure',
                'esx_ratio': 18,
                'native_vlan': '4',
                'domain': 'ln.debesys.net',
                'timezone': 'Europe/London',
                'networks': {
                    'esxnet1': 'LN-VLAN400',
                    'esxnet2': 'LN-VLAN432',
                    'esxnet4': 'LN-VLAN448'
                },
                'vm_ver': 'vmx-13',
                'osid': 'centos64Guest'
            },
            'ba': {
                'sitename': 'Basildon',
                'site_oct': 125,
                'esxi_dc_name': 'Debesys-Basildon',
                'esxi_clstr_name': None,
                'esxi_infra_name': 'TT BA Infrastructure',
                'esx_ratio': 18,
                'native_vlan': '4',
                'domain': 'ln.debesys.net',
                'timezone': 'Europe/London',
                'networks': {
                    'esxnet1': 'BA-VLAN400',
                    'esxnet2': 'BA-VLAN432',
                    'esxnet4': 'BA-VLAN448'
                },
                'vm_ver': 'vmx-13',
                'osid': 'centos64Guest'
            },
            'fr': {
                'sitename': 'Frankfurt',
                'site_oct': 127,
                'esxi_dc_name': 'Debesys-Frankfurt',
                'esxi_clstr_name': 'FR SL210t G8 Cluster',
                'esxi_infra_name': 'TT FR Infrastructure',
                'esx_ratio': 18,
                'native_vlan': '4',
                'domain': 'fr.debesys.net',
                'timezone': 'Europe/Berlin',
                'networks': {
                    'esxnet1': 'FR-VLAN400',
                    'esxnet2': 'FR-VLAN432',
                    'esxnet4': 'FR-VLAN448'
                },
                'vm_ver': 'vmx-13',
                'osid': 'centos64Guest'
            },
            'ty': {
                'sitename': 'Tokyo',
                'site_oct': 142,
                'esxi_dc_name': 'Debesys-Tokyo',
                'esxi_clstr_name': 'TY DL360 G9 Cluster',
                'esxi_infra_name': 'TT TY Infrastructure',
                'esx_ratio': 18,
                'native_vlan': '4',
                'domain': 'ty.debesys.net',
                'timezone': 'Asia/Tokyo',
                'networks': {
                    'esxnet1': 'TY-VLAN400',
                    'esxnet2': 'TY-VLAN432',
                    'esxnet3': 'TY-VLAN448'
                },
                'vm_ver': 'vmx-13',
                'osid': 'centos64Guest'
            },
            'hk': {
                'sitename': 'Hong Kong',
                'site_oct': 145,
                'esxi_dc_name': 'Debesys-HongKong',
                'esxi_clstr_name': 'HK DL360 G9 Cluster',
                'esxi_infra_name': 'TT HK Infrastructure',
                'esx_ratio': 18,
                'native_vlan': '4',
                'domain': 'hk.debesys.net',
                'timezone': 'Asia/Hong_Kong',
                'networks': {
                    'esxnet1': 'HK-VLAN400',
                    'esxnet2': 'HK-VLAN432',
                    'esxnet4': 'HK-VLAN448'
                },
                'vm_ver': 'vmx-13',
                'osid': 'centos64Guest'
            },
            'sy': {
                'sitename': 'Sydney',
                'site_oct': 144,
                'esxi_dc_name': 'Debesys-Sydney',
                'esxi_clstr_name': 'SY SL210t G8 Cluster',
                'esxi_infra_name': 'TT SY Infrastructure',
                'esx_ratio': 18,
                'native_vlan': '4',
                'domain': 'sy.debesys.net',
                'timezone': 'Australia/Sydney',
                'networks': {
                    'esxnet1': 'SY-VLAN400',
                    'esxnet2': 'SY-VLAN432',
                    'esxnet4': 'SY-VLAN448'
                },
                'vm_ver': 'vmx-13',
                'osid': 'centos64Guest'
            },
            'sg': {
                'sitename': 'Singapore',
                'site_oct': 143,
                'esxi_dc_name': 'Debesys-Singapore',
                'esxi_clstr_name': 'SG SL210t G8 Cluster',
                'esxi_infra_name': 'TT SG Infrastructure',
                'esx_ratio': 18,
                'native_vlan': '4',
                'domain': 'sg.debesys.net',
                'timezone': 'Asia/Singapore',
                'networks': {
                    'esxnet1': 'SG-VLAN400',
                    'esxnet2': 'SG-VLAN432',
                    'esxnet4': 'SG-VLAN448'
                },
                'vm_ver': 'vmx-13',
                'osid': 'centos64Guest'
            },
            'bk': {
                'sitename': 'Bangkok',
                'site_oct': 147,
                'esxi_dc_name': 'Debesys-Bangkok',
                'esxi_clstr_name': None,
                'esxi_infra_name': 'TT BK Infrastructure',
                'esx_ratio': 18,
                'native_vlan': '4',
                'domain': 'bk.debesys.net',
                'timezone': 'Asia/Bangkok',
                'networks': {
                    'esxnet1': 'BK-VLAN400',
                    'esxnet2': 'BK-VLAN432',
                    'esxnet4': 'BK-VLAN448'
                },
                'vm_ver': 'vmx-13',
                'osid': 'centos64Guest'
            },
            'se': {
                'sitename': 'Seoul',
                'site_oct': 141,
                'esxi_dc_name': 'Debesys-Seoul',
                'esxi_clstr_name': None,
                'esxi_infra_name': 'TT SE Infrastructure',
                'esx_ratio': 18,
                'native_vlan': '4',
                'domain': 'se.debesys.net',
                'timezone': 'Asia/Seoul',
                'networks': {
                    'esxnet1': 'SE-VLAN400',
                    'esxnet2': 'SE-VLAN432',
                    'esxnet4': 'SE-VLAN448'
                },
                'vm_ver': 'vmx-13',
                'osid': 'centos64Guest'
            }
        }
    }
}

NTNX = {
    'Hawaii': {
        'acropolis_url': "https://10.35.0.254:9440/api/nutanix/v2.0/",
        'prism_url': "https://10.35.0.254:9440/PrismGateway/services/rest/v1/",
        'web_url': "https://10.35.0.254:9440",
        'ipaddress': '10.35.0.254'
    },
    'Mykonos': {
        'acropolis_url': "https://10.35.0.251:9440/api/nutanix/v2.0/",
        'prism_url': "https://10.35.0.251:9440/PrismGateway/services/rest/v1/",
        'web_url': "https://10.35.0.251:9440",
        'ipaddress': '10.35.0.251'
    },
    'Santorini': {
        'acropolis_url': "https://10.35.0.253:9440/api/nutanix/v2.0/",
        'prism_url': "https://10.35.0.253:9440/PrismGateway/services/rest/v1/",
        'web_url': "https://10.35.0.253:9440",
        'ipaddress': '10.35.0.253'
    },
    'Calvera': {
        'acropolis_url': "https://10.226.64.30:9440/api/nutanix/v2.0/",
        'prism_url': "https://10.226.64.30:9440/PrismGateway/services/rest/v1/",
        'web_url': "https://10.226.64.30:9440",
        'ipaddress': '10.226.64.30'
    },
    'Barbados': {
        'acropolis_url': "https://10.35.2.253:9440/api/nutanix/v2.0/",
        'prism_url': "https://10.35.2.253:9440/PrismGateway/services/rest/v1/",
        'web_url': "https://10.35.2.253:9440",
        'ipaddress': '10.35.2.253'
    },
    'Grenada': {
        'acropolis_url': "https://10.35.2.254:9440/api/nutanix/v2.0/",
        'prism_url': "https://10.35.2.254:9440/PrismGateway/services/rest/v1/",
        'web_url': "https://10.35.2.254:9440",
        'ipaddress': '10.35.2.254'
    },
    'Polaris': {
        'acropolis_url': "https://10.211.64.30:9440/api/nutanix/v2.0/",
        'prism_url': "https://10.211.64.30:9440/PrismGateway/services/rest/v1/",
        'web_url': "https://10.211.64.30:9440",
        'ipaddress': '10.211.64.30'
    }
}
