#!/usr/bin/env python3
"""chef.py
Classes and Functions used with the interaction of Chef.
"""
import logging
import json
import requests
from ttsyseng.selfservice.helpers.conf_data import SETTINGS,DCS,NTNX

class TTNtnx(object):

    def __init__(self):
        self.log = logging.getLogger(__name__)
        self.ntnx = NTNX
        self.sess = requests.Session()
        requests.packages.urllib3.disable_warnings()
        self.sess.auth = ('ops-monitoring@int.tt.local', 'lUtw4oSMRSuV')


    def get_vms(self, cluster):
        """
        Function: get_vms
        Summary: Grab list of VM's from Nutanix
        Examples: get_vms(cluster="Hawaii")
        Attributes: 
            @param (cluster):Cluster Name to Grab from...
        Returns: Dictionary of VM's on this cluster.
        """
        self.log.info("Getting list of VMs from Nutanix cluster %s...", cluster)
        ntnx_vms = {}
        url = "%s/vms/" % (NTNX[cluster]['acropolis_url'])
        req = self.sess.get(url, verify=False)
        ntnx_list = req.json()['entities']
        for ntx_vm in ntnx_list:
            ntnx_vms[ntx_vm["name"]] = {}
        return ntnx_vms
