"""TTJenkins

Used for interacting with jenkins.

Variables:
    HTTP_CODES_TO_RETRY {list} -- HTTP Status Codes to retry the job on. 
"""
import sys
import json
import datetime
import re
import os
import requests
import time
import logging
from pprint import pprint
from ttsyseng.selfservice.helpers.conf_data import SETTINGS

USER = os.environ.get("JENKINS_USER")
TOKEN = os.environ.get("JENKINS_TOKEN") 

HTTP_CODES_TO_RETRY = [500]
class TTJenkins:

    def __init__(
        self,
        user,
        token,
        verbose=True,
        verbose_timestamps=None,
        synchronous=None,
        upload=None,
        allow_output_to_console=True,
        prefix='',
         allow_output_on_worker_assigned=False
        ):

        self.user = user
        self.token = token
        self.auth = (self.user, self.token)
        self.server = 'https://jenkins.tradingtechnologies.com'
        self.verbose = verbose
        self.verbose_timestamps = verbose_timestamps
        self.my_guid = ""
        self.request_number = 0
        self.request_url = ""
        self.request_completed_successfully = False
        self.allow_output_to_console = allow_output_to_console
        self.prefix = prefix
        self.allow_output_on_worker_assigned = allow_output_on_worker_assigned
        self.retry_timeout = 0

    def output(self, value, same_line=False):
        if self.allow_output_to_console:
            sys.stdout.write(value)
            if not same_line:
                sys.stdout.write("\n")
            sys.stdout.flush()

    def now(self):
        return str(datetime.datetime.now())

    def get_all_job_url(self, job):
        return "{0}/job/{1}".format(self.server, job)

    def launch_job(
        self,
        job,
        params={},
        wait=False
        ):
        """
        Launches a Jenkins job
        :param name: Name of job to launch
        :param params: A dictionary containing the name/value pairs of each param
            For example: if there are 2 parameters: GIT_BRANCH and UPLOAD
            {'BRANCH':'develop','UPLOAD_TAG':'','UPLOAD':'False'}
        :param wait: If true block until the the job has completed, otherwise
        return once the job has been received.
        Returns True if the job completed successfully (or received successfully if the parameter
        wait is False).
        """

        headers = {}
        # ----------------------------------------------------
        # Mon May 09 06:58:05 2016 - tgooderham : DEB-40551
        # Generate and include Cross Site Request Forgery protection header
        # Ref: https://cloudbees.zendesk.com/hc/en-us/articles/218671418-CSRF-protection-prevents-a-plugin-to-work
        # ----------------------------------------------------
        url = "{0}/crumbIssuer/api/xml".format(self.server)
        crumb_token = ''
        response = requests.get(url, auth=self.auth)


       #
        # This check can be removed after the full switch over has taken place
        # A 404 error indicates that Security is disabled, thus no need to add this.
        # Response contains something like: '.crumb:8b6bf93d3801daadb36f18bea08ee01a'
        # which then will be passed into the post request header
        #
        if response.status_code != 404:
            crumb_html = response.content.decode('utf-8')
            crumb_value_regex = re.compile("<crumb>(?P<crumb_value>[a-z0-9]*)</crumb>")
            crumb_key_regex = re.compile("<crumbRequestField>(?P<crumb_key>.*)</crumbRequestField>")
            crumb_key = 'invalid'
            crumb_value = 'invalid'

            result_key = crumb_key_regex.search(crumb_html)
            if result_key is None:
                self.logit("Failed to find crumb key in '{0}'.".format(crumb_html))

            try:
                crumb_key = result_key.groupdict().get("crumb_key")
            except:
                self.logit("Failed to find crumb key in '{0}'.".format(crumb_html))

            result_value = crumb_value_regex.search(crumb_html)
            if result_value is None:
                self.logit("Failed to find crumb value in '{0}'.".format(crumb_html))

            try:
                crumb_value = result_value.groupdict().get("crumb_value")
            except:
                self.logit("Failed to find crumb in '{0}'.".format(crumb_html))

            headers[crumb_key] = crumb_value
            self.logit( "Adding key '{0}' with value '{1}' to header.".format(
                crumb_key, crumb_value))

        # ----------------------------------------------------
        # Convert dictionary into list of dict's needed by api
        # ----------------------------------------------------
        args = []
        for argName in params:
            argValue = params[argName]
            args.append({'name': argName, 'value': argValue})

            # For this library to be able to determine the status
            # of a request, one of the user's arguments need to
            # be a a guid.  Otherwise the library can only be used
            # in asynchronous mode.
            if "GUID" == argName:
                self.my_guid = argValue

        message = "Launching your request ({0}".format(job)
        if len(self.my_guid) != 0:
            message += ", instance {0}).".format(self.my_guid)
        else:
            message += ")."
        self.output(message)

        url = self.server + '/job/' + job + '/build'
        payload = {'json': json.dumps({'parameter': args})}

        if not self.post_request(url, payload, headers=headers):
            self.output("Your request was **NOT** successfully received, rerun your request\n"
                        "with -v and contact deployment@tradingtechnologies for help.")
            return False
        self.output("Your request has been successfully received.")
        self.output("All {0} requests: {1}/job/{2}".format(job, self.server, job))

        if not wait:
            self.output("You will receive an email when your request is finished.")
            return True

        # The GUID is how we can track a job.  If this class is being used and caller
        # didn't provide a GUID in the argument, then inform them.  The remedy is to
        # add an argument to the job named GUID and update the caller to generate and
        # pass it.
        if len(self.my_guid) == 0 and wait:
            self.output("Your request didn't have a GUID argument and can't be tracked.\n"
                        "Your job is likely running and you can use the above URL to monitor\n"
                        "it.  You will receive an email when your request is finished.")
            return False

        try:
            self.find_my_request(job)
        except Exception as ex:
            self.output(str(ex))
            self.output("An unexpected error happened while trying to locate your request.\n"
                        "It's very likely your request is still processing, use the link above\n"
                        "to search for your request and please email deployment@tradingtechnologies.com\n"
                        "with this error.")
            return False

        if 0 == len(self.request_url):
            # This will happen if the request is aborted while still in the queue waiting for a resource.
            return False

        request_running = "Your request is running, use the following URLs for details:\n{0}\n{0}console".format(
            self.request_url)
        self.output(request_running)

        if(False == self.allow_output_to_console and
           True == self.allow_output_on_worker_assigned):
            # Most callers of ttjenkins either want it to write to stdout or not.  However, the case
            # or request_build.py is more complex.  In that case, muliple instances are created in
            # different threads and processed in parallel.  I felt it was worthwhile to allow this
            # script to skip the rest of the stdout, but get the job's url once running.  I feel the
            # benefit to the users is worth the strangeness in the ttjenkins interface.
            message = ("{0}build/package is running, details:\n                  {1}".format(
                    self.prefix, self.request_url))
            print(message)

        self.wait_for_my_job()
        return self.request_completed_successfully


    def find_my_request(self, job):
        """
        Wait for the the request to show up in the queue of requests or
        in the set of builds happening.  Print status while in the queue
        and return once this jobs request_number and request_url have
        been found.
        """
        queue_url = self.server + '/queue/api/json'
        jobs_url = self.server + '/job/' + job + '/api/json?depth=1'

        # Normally my request will be found in the queue and then found in
        # the jobs_info query.  Once found in the jobs_info query, this function
        # returns.  However, if a request is cancelled before it's working (and
        # therefore not in the jobs_info query) the request will be removed from
        # the queue.  There isn't any known way to get information about these
        # requests.  Based on those observations, we'll wait some amount of time
        # if the request is found in neither the queue nor the jobs_info query.
        # After that time expires, print an error message and return.
        loop_sleep = 2
        loop_iterations_my_request_missing_max = 5
        loop_iterations_my_request_missing = 0

        queue_start = datetime.datetime.now()
        # retry for up to ten minutes
        self.retry_timeout = time.time()+120

        while True:
            # Look in the queue of waiting jobs, the queue holds all requests not
            # just requests for this job.  Check if my request is in the queue and
            # determine its number in the queue.  When my job is in the queue, it
            # has not been assigned a job number, but it does have an identifier
            # which represents its position in the queue.
            my_queue_id = -1

            # queue_ids is a set of all the queue ids of jobs that are other
            # instances of the same job as me.  Keeping track of all the
            # queue ids of my peers is a reasonable estimate of my position.
            # This assumes that all peers go into the same pool and does not
            # take into account other types of jobs which might share the
            # worker pool with my job type.  Regardless, it's decent feedback
            # to give to the engineer.
            queue_ids = list()

            try:
                queue = self.get_request(queue_url)
            except Exception as ex:
                self.http_exception(ex)

            if queue == -1:
                # Got Http error from HTTP_CODES_TO_RETRY list, try again
                time.sleep(2)
                continue
            else:
                self.retry_timeout = time.time()+120
            for item in queue['items']:
                if 'task' in item:
                    if 'name' in item['task']:
                        if item['task']['name'] == job:
                            queue_ids.append(item['id'])

                if self.find_my_guid_in_actions(item['actions']):
                    my_queue_id = item['id']

            if my_queue_id in queue_ids:
                queue_ids.sort()
                # The extra spaces at the end allow ensure different size output does not leave characters.
                self.output("Waiting for a resource, you're position in line is {0} of {1}.                 \r".format(
                    queue_ids.index(my_queue_id) + 1, len(queue_ids)), same_line=True)
                sys.stdout.flush()

            try:
                jobs_info = self.get_request(jobs_url)
            except Exception as ex:
                self.http_exception(ex)

            if jobs_info == -1:
                # Got Http error from HTTP_CODES_TO_RETRY list, try again
                time.sleep(2)
                continue
            else:
                self.retry_timeout = time.time()+120
            for build in jobs_info['builds']:
                if self.find_my_guid_in_actions(build['actions']):
                    self.request_number = build['number']
                    self.request_url = build['url']
                    self.output("") # This flushes so the \r print above, otherwise that is left over.
                    queue_end = datetime.datetime.now()
                    elapsed = queue_end - queue_start
                    mins, secs = divmod(elapsed.seconds, 60)
                    hours, mins = divmod(mins, 60)
                    self.output("Your request waited {0}h {1}m {2}s for a resource.".format(hours, mins, secs))
                    return

            # My request was in neither the queue nor the jobs_info query, likely aborted in the queue.
            if my_queue_id not in queue_ids:
                loop_iterations_my_request_missing += 1

            if loop_iterations_my_request_missing >= loop_iterations_my_request_missing_max:
                self.output("") # This flushes so the \r print above, otherwise that is left over.
                self.output("Your request can't be found and was likely aborted.")
                return

            time.sleep(loop_sleep)


    def wait_for_my_job(self):
        start = datetime.datetime.now()
        # retry for up to 10 minutes
        self.retry_timeout = time.time()+120
        while True:
            try:
                my_request = self.get_request(self.request_url + '/api/json')
            except Exception as ex:
                self.http_exception(ex)
            if my_request == -1:
                # Got Http error from HTTP_CODES_TO_RETRY list, try again
                time.sleep(2)
                continue
            else:
                self.retry_timeout = time.time()+120
            if my_request['result'] is not None:
                end = datetime.datetime.now()
                elapsed = end - start
                mins, secs = divmod(elapsed.seconds, 60)
                hours, mins = divmod(mins, 60)
                self.output("Your request took {0}h {1}m {2}s to finish.".format(hours, mins, secs))
                message = "Your request finished with result: {0}".format(my_request['result'])
                if my_request['result'] != "SUCCESS":
                    message += " <-- Use the URLs to get details."
                else:
                    self.request_completed_successfully = True
                self.output(message)
                break
            time.sleep(2)


    def find_my_guid_in_actions(self, actions):
        for action in actions:
            if 'parameters' in action:
                parameters = action['parameters']
                for parameter in action['parameters']:
                    if parameter['name'] == 'GUID' and self.my_guid == parameter['value']:
                        return True
        return False


    def get_request(self, url):
        """
        Submits a get request and returns a json decoded object response
        Returns dictionary of response.content or True if successful.
        Returns -1 if it fails but the status code is on the retry list.
        """

        self.logit('Requesting: {0}'.format(url))

        r = requests.get(url, auth=self.auth)
        if r.status_code == requests.codes.ok:
            content = json.loads(r.content)
            if self.verbose:
                self.output(json.dumps(content, sort_keys=True, indent=4, separators=(',', ': ')))
            return content
        elif r.status_code in HTTP_CODES_TO_RETRY and self.retry_timeout > time.time():
            self.logit('HTTP error code {0}, retrying'.format(r.status_code))
            return -1
        else:
            r.raise_for_status()


    def post_request(self, url, data, headers={}):
        """
        Submits a post request and returns a json decoded object response
        Returns True if successful. False if otherwise
        """

        self.logit('{0} {1}'.format(url, data))

        try:
            r = requests.post(url, auth=self.auth, data=data, headers=headers)
            self.logit("Received response {0}.".format(r.status_code))
            # ----------------------------------------------------
            # Submitting a job returns a 201 response code,
            # which contains no content
            # ----------------------------------------------------
            if r.status_code == 201:
                return True

        except requests.exceptions.RequestException as ex:
            self.logit('Error in '
                       + '{0}: {1}'.format(sys._getframe().f_code.co_name,
                       ex))


    def logit(self, msg):
        if self.verbose:
            if self.verbose_timestamps:
                self.output('[{0}] {1}'.format(self.now(), msg))
            else:
                self.output('{0}'.format(msg))

    def http_exception(self, ex):
        self.output(str(ex))
        self.output("ATTENTION: While polling to determine the status of your request, the server returned too many errors.\n"
                    "Please use the URLs above to determine the status of your request.\n"
                    "This error does not necessarily mean your request is no longer running.\n")
