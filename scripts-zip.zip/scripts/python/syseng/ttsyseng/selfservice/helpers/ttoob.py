"""ttoob.py

class for interacting with ipmi/ilo/snow
"""
import logging
import re
import sys
import hpilo
import pysnow
from pyghmi.ipmi import command
from pyghmi.ipmi.private import session
from pprint import pprint

def check_mac(arg_value,
                  pat=re.compile(r'^([0-9a-fA-F][0-9a-fA-F]:){5}([0-9a-fA-F][0-9a-fA-F])$')):
    """check_mac

    validate that mac provided by user fits our pattern...

    Arguments:
        arg_value {string} -- mac to check
    Returns:
        [string] -- valid mac string
    """
    if not pat.match(arg_value):
        raise argparse.ArgumentTypeError("Provided Mac (%s), does not match the " \
                                         "pattern of a proper mac address..." % arg_value)
    return arg_value

class TTOob():
    """TTOob()

    class for interacting with ipmi/ilo/snow
    """
    def __init__(self):
        self.log = logging.getLogger(__name__)
        self.sna = pysnow.Client(instance='tradingtech', user='svc-elsrw', password='P8pcqQdf')

        self.sna.parameters.display_value = True

    def get_snow(self, host):
        """get_snow

        retrieve host data from SNOW

        Arguments:
            host {string} -- hostname to lookup in snow...
        """
        self.log.info("Trying to locate host %s in SNOW.", host)
        try:
            snh = self.sna.resource(api_path='/table/cmdb_ci_server')
            snh_resp = snh.get(query={'name': host}).one()

            if not snh_resp['mac_address']:
                self.log.error("Host found in SNOW, but is missing the 'mac_address' field")
                sys.exit(255)



        except Exception as err:
            self.log.error("Failed to locate host %s in SNOW... %s", host, err)
            sys.exit(255)

        return snh_resp

    def get_hw_bl(self, oob, host):
        """get_hw_bl

        Get the Bootloader mode from OOB

        Arguments:
            oob {object} -- class object for interacting with hpilo.
            host {string} -- host to connect to.

        Returns:
            [type] -- [description]
        """
        self.log.info("[OOB] Checking OOB for Boot Loader Type...")
        try:
            boot_mode = oob.get_current_boot_mode()

            self.log.info("[OOB] Identified Boot mode as: %s", boot_mode)
            if re.search(r"legacy", boot_mode, flags=re.IGNORECASE):
                ret = "mbr"
            else:
                ret = "efi"
        except Exception as err:
            ret = False

        return ret

    def get_hrdw_hpe(self, opts, snow, ilo):
        """get_hrdw_hpe

        Logic for grabbing the info from snow and putting it into the return object.

        Arguments:
            opts {[type]} -- [description]
            snow {[type]} -- [description]
        """
        ret = lambda: None
        if re.search(r"(G6|G 6|Gen6|Gen 6)", snow['model_id']['display_value'] \
                     , flags=re.IGNORECASE):
            ret.host_gen = "Gen 6"
            ret.bl = "mbr"
        elif re.search(r"(G7|G 7|Gen7|Gen 7)", snow['model_id']['display_value'], \
                       flags=re.IGNORECASE):
            ret.host_gen = "Gen 7"
            ret.bl = "mbr"
        elif re.search(r"(G8|G 8|Gen8|Gen 8)", snow['model_id']['display_value'], \
                       flags=re.IGNORECASE):
            ret.host_gen = "Gen 8"
            bootloader = self.get_hw_bl(ilo, opts.host)
            if not bootloader:
                self.log.warning("Failed to locate BL via OOB. Defaulting to MBR...")
                ret.bl = "mbr"
            else:
                ret.bl = bootloader
        elif re.search(r"(G9|G 9|Gen9|Gen 9)", snow['model_id']['display_value'],
                       flags=re.IGNORECASE):
            ret.host_gen = "Gen 9"
            bootloader = self.get_hw_bl(ilo, opts.host)
            if not bootloader:
                self.log.warning("Failed to locate BL via OOB. Defaulting to efi...")
                ret.bl = "efi"
            else:
                ret.bl = bootloader
        elif re.search(r"(G10|G 10|Gen10|Gen 10)", snow['model_id']['display_value'],
                       flags=re.IGNORECASE):
            ret.host_gen = "Gen 10"
            bootloader = self.get_hw_bl(ilo, opts.host)
            if not bootloader:
                self.log.warning("Failed to locate BL via OOB. Defaulting to efi...")
                ret.bl = "efi"
            else:
                ret.bl = bootloader
        elif re.search(r"(G11|G 11|Gen11|Gen 11)", snow['model_id']['display_value'], \
                       flags=re.IGNORECASE):
            ret.host_gen = "Gen 11"
            bootloader = self.get_hw_bl(ilo, opts.host)
            if not bootloader:
                self.log.warning("Failed to locate BL via OOB. Defaulting to efi...")
                ret.bl = "efi"
            else:
                ret.bl = bootloader

        return ret

    def get_hrdw(self, opts):
        """get_hrdw()

        gather hostgen and other required data...
        """
        snow = self.get_snow(host=opts.host)
        ret = lambda: None

        if snow['manufacturer']['display_value'] == "HP" or snow['manufacturer']['display_value'] \
           == "HPE":
            ilo = hpilo.Ilo(opts.ilo_ip, login=opts.ilo_user,
                            password=opts.ilo_pass, ssl_verify=False)

            tmp = self.get_hrdw_hpe(opts, snow, ilo)

            ret.host_gen = tmp.host_gen
            ret.bl = tmp.bl

            ret.type = "GP"

        elif "ICC" in snow['manufacturer']['display_value'] or  \
             "International Computer Concepts" in snow['manufacturer']['display_value'] or \
             "CIARA" in snow['manufacturer']['display_value']:
            if 'ICC' in snow['model_id']['display_value']:
                ret.host_gen = "ICC"
                ret.type = "OC"
            elif 'CIARA' in snow['model_id']['display_value']:
                ret.host_gen = "CIARA"
                ret.type = "OC"
                ret.bl = "efi"
            elif 'ORION' in snow['model_id']['display_value']:
                ret.host_gen = "CIARA"
                ret.type = "OC"
                ret.bl = "mbr"
        else:

            self.log.error("Failed to identify host gen type. Please make sure servicenow is" \
                           " updated or manually deploy via the CLI")
            sys.exit(255)

        try:
            if check_mac(arg_value=snow['mac_address']):
                ret.mac = snow['mac_address']
                self.log.info("Found the follwoing mac from SNOW: %s", ret.mac)
                mac = re.sub(r"(\:|\.|\-|\ )", '', snow['mac_address'])
                mac_int = int(mac, 16) + 1
                mac_hex = "{:012x}".format(mac_int)
                ret.mac2 = ":".join(mac_hex[i:i+2] for i in range(0, len(mac_hex), 2))
                self.log.info("Found the follwoing mac2 from SNOW: %s", ret.mac2)
        except ArgumentTypeError as err:
            sys.exit(255)


        return ret

    def do_reboot(self, type, opts):
        self.log.info("Attempting to set next boot and reboot system Type: %s", type)
        if type == "HPE":
            ilo = hpilo.Ilo(opts.ilo_ip, login=opts.ilo_user, password=opts.ilo_pass, ssl_verify=False)
            self.log.info("[OOB] Setting set_one_time_boot(device=network) for host %s on ilo: %s", \
                          opts.host, opts.ilo_ip)
            ilo.set_one_time_boot(device="network")
            self.log.info("[OOB] Restarting the server (%s) on ilo: %s", opts.host, opts.ilo_ip)
            ilo.reset_server()
        else:
            obm = command.Command(bmc=opts.ilo_ip, userid="ttnet", password="18273645")
            self.log.info("[OOB] Setting bootdev=pxe for host %s on ilo: %s", opts.host, opts.ilo_ip)
            obm.set_bootdev(bootdev='network')
            self.log.info("[OOB] Restarting the server (%s) on ilo: %s", opts.host, opts.ilo_ip)
            obm.set_power(powerstate="boot")
