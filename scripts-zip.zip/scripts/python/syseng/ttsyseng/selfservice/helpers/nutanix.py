"""nutanix.py

Classes and functions for interacting with the Nutanix
"""
import logging
import time
import urllib3
import json
from base64 import b64encode

import requests

from ttsyseng.selfservice.helpers.conf_data import NTNX


urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

log = logging.getLogger(__name__)


class Nutanix(object):
    def __init__(self, host, username, password):
        self.host = host
        self.host_ip = NTNX[host]['ipaddress']
        if not username.endswith('@int.tt.local'):
            username += '@int.tt.local'
        self.username = username
        self.password = password
        self.uri_v2 = 'https://{}:9440/api/nutanix/v2.0/'.format(self.host_ip)
        self.uri_v3 = 'https://{}:9440/api/nutanix/v3/'.format(self.host_ip)
        self.session = self._session()

    def __repr__(self):
        return "<Nutanix host:{} ipaddress:{}>".format(self.host, self.host_ip)

    def _session(self):
        session = requests.Session()
        encoded_credentials = b64encode(
            bytes('{}:{}'.format(self.username, self.password),
            encoding='ascii')).decode('ascii')
        session.verify = False
        session.headers.update({
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Authorization': 'Basic {}'.format(encoded_credentials),
            'cache-control': 'no-cache'
        })
        return session

    def get_vm(self, vm_uuid):
        response = self.session.get(
            self.uri_v3 + 'vms/' + vm_uuid
        )
        response.raise_for_status()
        return response.json()

    def update_vm(self, vm_uuid, vm_spec):
        response = self.session.put(
            self.uri_v3 + 'vms/' + vm_uuid,
            data=json.dumps(vm_spec)
        )
        response.raise_for_status()
        return response.json()

    def get_vm_by_name(self, vm_name):
        response = self.session.post(
            self.uri_v3 + 'vms/list',
            data=json.dumps({
                "kind": "vm",
                "filter": "vm_name=={}".format(vm_name)
            })
        )
        response.raise_for_status()
        vms = response.json()
        this_vm = None
        for vm in vms['entities']:
            if vm['spec']['name'] == vm_name:
                this_vm = vm
                break
        return this_vm

    def get_network_by_vlan_id(self, vlan_id):
        # api v3 subnets for some reason does not list
        # all of the available networks/subnets
        # so we need to use the v2 api
        response = self.session.get(
            self.uri_v2 + 'networks'
        )
        response.raise_for_status()
        networks = response.json()

        this_network = None
        for network in networks['entities']:
            log.debug(network)
            if network['vlan_id'] == vlan_id:
                this_network = network
                break
        return this_network

    def get_subnet_by_vlan_id(self, vlan_id):
        response = self.session.post(
            self.uri_v3 + 'subnets/list',
            data=json.dumps({
                "kind": "subnet"
            })
        )
        response.raise_for_status()
        subnets = response.json()
        this_subnet = None
        for subnet in subnets['entities']:
            log.debug(subnet)
            if subnet['spec']['resources']['vlan_id'] == vlan_id:
                this_subnet = subnet
                break
        return this_subnet

    def add_vlan_nic(self, vm_uuid, vlan_id):  #subnet_uuid):
        vm = self.get_vm(vm_uuid)
        network = self.get_network_by_vlan_id(vlan_id)
        if not network:
            err = ("VLAN {} is not configured on this "
                   "Nutanix cluster".format(vlan_id))
            log.error(err)
            raise Exception('Failed to add nic. Error: {}'.format(err))

        for nic in vm['status']['resources']['nic_list']:
            nic_subnet_uuid = nic['subnet_reference']['uuid']
            if nic_subnet_uuid == network['uuid']:
                log.info('A nic already exists for vlan {}'.format(vlan_id))
                return vm

        # keep the metadata (required when updating a vm)
        # keep the spec, this is the expected state
        # delete the status, this represents the current state
        vm_spec = vm.copy()
        del vm_spec['status']

        new_nic_spec = {
            "nic_type": "NORMAL_NIC",
            "is_connected": True,
            "subnet_reference": {
                "kind": "subnet",
                "uuid": network['uuid']
            }
        }

        # append spec for the new nic
        vm_spec['spec']['resources']['nic_list'].append(new_nic_spec)
        log.debug(vm_spec)

        success = False
        result = self.update_vm(vm_uuid, vm_spec)
        try:
            task_uuid = result['status']['execution_context']['task_uuid']
            success = self._wait_for_task(task_uuid)
        except Exception as exc:
            log.error('The add_nic task failed! {}'.format(exc))

        if success:
            return self.get_vm(vm_uuid)
        else:
            raise Exception('Failed to add nic')

    def remove_vlan_nic(self, vm_uuid, vlan_id):
        vm = self.get_vm(vm_uuid)
        network = self.get_network_by_vlan_id(vlan_id)

        nic_to_remove = None
        nic_list = vm['status']['resources']['nic_list']
        for i in range(len(nic_list)):
            nic_subnet_uuid = nic_list[i]['subnet_reference']['uuid']
            if nic_subnet_uuid == network['uuid']:
                log.info('Removing vlan nic {}'.format(nic_list[i]))
                nic_to_remove = i
                break
        else:
            log.info('A nic does not exist for vlan {}'.format(vlan_id))
            return True

        # append spec for the new nic
        vm_spec = vm.copy()

        # keep the metadata (required when updating a vm)
        # keep the spec, this is the expected state
        # delete the status, this represents the current state
        del vm_spec['status']

        del vm_spec['spec']['resources']['nic_list'][nic_to_remove]
        log.debug(vm_spec)

        network = self.get_network_by_vlan_id(vlan_id)
        result = self.update_vm(vm_uuid, vm_spec)

        success = False
        try:
            task_uuid = result['status']['execution_context']['task_uuid']
            success = self._wait_for_task(task_uuid)
        except Exception as exc:
            log.error('The remove_nic task failed! {}'.format(exc))

        if success:
            return self.get_vm(vm_uuid)
        else:
            raise Exception('Failed to remove nic')

    def _wait_for_task(self, task_uuid):
        task = self._get_task(task_uuid)
        while task['status'] not in ('SUCCEEDED', 'FAILED'):
            task = self._get_task(task_uuid)
            log.info(task['progress_message'])
            time.sleep(1)

        if task and task['status'] == 'FAILED':
            log.error(task['error_detail'])
            return False

        return True

    def _get_task(self, task_uuid):
        response = self.session.get(
            self.uri_v3 + 'tasks/' + task_uuid
        )
        response.raise_for_status()
        return response.json()


def nutanix_host_by_vm(vm_name, username, password):
    """
    Function: nutanix_host_by_vm
    Summary: Return the Nutanix class object and vm dict for the
             Prism host the VM is a member of
    Examples:
    Attributes:
        @param (vm_name): host or node name of the VM
    Returns: nutanix object and vm dictionary
    """
    nutanix = None
    vm = {}
    for host in NTNX:
        try:
            nutanix = Nutanix(host, username, password)
            vm = nutanix.get_vm_by_name(vm_name)
        except Exception as exc:
            log.warning("Failed to connect to Nutanix host {}. {}".format(
                host, exc))
            continue
        if vm:
            break
    if not vm:
        raise Exception("VM {} could not be found on any "
                        "Nutanix host".format(vm_name))
    return (nutanix, vm)
