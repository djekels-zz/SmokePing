import time
import datetime
import sys
import os
import logging
import coloredlogs
import paramiko
import pkg_resources
from paramiko import SSHClient
import subprocess

LOG = logging.getLogger(__name__)

def startup(app):
    """
    Function: startup
    Summary: Display ASCII Art
    Examples: startup()
    Returns: ASCII Art Strings
    """

    now = datetime.datetime.now()
    version = pkg_resources.require("ttsyseng")[0].version

    if sys.stdin.isatty():
        print("""
\t\t                      \033[96m.,,,\033[0m
\t\t                    \033[96m.,,,,,,,\033[0m
\t\t                  \033[96m,,,,,,,\033[0m   \033[01;34m ((\033[0m
\t\t                 \033[96m,,,,,,,\033[0m   \033[01;34m(((((\033[0m
\t\t               \033[96m,,,,,,,\033[0m   \033[01;34m/((((((((\033[0m
\t\t             \033[96m,,,,,,,\033[0m   \033[01;34m/((((((((((((\033[0m
\t\t           \033[96m,,,,,,,\033[0m   \033[01;34m*((((((((((((((((\033[0m
\t\t         \033[96m,,,,,,,\033[0m    \033[01;34m((((((((((((((((((((\033[0m
\t\t       \033[96m,,,,,,,\033[0m   \033[00;34m,(   \033[01;34m((((((((((((((((((((\033[0m
\t\t     \033[96m,,,,,,,\033[0m   \033[00;34m.(((((   \033[01;34m((((((((((((((((((((\033[0m
\t\t   \033[96m,,,,,,,\033[0m   \033[00;34m.((((((((\\   \033[01;34m((((((((((((((((((((\033[0m
\t\t     \033[96m,,,\033[0m    \033[00;34m(((((((((((((\\   \033[01;34m((((((((((((((((\033[0m
\t\t          \033[00;34m((((((((  (((((((*   \033[01;34m((((((((((((\033[0m
\t\t         \033[00;34m((((((      (((((((*   \033[01;34m((((((((\033[0m
\t\t          \033[00;34m(((   \033[00;30m/%%%   \033[00;34m(((((((,   \033[01;34m((((\033[0m
\t\t              \033[00;30m*%%%%%%%   \033[00;34m((((((((.\033[0m
\t\t              \033[00;30m.%%%%%%%%%   \033[00;34m((((((((\033[0m
\t\t               \033[00;30m,%%%%%%%%%   \033[00;34m(((((\033[0m
\t\t                \033[00;30m,%%%%%%%%%\033[0m
\t\t                 \033[00;30m`*%%%%%%%\033[0m
\t\t                    \033[00;30m/%%%%                       \033[0m""")
        print("\n\t\t\t    \033[01;34mTrading Technologies, Inc.\033[0m\n\n")
        print("Welcome to \033[1;34m%s (v. %s)\t\t\t  \033[1;32m%s\033[0m" \
              % (app, version, now.isoformat()))
        print("\033[1;32m-------------------------------------------------------------------" \
          "-----------------\033[0m")
    else:
        print("Welcome to %s (v. %s)\t\t\t  %s" \
              % (app, version, now.isoformat()))
        print("-------------------------------------------------------------------" \
          "-----------------")

def init_log():
    """init_log

    Setup the logger functions for later use...

    Returns:
        logger (object) -- Logger object for use elsewhere...
    """
    if sys.stdin.isatty():
        coloredlogs.install()

    logpath = '/var/log/debesys/syseng-audit.log'
    logdir = os.path.dirname(logpath)
    try:
        if not os.path.isdir(logdir):
            os.mkdir(logdir)
    except OSError as err:
        print("Failed to create %s (%s)" % logdir, err)

    logger = logging.getLogger(__name__)
    return logger


def bytes_to_size(num, unit):
    for fmt in ['Ki', 'Mi', 'Gi', 'Ti', 'Pi', 'Ei', 'Zi']:
        num /= 1024
        if unit in fmt:
            return num

def ssh_alive_check(ipa, attempts=200):
    LOG.info("Testing SSH connection to host (%s)", ipa)
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    count = 0

    while count < attempts:
        try:
            ssh.connect(
                ipa,
                port=22,
                timeout=10,
                username='root',
                password='Tt12345678',
                allow_agent=False,
                look_for_keys=False)
            LOG.info("SSH CHECK SUCCESSFUL!")
            ssh.close()
            return True
        except:
            LOG.info("SSH ATTEMPT #%s FAILED. STILL KICKSTARTING... TRYING AGAIN", count)
            time.sleep(10)
            count += 1
            ssh.close()

    raise Exception("ERROR: host DID NOT RESPOND TO SSH")
