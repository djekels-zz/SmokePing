"""esxi.py

Classes and functions for interacting with the ESXi Clusters

Presentation for Team

"""
import atexit
import logging
import re
import ssl
import sys
import subprocess
import time
from pprint import pprint
import uuid
import requests
import paramiko
from paramiko import SSHClient
from pyVmomi import vim
from pyVim.connect import SmartConnect, Disconnect
from ttsyseng.selfservice.helpers.conf_data import SETTINGS
from ttsyseng.selfservice.helpers.ttchef import TTChefAPI
from ttsyseng.selfservice.helpers.ttdns import TTDns
from ttsyseng.selfservice.helpers.jenkins import TTJenkins
from ttsyseng.selfservice.helpers.servicenow_api import \
    ServiceNowAPI, ServiceNowTableLock

# pylint: disable=R0904
class ttESXi(object):
    """ttESXi()

    Custom class for functions to interact with our ESXi Clusters.
    """

    def __init__(self, args):
        self.logger = logging.getLogger(__name__)
        self.args = args
        self.vrtm = lambda: None
        self.int = lambda: None
        self.int.pkg = lambda: None
        self.int.pxe = lambda: None
        self.int.ssh = lambda: None
        self.int.pd = lambda: None

        self.int.ttdns = TTDns()
        self.int.snow = ServiceNowAPI()

        self.int.pd.tries = 30
        self.int.pd.sleep = 10
        try:
            self.int.ssh.attempts = SETTINGS['ssh']['attempts']
        except NameError:
            self.int.ssh.attempts = 200
        try:
            self.int.ssh.wait = SETTINGS['ssh']['wait']
        except NameError:
            self.int.ssh.wait = 10
        self.int.pxe.headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
        # pylint: disable=W0212
        ssl._create_default_https_context = ssl._create_unverified_context
        self.int.vctr_api = SmartConnect(host=self.args.vmw.host,
                                         user=self.args.vmw.user,
                                         pwd=self.args.vmw.passwd,
                                         port=self.args.port)

    def __exit__(self, exception_type, exception_value, traceback):
        atexit.register(Disconnect, self.int.vctr_api)

    def get_object(self, vimtype, name):
        """
        Function: get_object
        Summary: pull object from pyVmomi API
        Examples:
        Attributes:
            @param (vimtype): type of object to find.
            @param (name): name of object to find
        Returns: any object found
        """
        mob = None
        container = self.int.vctr_api.content.viewManager.CreateContainerView(
            self.int.vctr_api.content.rootFolder, vimtype, True)

        for i in container.view:
            if i.name == name or name in i.name:
                mob = i
                break

        if mob is None:
            raise Exception("ERROR: Object not found %s" % name)

        return mob

    def get_datacenter(self, name):
        """
        Function: get_datacenter
        Summary: Get Datacenter from name
        Examples: InsertHere
        Attributes:
            @param (name): Name to search for
        Returns: Datacenter object for given name
        """
        return self.get_object([vim.Datacenter], name)

    def get_cluster(self, name):
        """
        Function: get_cluster
        Summary: Get Cluster from name
        Examples: InsertHere
        Attributes:
            @param (name): Name to search for
        Returns: Cluster object for given name
        """
        return self.get_object([vim.ClusterComputeResource], name)

    def get_datastore_cluster(self):
        """
        Function: get_cluster
        Summary: Get Cluster from name
        Examples: InsertHere
        Attributes:
            @param (name): Name to search for
        Returns: Cluster object for given name
        """
        content = self.int.vctr_api.RetrieveContent()
        obj_view = content.viewManager.CreateContainerView(content.rootFolder,
                                                           [vim.StoragePod],
                                                           True)
        ds_cluster_list = obj_view.view
        obj_view.Destroy()
        return ds_cluster_list

    def get_host(self, name):
        """
        Function: get_cluster
        Summary: Get Cluster from name
        Examples: InsertHere
        Attributes:
            @param (name): Name to search for
        Returns: Cluster object for given name
        """
        return self.get_object([vim.HostSystem], name)

    def get_vm_list(self, name):
        logger = logging.getLogger(__name__)
        ttc = TTChefAPI()
        cntt = self.int.vctr_api.RetrieveContent()
        data = {}
        for child in cntt.rootFolder.childEntity:
            if child.name == name:
                dtcntr = child
                data[dtcntr.name] = {}
                clusters = dtcntr.hostFolder.childEntity
                for cluster in clusters:
                    data[dtcntr.name][cluster.name] = {}
                    hosts = cluster.host
                    for host in hosts:
                        hostname = host.summary.config.name
                        data[dtcntr.name][cluster.name][hostname] = {}
                        vms = host.vm
                        for vm in vms:
                            vmname = vm.summary.config.name
                            data[dtcntr.name][cluster.name][hostname][vmname] = {}
                            try:
                                chef = ttc.grab_node(vmname)
                                data[dtcntr.name][cluster.name][hostname][vmname]['chef'] = True
                                pprint(chef)
                            except:
                                data[dtcntr.name][cluster.name][hostname][vmname]['chef'] = False
                                logger.error("Failed to retrieve node... %s", vmname)
                            summary = self.vmsummary(vm.summary, vm.guest)
                            data[dtcntr.name][cluster.name][hostname][vmname]['mem'] = summary['mem']
                            data[dtcntr.name][cluster.name][hostname][vmname]['diskGB'] = summary['diskGB']
                            data[dtcntr.name][cluster.name][hostname][vmname]['cpu'] = summary['cpu']
                            data[dtcntr.name][cluster.name][hostname][vmname]['net'] = summary['net']
                            data[dtcntr.name][cluster.name][hostname][vmname]['ostype'] = summary['ostype']
                            data[dtcntr.name][cluster.name][hostname][vmname]['state'] = summary['state']

        return data

    # pylint: disable=R0913
    def get_datastore(self, cluster, cluster_name, ratio, size, disktype):
        """
        Function: get_datastore
        Summary: Gather datastore to use for this new vm.
        Examples: InsertHere
        Attributes:
            @param (cluster): cluster object
            @param (cluster_name): Cluster name
            @param (ratio): VM Ratio
            @param (size): Size of disk we are creating
            @param (disktype): Type of disk (san|ssd|local)
        Returns: datastore object to use.
        """
        self.logger.info("Find Datastore for new VM")
        size = int(size)
        rtn = None
        self.logger.info("Found %s nodes in cluster: %s", len(cluster.host), cluster_name)
        for host in cluster.host:
            count = 0

            for vrtm in host.vm:
                if vrtm.runtime.powerState == "poweredOn":
                    count += 1

            self.logger.info("Found %s VMs on Host: %s", count, host.name)
            if count > ratio:
                continue

            for dtst in host.datastore:
                free_space = dtst.summary.freeSpace / 1073741824
                self.logger.info("%s Free space found on Datastore: %s", free_space, dtst.name)

                if "Infrastructure" in cluster_name:
                    self.logger.info("This is being built on a Infra Host...")
                    if (
                            "Infra" in dtst.name and
                            free_space > int(size)
                    ):
                        self.logger.info("Disk Size (%s) is bigger then freespace (%s)...", size, free_space)
                        rtn = dtst
                        break
                    elif (
                            disktype == "local" in dtst.name 
                            and free_space > size
                    ):
                        self.logger.info("Disk Size (%s) is bigger then freespace (%s)...", size, free_space)
                        rtn = dtst
                        break
                else:
                    self.logger.info("This is being built on a Prod Host with disktype: %s...", disktype)
                    if (
                            disktype == "ssd" and "SSD" in dtst.name 
                            and free_space > size
                    ):
                        self.logger.info("Disk Size (%s) is bigger then freespace (%s)...", size, free_space)
                        rtn = dtst
                        break
                    elif (
                            disktype == "san" and "3PAR" in dtst.name 
                            and free_space > size
                    ):
                        self.logger.info("Disk Size (%s) is bigger then freespace (%s)...", size, free_space)
                        rtn = dtst
                        break
        if rtn:
            return rtn
        else:
            msg = "Required host and datastore not found for %s" % disktype
            raise Exception(msg)

    # pylint: disable=R1710
    def get_mac(self, vrtm, network):
        """
        Function: get_mac
        Summary: Grab MAC from vcenter
        Examples: InsertHere
        Attributes:
            @param (vrtm):VM Object
            @param (network): Network Object
        Returns: Mac Address
        """
        net = self.get_object([vim.dvs.DistributedVirtualPortgroup], network)

        for dev in vrtm.config.hardware.device:
            if "Network adapter" in dev.deviceInfo.label:
                if dev.backing.port.portgroupKey == net.key:
                    return dev.macAddress

    def prep(self, args):
        """
        Function: prep
        Summary: Accpet Args dict and preprocess for use in create/delete vms
        Examples: prep(args)
        Attributes:
            @param (args): [dict] - Dictionary of args
        Returns: self
        """
        self.vrtm.site = "10.%s" % args.dctr.oct
        if args.name:
            self.vrtm.name = args.name
        else:
            lock = ServiceNowTableLock("u_cmdb_ci_debesys_ip")
            with lock:
                self.vrtm.mgmt_ip = self.int.snow.get_ip(self.vrtm.site, "vm")
                self.vrtm.name = args.datacenter.lower() + self.vrtm.mgmt_ip.split(".")[2] \
                                 + "vm" + self.vrtm.mgmt_ip.split(".")[3]

                # RESERVE IP IN SERVICE NOW
                self.int.snow.update_sn_ip_status(self.vrtm.mgmt_ip, self.vrtm.name, True)
        args.name = self.vrtm.name
        vsp = re.split('(\d+)', self.vrtm.name)
        self.vrtm.mgmt_ip = "%s.%s.%s" % (self.vrtm.site, vsp[1], vsp[3])
        self.vrtm.pxe_server = "%s.0.30" % (self.vrtm.site)

        return self

    def create_vm(self, args):
        """
        Function: create_vm
        Summary: Create VM
        Examples: InsertHere
        Attributes:
            @param (args): args objects for creating vm
        Returns: VM Object for newly created vm
        """
        if args.command == "create":
            self.prep(args)

            datacenter = self.get_datacenter(args.dctr.name)
            cluster = self.get_cluster(args.dctr.clstr_name)
            datastore = self.get_datastore(cluster, args.dctr.clstr_name, args.dctr.ratio, \
                                           args.disksize, args.disktype)

            try:
                # Create VM after specifying datastore and configuration
                logging.info("CREATING: %s on %s with %s GB DISK"\
                             " and %s CPUs and %s MEMORY", self.vrtm.name, datastore.name, \
                             args.disksize, args.cpu, args.memory)
                datastore_path = "[%s] %s" % (datastore.name, self.vrtm.name)
                vm_folder = datacenter.vmFolder
                vmx_file = vim.vm.FileInfo(logDirectory=None,
                                           snapshotDirectory=None,
                                           suspendDirectory=None,
                                           vmPathName=datastore_path)

                vm_config = vim.vm.ConfigSpec(name=self.vrtm.name, memoryMB=(int(args.memory) \
                                              * 1024), numCPUs=int(args.cpu), numCoresPerSocket = int(1), \
                                              files=vmx_file, guestId=args.dctr.osid, \
                                              memoryHotAddEnabled = True, cpuHotAddEnabled = True, \
                                              cpuHotRemoveEnabled = True, version=args.dctr.vm_ver)

                vm_task = vm_folder.CreateVM_Task(config=vm_config, pool=cluster.resourcePool)
                self.wait_for_task(vm_task)

                new_vm = self.get_object([vim.VirtualMachine], self.vrtm.name)

                self.add_controller(new_vm)
                self.add_disk(new_vm, args.disksize)

                for net in args.dctr.ntwks.items():
                    self.add_nic(new_vm, net[1])

                #self.set_boot_device(new_vm, networks[0])
            except Exception as exp:
                msg = "Failed to create VM. \n %s" % exp
                self.logger.error(msg)
                sys.exit(1)

            return new_vm

    def chef_bootstrap(self, args):
        """
        Function: chef_bootstrap
        Summary: Bootstrap Host.
        Examples: InsertHere
        Attributes:
            @param (self):InsertHere
            @param (args):InsertHere
        Returns: InsertHere
        """
        self.logger.info("Attempting to Bootstrap host...")
        if args.chef_env:
            chef_env = args.chef_env
        else:
            chef_env = "None"

        bootstrap_requester = 'syseng@tradingtechnologies.com'
        job = TTJenkins(SETTINGS['jenkins']['user'], SETTINGS['jenkins']['token'], \
                        verbose=False)
        result = job.launch_job(job="bootstrap",
                                params={'GUID': str(uuid.uuid4()),
                                        'chef_env': chef_env,
                                        'BOOTSTRAP_REQUESTER': bootstrap_requester,
                                        'servers': self.vrtm.name}, wait=False)
        if not result:
            self.logger.info("Successfully scheduled Bootstrap job!")
            #sys.exit(0)
        else:
            self.logger.error("Failed to Schedule bootstrap job...")
            #sys.exit(1)


    def reg_pxe(self, args):
        """
        Function: reg_ks
        Summary: Register Host with SiteServer for PXE
        Examples: InsertHere
        Attributes:
            @param (args): args Object
        Returns: InsertHere
        """
        try:
            self.prep(args)
            vrtm = self.get_object([vim.VirtualMachine], self.vrtm.name)
            macs = []
            for net in args.dctr.ntwks.items():
                macs.append(self.get_mac(vrtm, net[1]))
            
            payload = {
                "ip": self.vrtm.mgmt_ip,
                "os_ver": args.centos_version,
                "hst_gen": "None",
                "hst_type": "VM",
                "bootloader": "mbr",
                "root_pw": "Tt12345678",
                "vlan_base": args.dctr.bvlid
            }

            # dj, removed hard coded number of macs based on environments
            i = 1
            j = 0
            for mac in macs:
                if i != 1:
                    payload["mac" + str(i)] = macs[j]
                else:
                    payload["mac"] = macs[j]
                i += 1
                j += 1

            msg = "Checking if old host entry exists for: %s" % self.vrtm.name
            self.logger.info(msg)
            ssapi = "http://%s:8000/host/lookup/%s" % (self.vrtm.pxe_server, self.vrtm.name)
            response = requests.get(ssapi, headers=self.int.pxe.headers)
            if response.status_code == 200:
                #Cleaning Up Kickstart File and Kickstart Pointer File
                msg = "Found Old KS Registration for %s, Removing Old kickstart registration." \
                       % self.vrtm.name
                self.logger.info(msg)
                ssapi = "http://%s:8000/host/delete/%s" % (self.vrtm.pxe_server, self.vrtm.name)
                response = requests.delete(ssapi, headers=self.int.pxe.headers)

            self.logger.info("Attempting to register host with pxe host: %s", self.vrtm.pxe_server)
            ssapi = "http://%s:8000/host/add/%s" % (self.vrtm.pxe_server, self.vrtm.name)
            response = requests.post(ssapi, params=payload, headers=self.int.pxe.headers)
            if response.status_code == 200:
                json_response = response.json()
                msg = "Registered Host: %s (%s/%s)" % (json_response['hostname'], \
                      json_response['ip'], json_response['mac'])
                self.logger.info(msg)
            else:
                self.logger.error("***FAIL*** Failed to register with pxe service. " \
                                  "Please contact syseng for further assistance.")
                sys.exit(255)
            self.logger.info("Validating that host was infact created as we expect it to be...")
            ssapi = "http://%s:8000/host/lookup/%s" % (self.vrtm.pxe_server, self.vrtm.name)
            response = requests.get(ssapi, headers=self.int.pxe.headers)
            if response.status_code != 200:
                self.logger.error("***FAIL*** Failed to locate registration on pxe service. " \
                                  "Please contact syseng for further assistance.")
                sys.exit(255)
        except Exception as exp:
            msg = "Failed to register Host. \n%s" % exp
            self.logger.info(msg)

        vm_task = vrtm.PowerOn()
        self.wait_for_task(vm_task)

        self.logger.info("WAITING FOR VM TO PXE BOOT AND BEGIN KICKSTARTING")
        time.sleep(60)

        self.ssh_alive_check()
        self.host_ready_bootstrap()

        #Cleaning Up Kickstart File and Kickstart Pointer File
        msg = "Kickstart completed for host %s, Removing Old kickstart registration." \
              % self.vrtm.name
        self.logger.info(msg)
        ssapi = "http://%s:8000/host/delete/%s" % (self.vrtm.pxe_server, self.vrtm.name)
        response = requests.delete(ssapi, headers=self.int.pxe.headers)

        if args.bootstrap:
            msg = "The Host %s is ready for being bootstraped into chef %s." % (self.vrtm.name, args.chef_env)
            self.logger.info(msg)
            self.chef_bootstrap(args)
         
        #dj - we need to clear these variables to ensure we can build 100's in one job
        args.name = None
        self.vrtm.name = None
            
    def add_controller(self, vrtm):
        """
        Function: add_controller
        Summary: Add disk controller to vm.
        Examples: InsertHere
        Attributes:
            @param (vm): vm object
        """
        task = vrtm.ReconfigVM_Task(
            spec=vim.vm.ConfigSpec(
                deviceChange=[
                    vim.vm.device.VirtualDeviceSpec(
                        operation=vim.vm.device.VirtualDeviceSpec.Operation.add,
                        device=vim.vm.device.VirtualLsiLogicSASController(
                            sharedBus=vim.vm.device.VirtualSCSIController.Sharing.noSharing
                        ),
                    )
                ]
            )
        )
        self.wait_for_task(task)

    def add_disk(self, vrtm, disk_size):
        """
        Function: add_disk
        Summary: Add Disk to VM
        Examples: InsertHere
        Attributes:
            @param (vm): VM Object
            @param (disk_size): Size of disk to create.
        """
        spec = vim.vm.ConfigSpec()
        # get all disks on a VM, set unit_number to the next available
        unit_number = 0
        for dev in vrtm.config.hardware.device:
            if hasattr(dev.backing, 'fileName'):
                unit_number = int(dev.unitNumber) + 1
                # unit_number 7 reserved for scsi controller
                if unit_number == 7:
                    unit_number += 1
                if unit_number >= 16:
                    self.logger.info("we don't support this many disks")
                    return
            if isinstance(dev, vim.vm.device.VirtualSCSIController):
                controller = dev
        # add disk here
        dev_changes = []
        new_disk_kb = int(disk_size) * 1024 * 1024
        disk_spec = vim.vm.device.VirtualDeviceSpec()
        disk_spec.fileOperation = "create"
        disk_spec.operation = vim.vm.device.VirtualDeviceSpec.Operation.add
        disk_spec.device = vim.vm.device.VirtualDisk()
        disk_spec.device.backing = \
            vim.vm.device.VirtualDisk.FlatVer2BackingInfo()
        # if disk_type == 'thin':
        #    disk_spec.device.backing.thinProvisioned = True
        disk_spec.device.backing.diskMode = 'persistent'
        disk_spec.device.unitNumber = unit_number
        disk_spec.device.capacityInKB = new_disk_kb
        disk_spec.device.controllerKey = controller.key
        dev_changes.append(disk_spec)
        spec.deviceChange = dev_changes

        task = vrtm.ReconfigVM_Task(spec=spec)
        self.wait_for_task(task)

        self.logger.info("%sGB disk added to %s", disk_size, vrtm.config.name)

    def add_nic(self, vrtm, network):
        """
        Function: add_nic
        Summary: Add NIC to VM
        Examples: InsertHere
        Attributes:
            @param (vrtm): VM Object
            @param (network): Network to Create
        Returns: InsertHere
        """
        self.logger.info("add_nic starting")
        portgroup = self.get_object([vim.dvs.DistributedVirtualPortgroup], network)
        dvs = portgroup.config.distributedVirtualSwitch
        port_key = self.search_port(dvs, portgroup.key)
        port = self.find_port(dvs, port_key)
        spec = vim.vm.ConfigSpec()

        nic_changes = []
        nic_spec = vim.vm.device.VirtualDeviceSpec()
        nic_spec.operation = vim.vm.device.VirtualDeviceSpec.Operation.add

        nic_spec.device = vim.vm.device.VirtualVmxnet3()
        nic_spec.device.deviceInfo = vim.Description()
        nic_spec.device.deviceInfo.summary = 'tt_vsphere_api_add_nic'

        nic_spec.device.backing = \
            vim.vm.device.VirtualEthernetCard.DistributedVirtualPortBackingInfo()
        nic_spec.device.backing.port = vim.dvs.PortConnection()
        nic_spec.device.backing.port.portgroupKey = port.portgroupKey
        nic_spec.device.backing.port.switchUuid = port.dvsUuid
        nic_spec.device.backing.port.portKey = port.key

        nic_spec.device.connectable = vim.vm.device.VirtualDevice.ConnectInfo()
        nic_spec.device.connectable.startConnected = True
        nic_spec.device.connectable.allowGuestControl = True
        nic_spec.device.connectable.connected = True
        nic_spec.device.connectable.status = 'untried'

        nic_spec.device.wakeOnLanEnabled = True
        nic_spec.device.addressType = 'assigned'

        nic_changes.append(nic_spec)
        spec.deviceChange = nic_changes

        task = vrtm.ReconfigVM_Task(spec=spec)
        self.wait_for_task(task)

        self.logger.info("%s NIC ADDED", network)

    def get_nic_device_by_mac(self, vrtm, macaddr):
        nic_device = None
        for dev in vrtm.config.hardware.device:
            if is_nic(dev) and dev.macAddress == macaddr:
                self.logger.info("NIC device label %s with mac %s",
                                 dev.deviceInfo.label, dev.macAddress)
                nic_device = dev
                break
        return nic_device

    def remove_nic(self, vrtm, device):
        """
        Function: remove_nic
        Summary: Remove NIC from VM
        Examples: InsertHere
        Attributes:
            @param (vrtm): VM Object
            @param (device): Network Device to delete
        Returns: InsertHere
        """
        self.logger.info("remove_nic starting")

        label = device.deviceInfo.label

        if not is_nic(device):
            raise AssertionError("Device {} is not a NIC device!".format(label))

        nic_spec = vim.vm.device.VirtualDeviceSpec()
        nic_spec.operation = vim.vm.device.VirtualDeviceSpec.Operation.remove
        nic_spec.device = device

        config_spec = vim.vm.ConfigSpec(deviceChange=[nic_spec])
        task = vrtm.ReconfigVM_Task(spec=config_spec)
        self.wait_for_task(task)

        self.logger.info("%s NIC REMOVED", label)

    def check_poweroff(self):

        count = 0

        while count < self.int.pd.tries:
            try:
                # Locate VM object from vcenter
                vrtm = self.get_object([vim.VirtualMachine], self.vrtm.name)

                # Validate the VM is off before we start powering it down...
                if vrtm.runtime.powerState == "poweredOn":
                    msg = "[ESXi] - The VM provided (%s) is still powered on. Please " \
                          "make sure the VM has been powered down before " \
                          "running this job... Attempt # %s" % \
                          (self.vrtm.name, count)
                    raise RuntimeError(msg)

                return vrtm
            except RuntimeError as exp:
                self.logger.error(exp)
                time.sleep(self.int.pd.sleep)
                count += 1

        raise RuntimeError("We Tried %s Times but VM (%s) is still not "
                           "powered down... " % (count, self.vrtm.name))

    def delete_vm(self, args):
        """
        Function: delete_vm
        Summary: Remove VM from ESXi Cluster
        Examples: InsertHere
        Attributes:
            @param (args):InsertHere
        Returns: InsertHere
        """
        if args.command == "delete":
            self.prep(args)

            hstsplt = re.search(r'((?:m\-|m)[a-zA-Z]{2,3}|(?:sqe\-|sqe)[a-zA-Z]{2,3}|[a-zA-Z]{2,3})([0-9]{1})([a-zA-Z]{2,5})([0-9]{1,3})', self.vrtm.name)

            try:

                if args.datacenter.lower() != hstsplt[1].lower():
                    msg = "Datacenter provided (%s) does not match the " \
                          "hostname (%s)" % (args.datacenter, hstsplt[1])
                    raise RuntimeError(msg)

                if args.prod and re.match(r'((?:m\-|m)[a-z]{2}|(?:sqe\-|sqe)'
                                          '[a-z]{2}).*', self.vrtm.name):
                    msg = "ENV missmatch. Prod env provided but hostname is" \
                          " %s." % hstsplt[1]
                    raise RuntimeError(msg)

                if args.mock and not re.match(r'((?:m\-|m)[a-z]{2}|(?:sqe\-|'
                                              'sqe)[a-z]{2}).*',
                                              self.vrtm.name):
                    msg = "ENV missmatch. Mock env provided but hostname is" \
                          " %s." % hstsplt[1]
                    raise RuntimeError(msg)

                vrtm = self.check_poweroff()

                self.int.snow.update_sn_ip_status(self.vrtm.mgmt_ip,
                                                  self.vrtm.name, False)
                self.logger.info("[ESXi] - Deleting vm %s", self.vrtm.name)

                self.logger.info("[ESXi] - Attempting to destroy vm...")
                task = vrtm.Destroy_Task()
                self.wait_for_task(task)

                self.logger.info("[ESXi] - Successfully deleted %s!",
                                 self.vrtm.name)
                sys.exit(0)

            except RuntimeError as exp:
                self.logger.error(exp)
                sys.exit(1)
            except Exception as exp:
                self.logger.error("Deleting this VM has failed. Contact "
                                  "Systems Engineering to clean up vm in"
                                  " vSphere. Exception %s", exp)
                sys.exit(1)

    def ssh_alive_check(self):
        """
        Function: ssh_alive_check
        Summary: Check if host has complete its kickstart/pxe process.
        Examples: ssh_alive_check()
        Returns: (True|False)
        """
        self.logger.info("Checking if host %s (%s) is alive!", self.vrtm.name, self.vrtm.mgmt_ip)
        ssh = SSHClient()
        ssh.load_system_host_keys()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        count = 0

        while count < self.int.ssh.attempts:
            try:
                ping = self.ping(self.vrtm.mgmt_ip)
                if ping == 0:
                    msg = "Host %s (%s) is online. Attempting to ssh to host." \
                           % (self.vrtm.name, self.vrtm.mgmt_ip)
                    self.logger.info(msg)
                    ssh.connect(self.vrtm.mgmt_ip, username='root', timeout=8,
                                password='Tt12345678', allow_agent=False, look_for_keys=False)
                    self.logger.info("SSH CHECK SUCCESSFUL!")
                    ssh.close()
                    return
                else:
                    self.logger.info("Host is not up (ping failed). Could  not test SSH yet...")
                    self.logger.info("Attempt: #%s", count)
                    time.sleep(self.int.ssh.wait)
                    count += 1
                    ssh.close()
            except Exception:
                self.logger.info("SSH ATTEMPT #%s FAILED. STILL KICKSTARTING... " \
                                 "TRYING AGAIN", count)
                time.sleep(self.int.ssh.wait)
                count += 1
                ssh.close()

        raise Exception("ERROR: VM DID NOT RESPOND TO SSH")

    def host_ready_bootstrap(self):
        """
        Function: host_ready_bootstrap
        Summary: Check if host has rebooted twice after imaging
        Examples: host_ready_bootstrap()
        Returns: (True|False)
        """
        self.logger.info("Checking if host %s is ready for bootstrap", self.vrtm.mgmt_ip)
        ssh = SSHClient()
        ssh.load_system_host_keys()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        count = 0
        dobootstrap = 0

        while count <= 5:
            try:
                 count += 1
                 msg = "Host %s (%s) is online. Attempting to verify reboot status." \
                        % (self.vrtm.name, self.vrtm.mgmt_ip)
                 self.logger.info(msg)
                 ssh.connect(self.vrtm.mgmt_ip, username='root', timeout=8,
                             password='Tt12345678', allow_agent=False, look_for_keys=False)
                 self.logger.info("SSH LOGIN SUCCESSFUL, Checking for finger print, %s" % count)
                 stdin, stdout, stderr = ssh.exec_command("[ ! -f /tmp/firstboot.sh ] && echo -ne \"Success\"")
                 firstboot = stdout.read()

                 if firstboot == "b'Success'":
                      msg = "We are inside a success on count of %s", dobootstrap
                      self.logger.info(msg)
                      dobootstrap += 1
                      break
                 else:
                      msg = "We are inside a failure on count of %s and firtsboot %s" % (dobootstrap, firstboot)
                      self.logger.info(msg)
                      dobootstrap += 1
                      break

                 msg = "Chilling while waiting for this host to boot"
                 self.logger.info(msg)

                 time.sleep(4)

            except Exception:
                self.logger.info("Verifying if host has rebooted #%s FAILED s failed trying again", count)
                time.sleep(self.int.ssh.wait)
                ssh.close()
                count += 1

        return dobootstrap


    ### Static Methods for use in the class
    @staticmethod
    def find_port(dvs, key):
        """
        Function: find_port
        Summary: Find port in given DVS
        Examples: InsertHere
        Attributes:
            @param (dvs):DVS Object
            @param (key): Key
        Returns: Port to use
        """
        obj = None
        try:
            ports = dvs.FetchDVPorts()
            for i in ports:
                if i.key == key:
                    obj = i
        except IndexError:
            raise Exception("ERROR: NO PORTS FOUND FOR DVS")

        if obj is not None:
            return obj
        else:
            raise Exception("ERROR: NO PORTS FOUND FOR DVS")

    @staticmethod
    def search_port(dvs, portgroupkey):
        """
        Function: search_port
        Summary: Locate DVS To Use
        Examples: InsertHere
        Attributes:
            @param (dvs):Distributed VSwitch Object
            @param (portgroupkey): Port Group Key to search for.
        Returns: DVS to use
        """
        search_portkey = []
        criteria = vim.dvs.PortCriteria()
        criteria.connected = False
        criteria.inside = True
        criteria.portgroupKey = portgroupkey
        ports = dvs.FetchDVPorts(criteria)

        for port in ports:
            search_portkey.append(port.key)

        return search_portkey[0]

    @staticmethod
    def wait_for_task(task):
        """
        Function: wait_for_task
        Summary: Wait for task to complete
        Examples: InsertHere
        Attributes:
            @param (task): task to wait for
        Returns: InsertHere
        """
        count = 0
        while task.info.state != "success" or task.info.state == "error":
            time.sleep(1)
            count += 1
            if count > 120:
                break

        if task.info.state != "success":
            raise Exception("ERROR: VM Task took too long or did not complete successfully: %s" \
                            % task.info.state)
    @staticmethod
    def ping(host):
        """
        Returns True if host responds to a ping request
        """

        # Ping parameters as function of OS
        status,result = subprocess.getstatusoutput("ping -c1 " + str(host))
        return status

    @staticmethod
    def getNICs(summary, guest):
        nics = {}
        for nic in guest.net:
            if nic.network:  # Only return adapter backed interfaces
                if nic.ipConfig is not None and nic.ipConfig.ipAddress is not None:
                    nics[nic.macAddress] = {}  # Use mac as uniq ID for nic
                    nics[nic.macAddress]['netlabel'] = nic.network
                    ipconf = nic.ipConfig.ipAddress
                    i = 0
                    nics[nic.macAddress]['ipv4'] = {}
                    for ip in ipconf:
                        if ":" not in ip.ipAddress:  # Only grab ipv4 addresses
                            nics[nic.macAddress]['ipv4'][i] = ip.ipAddress
                            nics[nic.macAddress]['prefix'] = ip.prefixLength
                            nics[nic.macAddress]['connected'] = nic.connected
                    i = i+1
        return nics


    def vmsummary(self, summary, guest):
        vmsum = {}
        config = summary.config
        net = self.getNICs(summary, guest)
        vmsum['mem'] = str(config.memorySizeMB / 1024)
        vmsum['diskGB'] = str("%.2f" % (summary.storage.committed / 1024**3))
        vmsum['cpu'] = str(config.numCpu)
        vmsum['path'] = config.vmPathName
        vmsum['ostype'] = config.guestFullName
        vmsum['state'] = summary.runtime.powerState
        vmsum['annotation'] = config.annotation if config.annotation else ''
        vmsum['net'] = net

        return vmsum


    @staticmethod
    def vm2dict(data, dc, cluster, host, vm, summary):
        # If nested folder path is required, split into a separate function
        vmname = vm.summary.config.name
        data[dc][cluster][host][vmname]['folder'] = vm.parent.name
        data[dc][cluster][host][vmname]['mem'] = summary['mem']
        data[dc][cluster][host][vmname]['diskGB'] = summary['diskGB']
        data[dc][cluster][host][vmname]['cpu'] = summary['cpu']
        data[dc][cluster][host][vmname]['path'] = summary['path']
        data[dc][cluster][host][vmname]['net'] = summary['net']
        data[dc][cluster][host][vmname]['ostype'] = summary['ostype']
        data[dc][cluster][host][vmname]['state'] = summary['state']
        data[dc][cluster][host][vmname]['annotation'] = summary['annotation']
        return data


def is_nic(device):
    return isinstance(device, vim.vm.device.VirtualEthernetCard)
