#!/usr/bin/env python3
"""chef.py
Classes and Functions used with the interaction of Chef.
"""
import logging
from chef import autoconfigure, Search, Node
from pprint import pprint

class TTChefAPI(object):
    """TTChefAPI
    Primary Class for functions interacting with chef.
    """

    def __init__(self):

        ### Chef API Setup
        self.capi = autoconfigure()
        self.log = logging.getLogger(__name__)


    def grab_servers(self, query):
        """grab_servers
        Get a list of Site Servers from Chef
        Returns:
            [array] -- Array of servers as returned by chef.
                       Including all data associated with that server.
        """
        self.log.info("Getting list of nodes from chef based on query '%s'", query)
        servers = Search('node', query)
        return servers

    def get_vms(self, query):
        """grab_servers
        Get a list of Site Servers from Chef
        Returns:
            [array] -- Array of servers as returned by chef.
                       Including all data associated with that server.
        """
        self.log.info("Getting list of vm nodes from chef based on query '%s'", query)
        vms = Search('node', query)
        ret = {}
        for vmn in vms:
            ret[vmn['name']] = ""
        return ret

    def grab_server(self, name):
        self.log.info("Requesting details from chef on server: %s", name)
        query = "node_name:%s and run_list:*site_server*" % name
        server = Search('node', query)
        return server

    def grab_node(self, name):
        self.log.info("Requesting details from chef on Node: %s", name)
        server = Node(name)
        return server
