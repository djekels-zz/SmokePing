import argparse
import datetime
import coloredlogs
import logging
import sys
import os
import re
import pysnow
import pkg_resources
from pprint import pprint
from signal import signal, SIGINT
from ttsyseng.selfservice.helpers.conf_data import SETTINGS,DCS,NTNX
from ttsyseng.selfservice.helpers.servicenow_api import ServiceNowAPI, ServiceNowTableLock
from ttsyseng.selfservice.helpers.ttchef import TTChefAPI
from ttsyseng.selfservice.helpers.ttdns import TTDns
from ttsyseng.selfservice.helpers.ttntnx import TTNtnx
from ttsyseng.selfservice.helpers.tools import startup,init_log

SNA = pysnow.Client(instance='tradingtech', user='svc-elsrw', password='P8pcqQdf')
SNA.parameters.display_value = True

def handler(signal_received, frame):
    log = logging.getLogger(__name__)
    # Handle any cleanup here
    log.info('SIGINT or CTRL-C detected. Exiting gracefully')
    exit(0)

def get_args():
    """
    Function: get_args
    Summary: parse argv and return dict() of flags and data passed in
    Examples: get_args()
    Returns: dict() of flags and data passed in.
    """
    version = "ttsyseng v: %s" % pkg_resources.require("ttsyseng")[0].version
    prsr = argparse.ArgumentParser(
        description='Nutanix VM Audit')
    sub = prsr.add_subparsers(title="commands", dest="command")


    prsr.add_argument("-v", "--version", action='version', version=version)
    prsr.add_argument("-d", "--debug", help="Debug/Verbose output",\
                        action='store_true', default=False)

    chef = sub.add_parser(name='chef', description='Audit live vms not in chef')
    chef.add_argument("-c", "--cluster", help="Which cluster to run this against.",\
                     action='store_true', default=False)

    args = prsr.parse_args()

    return args

def get_ntnx():
    ntx = TTNtnx()

    ntnx = {}
    for key, val in NTNX.items():
        ntnx[key] = {}
        ntnx[key].update(ntx.get_vms(cluster=key))

    return ntnx

def get_chef(ttch, key):
    chf = {}
    query = "n:%s*vm*" % key
    chf.update(ttch.get_vms(query=query))
    return chf

def get_snow(key, val):
    log = logging.getLogger(__name__)
    snr = SNA.resource(api_path='/table/u_cmdb_ci_debesys_ip')

    snlist = {}
    log.info("Checking Datacenter Name: '%s'", val['name'])
    rng1 = "10.%s.1." % val['octet']
    rng2 = "10.%s.2." % val['octet']
    rng3 = "10.%s.3." % val['octet']
    query = (
        pysnow.QueryBuilder()
        .field('ip_address').starts_with(rng1)
        .OR()
        .field('ip_address').starts_with(rng2)
        .OR()
        .field('ip_address').starts_with(rng3)
        .AND()
        .field('u_active').equals("true")
    )
    sn_host_resp = snr.get(query=query).all()
    for sn_host in sn_host_resp:
        if sn_host['u_hostname'] != "DHCP" and sn_host['u_hostname'] != "HA PROXY" and sn_host['u_hostname'] != "HA Proxy" and sn_host['u_hostname'] != "BROADCAST_ADDRESS":
            ret = {}
            ret[sn_host['u_hostname']] = ""
            snlist.update(ret) 
    return snlist

def main():    
    log = init_log()
    args = get_args()
    ttch = TTChefAPI()

    dns = TTDns()
    snr = SNA.resource(api_path='/table/u_cmdb_ci_debesys_ip')

    signal(SIGINT, handler)

    startup(app="TTSysEng - Nutanix Audit")
    log.info("Starting up nutanix_audit app...")

    ntnx = get_ntnx()

    chf = {}
    snlist = {}
    for key, val in DCS['Glados'].items():
        chf.update(get_chef(ttch, key))
        snlist.update(get_snow(key=key, val=val))    

    log.info("Found %s vms in SNOW for Glados...", len(snlist))

    for key, val in DCS['SQE'].items():
        chf.update(get_chef(ttch, key))
        snlist.update(get_snow(key=key, val=val))    

    ntct = 0
    for k, v in ntnx.items():
        ntct = ntct + len(ntnx[k])

    log.info("Found: %s in Nutanix, %s in Chef, %s in SNOW...", ntct, len(chf), len(snlist))

    for key, val in ntnx.items():
        for ntxkey, ntxval in val.items():
            if ntxkey not in chf:
                log.error("Found VM: %s in Nutanix but not in Chef...", ntxkey)

            splt = re.search(r'((?:m\-|m)[a-zA-Z]{2,3}|(?:sqe\-|sqe)[a-zA-Z]{2,3}|[a-zA-Z]{2,3})([0-9]{1,3})([a-zA-Z]{2,5})([0-9]{1,3})', ntxkey)
            if splt:
                host_dns = dns.get_dc(splt[1])
                ip = "10.%s.%s.%s" % (host_dns['dc_octet'], splt[2], splt[4])
                query = (
                    pysnow.QueryBuilder()
                    .field('ip_address').equals(ip)
                )
                sn_host_resp = snr.get(query=query).all()
                if len(sn_host_resp) == 0:
                    log.error("Failed to locate IP entry for %s", ip)
                elif len(sn_host_resp) > 1:
                    logger.error("Located more then one entry in SNOW... THIS IS BAD... %s (%s)", ntxkey, ip)
                else:
                    if sn_host_resp[0]['u_active'] != "true":
                        log.error("Found IP %s for host %s in SNOW but it is marked INACTIVE...", ip, ntxkey)
            else:
                log.error("Hostname (%s) does not follow standard naming convention... SKIPPING...", ntxkey)

    for key, val in snlist.items():
        if key not in chf:
            log.error("Found VM: %s is reserved in SNOW but not in Chef...", key)

        fnd = {}
        for k, v in ntnx.items():
            if key in ntnx[k]:
                fnd[k] = k
            else:
                pass
        if len(fnd) == 0:
            log.error("Found VM: %s is reserved in SNOW but not in Nutanix...", key)




if __name__ == '__main__':
    main()
    sys.exit(0)
