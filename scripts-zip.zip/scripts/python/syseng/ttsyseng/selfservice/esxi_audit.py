import argparse
import coloredlogs
import logging
import os
import sys
from pprint import pprint
from ttsyseng.selfservice.helpers.conf_data import SETTINGS,ESXI
from ttsyseng.selfservice.helpers.esxi import ttESXi
from ttsyseng.selfservice.helpers.servicenow_api import ServiceNowAPI, ServiceNowTableLock



def get_args():
    """
    Function: get_args
    Summary: parse argv and return dict() of flags and data passed in
    Examples: get_args()
    Returns: dict() of flags and data passed in.
    """
    logger = logging.getLogger(__name__)
    prsr = argparse.ArgumentParser(
        description='Creating VM in ESXi Cluster')
    sub = prsr.add_subparsers(title="commands", dest="command")

    prsr.add_argument("-v", "--debug", help="Debug/Verbose output",\
                        action='store_true', default=False)

    storage = sub.add_parser(name='storage', description='Audit Storage')
    storage.add_argument("-m", "--mock", help="Run this against the MOCK cluster",\
                     action='store_true', default=False)
    storage.add_argument("-p", "--prod", help="Run this against the PROD cluster",\
                     action='store_true', default=False)
    storage.add_argument('-dc', '--datacenter', required=False, action='store', \
                        help="Datacenter name abbreviation, ex: m-ar, ln, ch")

    args = prsr.parse_args()

    args.port = 443
    args.vmw = lambda: None
    if args.mock:
        args.vmw.env = "mock"
        args.vmw.host = ESXI['mock']['vcenter']['host']
        args.vmw.port = ESXI['mock']['vcenter']['port']
        args.vmw.user = ESXI['mock']['vcenter']['user']
        args.vmw.passwd = ESXI['mock']['vcenter']['passwd']
    elif args.prod:
        args.vmw.env = "prod"
        args.vmw.host = ESXI['prod']['vcenter']['host']
        args.vmw.port = ESXI['prod']['vcenter']['port']
        args.vmw.user = ESXI['prod']['vcenter']['user']
        args.vmw.passwd = ESXI['prod']['vcenter']['passwd']
    else:
        args.vmw.env = args.env
        args.vmw.host = args.vcenter
        args.vmw.port = args.port
        args.vmw.user = args.user
        args.vmw.passwd = args.password
    if args.datacenter:
        args.dctr = lambda: None
        args.dctr.name = ESXI[args.vmw.env]['clusters'][args.datacenter]['esxi_dc_name']
        try:
            args.dctr.dscn = ESXI[args.vmw.env]['clusters'][args.datacenter]['esxi_stor_clstr_name']
        except:
            logger.warn("Failed to set storage cluster name...")
        args.dctr.oct = ESXI[args.vmw.env]['clusters'][args.datacenter]['site_oct']
        args.dctr.ratio = ESXI[args.vmw.env]['clusters'][args.datacenter]['esx_ratio']
        args.dctr.ntwks = ESXI[args.vmw.env]['clusters'][args.datacenter]['networks']
        args.dctr.vm_ver = ESXI[args.vmw.env]['clusters'][args.datacenter]['vm_ver']
        args.dctr.osid = ESXI[args.vmw.env]['clusters'][args.datacenter]['osid']
        args.dctr.bvlid = ESXI[args.vmw.env]['clusters'][args.datacenter]['native_vlan']

    return args

def init_log():
    logpath = '/var/log/debesys/processor.log'
    logdir = os.path.dirname(logpath)
    try:
        if not os.path.isdir(logdir):
            os.mkdir(logdir)
    except:
        print("Failed to create %s" % logdir)

    logger = logging.getLogger()

    return logger

def main():

    if sys.stdin.isatty():
        coloredlogs.install()

    args = get_args()
    logger = init_log()

    logger.info("Starting up esxi_audit app...")
    ttesxi = ttESXi(args)
    vms = ttesxi.get_vm_list(args.dctr.name)

if __name__ == '__main__':
    main()
    sys.exit(0)
