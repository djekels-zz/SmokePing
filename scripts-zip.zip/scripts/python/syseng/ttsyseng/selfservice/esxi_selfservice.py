import argparse
import logging
import platform
import os
import uuid
import stat
import requests
import sys
import json
import re
import urllib
import datetime
import time
from pyVmomi import vim
from pprint import pprint
from ttsyseng.selfservice.helpers.conf_data import SETTINGS,ESXI
from ttsyseng.selfservice.helpers.esxi import ttESXi
from ttsyseng.selfservice.helpers.servicenow_api import ServiceNowAPI, ServiceNowTableLock
from logging.handlers import RotatingFileHandler

USER = os.environ.get("JENKINS_USER")
TOKEN = os.environ.get("JENKINS_TOKEN")

def get_args():
    """
    Function: get_args
    Summary: parse argv and return dict() of flags and data passed in
    Examples: get_args()
    Returns: dict() of flags and data passed in.
    """
    logger = logging.getLogger(__name__)
    prsr = argparse.ArgumentParser(
        description='Creating VM in ESXi Cluster')
    sub = prsr.add_subparsers(title="commands", dest="command")

    prsr.add_argument("-v", "--debug", help="Debug/Verbose output",\
                        action='store_true', default=False)

    avm = sub.add_parser(name='create', description='Create VM(s)')
    avm.add_argument("-m", "--mock", help="Run this against the MOCK cluster",\
                     action='store_true', default=False)
    avm.add_argument("-p", "--prod", help="Run this against the PROD cluster",\
                     action='store_true', default=False)
    avm.add_argument("-n", '--name', required=False, action='store', \
                        help="Name of VM")
    avm.add_argument("-b", '--bootstrap', action='store_true', default=False, \
                     help='If supplied causes a chef bootstrap to occur')
    avm.add_argument('-dc', '--datacenter', required=False, action='store', \
                        help="Datacenter name abbreviation, ex: m-ar, ln, ch")
    avm.add_argument("-vc", '--vcenter', required=False, action='store', \
                        help='Remote vCenter host host to connect to')
    avm.add_argument('-o', '--port', type=int, default=443, action='store', \
                        help='Port to connect on')
    avm.add_argument('-u', '--user', required=False, action='store', \
                        help='User name to use when connecting to host')
    avm.add_argument('-pswd', '--password', required=False, action='store', \
                        help='Password to use when connecting to host')
    avm.add_argument("-e", '--env', required=False, action='store', \
                        help='What TT Environement is this Dev/Mock/Prod')
    avm.add_argument("-ce", '--chef_env', required=False, action='store', \
                        help='What Chef Environement is this?', default="none")
    avm.add_argument('-cpu', '--cpu', required=False, action='store', \
                        help='Number of cpus/cores. 1 core per cpu.', \
                        default=4)
    avm.add_argument('-ds', '--disksize', required=False, action='store', \
                        help='Disk size in GB, 200GB default', default=200)
    avm.add_argument('-dt', '--disktype', required=False, action='store', \
                        help='san, ssd or local, defaults to san except for infra cluster', \
                        default="san", choices={"san", "ssd", "local"})
    avm.add_argument('-mem', '--memory', required=False, action='store', \
                        help='Amount of memory for vm in GB, 8GB default', default=8)
    avm.add_argument('--ssd', required=False, action='store', \
                        help='Choose to put VMs on local SSD volume', \
                        default=False)
    avm.add_argument('-ct', '--clstr_type', required=False, action='store', \
                        help='prod or infra. Prod is for TT apps.', \
                        default='prod', choices={"prod", "infra"})
    avm.add_argument('-x', '--multiplier', required=False, action='store', \
                        help='Number of VMs to create with same args', default=1)
    avm.add_argument('-os', '--centos_version', required=False, action='store', \
                        help='Choose whether you want centos 6 or centos 7', \
                        default='7.4', choices={"6.9", "6.10", "7.4", "7.6", "7.7", "7.8", "7.9", "8.0", "8.1", "8.2"})

    dvm = sub.add_parser(name='delete', description='Delete VM(s)')
    dvm.add_argument("-m", "--mock", help="Run this against the MOCK cluster",\
                     action='store_true', default=False)
    dvm.add_argument("-p", "--prod", help="Run this against the PROD cluster",\
                     action='store_true', default=False)
    dvm.add_argument("-n", '--name', required=False, action='store', \
                        help="Name of VM")
    dvm.add_argument('-dc', '--datacenter', required=False, action='store', \
                        help="Datacenter name abbreviation, ex: m-ar, ln, ch")
    dvm.add_argument("-vc", '--vcenter', required=False, action='store', \
                        help='Remote vCenter host host to connect to')
    dvm.add_argument('-o', '--port', type=int, default=443, action='store', \
                        help='Port to connect on')
    dvm.add_argument('-u', '--user', required=False, action='store', \
                        help='User name to use when connecting to host')
    dvm.add_argument('-pswd', '--password', required=False, action='store', \
                        help='Password to use when connecting to host')
    dvm.add_argument("-e", '--env', required=False, action='store', \
                        help='What TT Environement is this Dev/Mock/Prod')

    args = prsr.parse_args()

    pprint(args)

    if args.command == "delete":
        args.clstr_type = None
        args.centos_version = None

    if not args.mock and not args.prod and not args.vcenter:
        msg = "Please provide a Cluster resource to proceed. You need to either pass " \
              "-mock (--mock), -prod (--prod) or -vc (--vcenter) to do anything!"
        logger.error(msg)
        sys.exit(1)

    if args.mock and args.prod and args.vcenter:
        msg = "You can not pass both a environment flag and the vcenter flag. " \
              "Please use one or the other"
        logger.error(msg)
        sys.exit(1)

    if args.vcenter and not args.port and not args.user and not args.password:
        msg = "When using the vcenter argument (-vc|--vcenter), you must pass" \
              "Port (-o|--port), Username (-u|--user) and Password (-p|--password)." \
              "Please add those flags and try again!"
        logger.error(msg)
        sys.exit(1)

    if args.command == "delete" and not args.name:
        msg = "To delete a vm, you need to provide the vm name (-n|--name)!"
        logger.error(msg)
        sys.exit(1)

    args.vmw = lambda: None
    if args.mock:
        args.vmw.env = "mock"
        args.vmw.host = ESXI['mock']['vcenter']['host']
        args.vmw.port = ESXI['mock']['vcenter']['port']
        args.vmw.user = ESXI['mock']['vcenter']['user']
        args.vmw.passwd = ESXI['mock']['vcenter']['passwd']
    elif args.prod:
        args.vmw.env = "prod"
        args.vmw.host = ESXI['prod']['vcenter']['host']
        args.vmw.port = ESXI['prod']['vcenter']['port']
        args.vmw.user = ESXI['prod']['vcenter']['user']
        args.vmw.passwd = ESXI['prod']['vcenter']['passwd']
    else:
        args.vmw.env = args.env
        args.vmw.host = args.vcenter
        args.vmw.port = args.port
        args.vmw.user = args.user
        args.vmw.passwd = args.password

    if args.datacenter:
        args.dctr = lambda: None
        args.dctr.name = ESXI[args.vmw.env]['clusters'][args.datacenter]['esxi_dc_name']
        args.dctr.oct = ESXI[args.vmw.env]['clusters'][args.datacenter]['site_oct']
        args.dctr.ratio = ESXI[args.vmw.env]['clusters'][args.datacenter]['esx_ratio']
        args.dctr.ntwks = ESXI[args.vmw.env]['clusters'][args.datacenter]['networks']
        args.dctr.vm_ver = ESXI[args.vmw.env]['clusters'][args.datacenter]['vm_ver']
        args.dctr.osid = ESXI[args.vmw.env]['clusters'][args.datacenter]['osid']
        args.dctr.bvlid = ESXI[args.vmw.env]['clusters'][args.datacenter]['native_vlan']

    if args.clstr_type == "prod":
        if ESXI[args.vmw.env]['clusters'][args.datacenter]['esxi_clstr_name']:
            args.dctr.clstr_name = ESXI[args.vmw.env]['clusters']\
                                   [args.datacenter]['esxi_clstr_name']
        else:
            msg = "This Datacenter does not have a Prod Cluster. Please try again!"
            logger.error(msg)
            sys.exit(1)
    elif args.clstr_type == "infra":
        if ESXI[args.vmw.env]['clusters'][args.datacenter]['esxi_infra_name']:
            args.dctr.clstr_name = ESXI[args.vmw.env]['clusters']\
                                   [args.datacenter]['esxi_infra_name']
        else:
            msg = "This Datacenter does not have a Infra Cluster. Please try again!"
            logger.error(msg)
            sys.exit(1)

    if args.centos_version == "6.9" or args.centos_version == "6.10":
        args.centos_version = args.centos_version
    elif args.centos_version == "7.6":
        args.centos_version = "7.6.1810"
    elif args.centos_version == "7.7":
        args.centos_version = "7.7.1908"
    elif args.centos_version == "7.4":
        args.centos_version = "7.4.1708"
    elif args.centos_version == "7.8":
        args.centos_version = "7.8.2003"
    elif args.centos_version == "7.9":
        args.centos_version = "7.9.2009"
    elif args.centos_version == "8.0":
        args.centos_version = "8.0.1905"
    elif args.centos_version == "8.1":
        args.centos_version = "8.1.1911"
    elif args.centos_version == "8.2":
        args.centos_version = "8.2.2004"
    else:
        args.centos_version = "7.6.1810"

    if not args.port:
        args.port = 443
    return args

def main():
    """
    Function: main
    Summary: do all the things...
    Examples: main()
    Returns: Null
    """
    
    # LOGGING SETUP DATE|TIME|LOGLEVEL|PROCESSID|MESSAGE
    log_format = '%(asctime)s.%(msecs).03d | %(levelname)-8s %(process)d | %(message)s'
    date_format = '%Y-%m-%d %H:%M:%S'
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    formatter = logging.Formatter(fmt=log_format, datefmt=date_format)
    sh = logging.StreamHandler()
    sh.setFormatter(formatter)
    logger.addHandler(sh)

    args = get_args()
    ttesxi = ttESXi(args)
    
    ###if os.isatty(sys.stdout.fileno()):


    if args.command == "delete" and args.name:
        ttesxi.delete_vm(args)
        sys.exit(0)

    # LOG WHERE FOR WINDOWS OR LINUX
    if "Windows" in platform.platform():
        if not os.path.exists("C:/tmp/"):
            os.mkdir("C:/tmp/")
        fh = RotatingFileHandler("C:/tmp/create_vm.py", maxBytes=1024 * 1024 * 100, backupCount=5)
    else:
        if not os.path.exists("/tmp/"):
            os.mkdir("/tmp/")
        fh = RotatingFileHandler("/tmp/create_vm.py", maxBytes=1024 * 1024 * 100, backupCount=5)



    msg = "Creating %s VMs" % args.multiplier
    logger.info(msg)
    for cnt in range(int(args.multiplier)):
        try:
            ttesxi.create_vm(args)
            ttesxi.reg_pxe(args)
        except Exception as exp:
            logger.error("Creating this vm has failed. Cleaning up Servicenow. Contact Systems" \
                         " Engineering to clean up vm in vSphere. Exception %s", exp)
            logger.error(exp)
            #sn.update_sn_ip_status(mgmt_ip, vm_name, False)
            #api.delete_vm(vm_name)
            sys.exit(1)

if __name__ == '__main__':
  main()
