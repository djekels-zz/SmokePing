from setuptools import setup, find_packages
from codecs import open
from os import path

here = path.abspath(path.dirname(__file__))

setup(
    name='ttsyseng',
    version='1.1.81',
    description='Trading Technologies - SysEng Modules',
    long_description='Trading Technologies - SysEng Modules',
    url='https://github.com/tradingtechnologies/systems_engineering',
    author='Systems Engineering',
    author_email='syseng@tradingtechnologies.com',
    license='Proprietary. All Rights Reserved',
    keywords='SysEng Modules',     # What does your project relate to?
    include_package_data=True,
    packages=find_packages(exclude=['contrib', 'docs', 'tests'], include=['*']),
    install_requires=[
        'requests',
        'pyvmomi',
        'PyYAML',
        'scp',
        'paramiko==2.5.1',
        'pysnow',
        'python-hpilo',
        'pyghmi',
        'PyChef',
        'coloredlogs'
    ],

    # command line tool
    entry_points={
        'console_scripts': [
            'ss_esxi=ttsyseng.selfservice.esxi_selfservice:main',
            'ss_rekick=ttsyseng.selfservice.rekick:main',
            'esxi_audit=ttsyseng.selfservice.esxi_audit:main',
            'ntx_audit=ttsyseng.selfservice.ntnx_audit:main'
        ]
    }
)
