#!/bin/bash
#
#Author: Sy Spencer
#Jira: OPS-28144
#Date: April 2021
#

#Script expects CSV file formatted in <vlan name>,<vm uuid>,<vm hostname>,<mac address>
#Script expects to be sorted by hostname or VMs will be rebooted after every nic swap
#Script expects cluster VLANs to exactly match formating of VLANs in CSV
#Script expects to be unix format. Any DOS/WINDOWS new line or carriage return characters will cause issues

file="$1"

now=$(TZ=America\chicago date +"%m%d%y-%H%M")
vm2="foo"
line=0

inf () {
	ch_time=$(TZ=America\chicago date +"%m-%d-%y %T"); printf "$ch_time | $line | INFO | "
}

dbg () {
	ch_time=$(TZ=America\chicago date +"%m-%d-%y %T"); printf "$ch_time | $line | DEBUG | "
}

#Function only triggers reboot of VM after the next VM is being worked on to prevent unnecessary reboots
reboot_vm () {
	if [[ "$1" != "foo" ]]; then
		printf "$(dbg)var vm2 does not equal foo\n" | tee -a $logfile > /dev/null 2>&1
		if [[ "$1" == "$2" ]]; then
			printf "$(inf)Still working on $2...\n" | tee -a $logfile
		elif [[ "$1" != "$2" ]] && [[ "$1" != "" ]]; then
			printf "$(inf)VM $1 modifications complete, rebooting now.\n" | tee -a $logfile
			printf "$(dbg)Command: \"/usr/local/nutanix/bin/acli vm.reset \"$1\"\n" | tee -a $logfile > /dev/null 2>&1
			/usr/local/nutanix/bin/acli vm.reset "$1" | tee -a $logfile
			vm2=$2
			printf "$(dbg)var \$vm2 equals $1\n" | tee -a $logfile > /dev/null 2>&1
		else
			printf "$(inf)WARNING no value detected for var \$vm2. No action taken.\n" | tee -a $logfile
		fi
	else
		printf "$(dbg)var vm2 is foo. Setting to current vm \"$2\"\n" | tee -a $logfile > /dev/null 2>&1
		vm2=$2
	fi
	line=$(($3+1))	
}

logfile="/tmp/nutnx_vm_mac_swapper_$now.log"
printf "$(inf)Logs will be written to $logfile\n" | tee -a $logfile

#verifies CSV does not have any windows formatting nonsense
if (file -b - < $file | grep -q "CRLF"); then
	printf "$(inf)WARNING - File \"$file\" appears to be DOS/WINDOWS format.\n" | tee -a $logfile
	printf "$(inf)Recommend trying dos2unix tool on another linux machine to modify file and try again.\n" | tee -a $logfile
	printf "$(inf)Please remember to correctly format CSV per guidelines at top of script.\n" | tee -a $logfile
	printf "$(inf)Stopping script.\n" | tee -a $logfile
	exit 1
else
	printf "$(inf)Verified file \"$file\" does not have DOS/Windows formatting.\n" | tee -a $logfile
fi


while IFS=',' read -r vlan nic_uid vm mac_addr
do
	if /usr/local/nutanix/bin/acli vm.get "$vm" | grep -q "config"; then
		printf "$(dbg)$vm is present in this cluster.\n" | tee -a $logfile > /dev/null 2>&1
		#grab VM's current mac address for target vlan
		cur_mac="$(/usr/local/nutanix/bin/acli vm.nic_list "$vm" | grep "$vlan" | awk -- '{printf $1}')"
		#len1=$(expr length $mac_addr)
		#len2=$(expr length $cur_mac)
		printf "$(inf)Working on $vm | $vlan | $mac_addr.\n" | tee -a $logfile
		printf "$(dbg)$vm | $vlan current MAC = \"$cur_mac\"\n" | tee -a $logfile > /dev/null 2>&1
		printf "$(dbg)$vm | $vlan listed MAC  = \"$mac_addr\"\n" | tee -a $logfile > /dev/null 2>&1
		#check if existing nic/mac is present for this vm
		if [ -z "$cur_mac" ]; then
			printf "$(inf)No NIC found for $vm | $vlan.\n" | tee -a $logfile
			printf "$(inf)Adding NIC for $vm | $vlan | $mac_addr.\n" | tee -a $logfile
			printf "$(dbg)Command: \"/usr/local/nutanix/bin/acli vm.nic_create \"$vm\" network=\"$vlan\" mac=\"$mac_addr\"\"\n" | tee -a $logfile > /dev/null 2>&1
			/usr/local/nutanix/bin/acli vm.nic_create "$vm" network="$vlan" mac="$mac_addr" | tee -a $logfile
			reboot_vm "$vm2" "$vm" "$line"
		elif [[ "$mac_addr" == "$cur_mac" ]]; then
			printf "$(inf)MAC match! $vm | $vlan [$mac_addr|$cur_mac]. Taking no action.\n" | tee -a $logfile
			printf "$(dbg)var len1 length \"$len1\", var len2 length \"$len2\"\n" | tee -a $logfile > /dev/null 2>&1
			line=$(($line+1))
		#if MAC's are not equal verifies the values were both 17 characters long as expected of MACs
		elif [[ "$mac_addr" != "$cur_mac" ]]; then
			len1=$(expr length $mac_addr)
			len2=$(expr length $cur_mac)
			if [[ $len1 == 17 ]] && [[ $len2 == 17 ]]; then
				printf "$(inf)MAC addresses do not match [$mac_addr|$cur_mac]\n" | tee -a $logfile
				printf "$(dbg)var len1 length \"$len1\" | var len2 length \"$len2\"\n" | tee -a $logfile > /dev/null 2>&1
				printf "$(inf)Removing NIC for $vm | $vlan | $cur_mac.\n" | tee -a $logfile
				printf "$(dbg)Command: \"/usr/local/nutanix/bin/acli vm.nic_delete \"$vm\" \"$cur_mac\"\n" | tee -a $logfile > /dev/null 2>&1
				/usr/local/nutanix/bin/acli vm.nic_delete "$vm" "$cur_mac" | tee -a $logfile
				printf "$(inf)Adding NIC for $vm | $vlan | $mac_addr.\n" | tee -a $logfile
				printf "$(dbg)Command: \"/usr/local/nutanix/bin/acli vm.nic_create \"$vm\" network=\"$vlan\" mac=\"$mac_addr\"\"\n" | tee -a $logfile > /dev/null 2>&1
				/usr/local/nutanix/bin/acli vm.nic_create "$vm" network="$vlan" mac="$mac_addr" | tee -a $logfile
			else
				printf "$(inf)MAC addresses do not match [$mac_addr|$cur_mac]. There may be a formatting issue. Taking no action.\n" | tee -a $logfile
			fi
			printf "$(dbg)var vm: \"$vm\" | var vm2: \"$vm2\"\n" | tee -a $logfile > /dev/null 2>&1
			reboot_vm "$vm2" "$vm" "$line"	
		else
			printf "$(inf)Something may be wrong. CSV may not be formatted correctly.\n" | tee -a $logfile
			printf "$(dbg)Current var values \$vlan=$vlan | \$vm=$vm | \$mac_addr=$mac_addr | \$cur_mac=$cur_mac\n" | tee -a $logfile > /dev/null 2>&1
			printf "$(dbg)var len1 length \"$len1\", var len2 length \"$len2\"\n" | tee -a $logfile > /dev/null 2>&1
			line=$(($line+1))
		fi
	else
		printf "$(inf)***ERROR: Unable to find $vm on this cluster***\n" | tee -a $logfile
		line=$(($line+1))	
	fi
done < $file

#This is needed or the last modified VM in the list will not get rebooted.
if [[ "$vm2" != "" ]]; then
	if [[ "$vm2" == "foo" ]]; then
		printf "$(inf)No action taken.\n" | tee -a $logfile
	else
		printf "$(inf)VM $vm2 modifications complete, rebooting now.\n" | tee -a $logfile
		printf "$(dbg)Command: \"/usr/local/nutanix/bin/acli vm.reset \"$vm2\"\n" | tee -a $logfile > /dev/null 2>&1
		/usr/local/nutanix/bin/acli vm.reset "$vm2" | tee -a $logfile
	fi
else
	printf "$(inf)WARNING no value detected for var \$vm2. No action taken.\n" | tee -a $logfile
fi

printf "$(inf)Script is complete. More detailed logs at $logfile\n" | tee -a $logfile

exit 0
