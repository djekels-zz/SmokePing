$user = 'ops-monitoring@int.tt.local'
$pswd = 'lUtw4oSMRSuV'

$secPswd = ConvertTo-SecureString -String $pswd -AsPlainText -Force
$cred = New-Object -TypeName PSCredential -ArgumentList $user,$secPswd

$hosts = "172.17.250.184"

$b = Get-Date

$a = "<style>"

$a = $a + "BODY{background-color:white;}"

$a = $a + "TABLE{border-width: 1px;border-style: solid;border-color: black;border-collapse: collapse;}"

$a = $a + "TH{border-width: 1px;padding: 1px;border-style: solid;border-color: black;background-color:80e2ff}"

$a = $a + "TD{border-width: 1px;padding: 1px;border-style: solid;border-color: black;background-color:white}"

$a = $a + "</style>"

if($global:defaultviservers){

    Disconnect-VIServer -Server $global:defaultviservers -Force -Confirm:$false

}

$output =  foreach($vc in $hosts){

    Write-Host "Getting Cluster Information from $vc"

    Connect-VIServer -Server $vc -Credential $cred | Out-Null

    Get-Cluster -Server $vc | where{$_.ExtensionData.Host.Count -ne 0} | ForEach-Object -Process {

        Write-Host "Looking at cluster $($_.Name)"

        #$ds = Get-Datastore -RelatedObject $_ | where{$_.ExtensionData.Summary.MultipleHostAccess}

        $sStat = @{

            Entity = Get-Cluster -Name $_.Name

            Stat = 'cpu.usage.average', 'mem.usage.average'

            Start = (Get-Date).AddDays(-7)

            # Start = (Get-Date).AddHours(-1)

            Instance = '*'

            ErrorAction = 'SilentlyContinue'

            }

        $stat = Get-Stat @sStat

        $esx = Get-VMHost -Location $_

        #$hostthreads = ($esx.extensiondata.hardware.cpuinfo.numcputhreads | Measure-Object -Sum).Sum

        $vm = Get-VM -Location $_ | where{$_.PowerState -eq "PoweredOn"}

        $cpuTot = ($esx | Measure-Object -Property CpuTotalMhz -Sum).Sum

        $cpuUse = ($esx | Measure-Object -Property CpuUsageMhz -Sum).Sum

        $memTot = ($esx | Measure-Object -Property MemoryTotalGB -Sum).Sum

        $memUse = ($esx | Measure-Object -Property MemoryUsageGB -Sum).Sum

        $obj = [ordered]@{

            #vCenter = $global:defaultviserver.Name



            Cluster = $_.Name

            'Total CPU Ghz' = [math]::Round($cpuTot/1000,0)

            'CPU Usage' = "{0:P0}" -f ($cpuUse/$cpuTot)

            #'CPU 7-day' = "{0:P2}" -f (((($stat | where { $_.MetricId -eq 'cpu.usage.average' }).Value | Measure-Object -Average).Average)/100)

            'CPU Free' = "{0:P0}" -f (($cpuTot - $cpuUse)/$cpuTot)

            'Total RAM GB' = [math]::Round($memTot,0)

            'RAM Usage' = "{0:P0}" -f ($memUse/$memTot)

            #'RAM 7-day' = "{0:P2}" -f (((($stat | where { $_.MetricId -eq 'mem.usage.average' }).Value | Measure-Object -Average).Average)/100)

            'RAM Free GB' = "{0:P0}" -f (($memTot - $memUse)/$memTot)

            #'Total Capacity GB' = [math]::Round(($ds.CapacityGB | Measure-Object -Sum).Sum,0)

            #'Used Capacity GB' = [math]::Round(($ds | %{$_.CapacityGB - $_.FreeSpaceGB} | Measure-Object -Sum).Sum,0)

            #'Free Capacity GB' = [math]::Round(($ds.FreeSpaceGB | Measure-Object -Sum).Sum,0)

            #'N° Hosts' = $_.ExtensionData.Host.Count
   
            'Hosts' = $_.ExtensionData.Host.Count

            'VMs' = &{

                $esxVM = Get-View -Id $_.ExtensionData.Host -Property VM

                $vm = @()

                if($esxVM.VM){

                    $vm = Get-View -Id $esxVM.VM -Property Summary.Config.Template |

                    where{-not $_.Summary.Config.Template}

                }

                $vm.Count

                }

            #'vCPU' = ($vm.NumCpu | Measure-Object -Sum).Sum

            #'pCPU' = ($esx.NumCpu | Sort-Object -Descending | Select -Skip 1 | Measure-Object -Sum).Sum

            #'vCPU/pCPU' = "{0:P0}" -f (($vm.NumCpu | Measure-Object -Sum).Sum / ($esx.NumCpu | Measure-Object -Sum).Sum)

            #'vMem' = [math]::Round(($vm.MemoryGB | Measure-Object -Sum).Sum)

            #'pMem' = [math]::Round(($esx.MemoryTotalGB | Measure-Object -Sum).Sum)

            #'VMs/Hosts' = $VMs / $Hosts 
	    #'VMs/Hosts' = [math]::Round(($VMs | Measure-Object -Sum).Sum / ($Hosts | Measure-Object -Sum).Sum)
	    #'VMs/Hosts' = "{0:P0}" -f ($vm.Count / $esx.Count)

        }
        New-Object PSObject -Property $obj 

   }

   Disconnect-VIServer $vc -confirm:$false
}

 " Report is generated at" +$b

$output | ConvertTo-Html -Head $a | Out-File ./prod-report.htm -width 400
echo "`n"
echo "`n"
$date = get-date -Format f
echo 'This report was generated on' >> ./prod-report.htm
 $date >> ./prod-report.htm
echo Yes |mv ./prod-report.htm /var/www/html/vmware-memory-report/

